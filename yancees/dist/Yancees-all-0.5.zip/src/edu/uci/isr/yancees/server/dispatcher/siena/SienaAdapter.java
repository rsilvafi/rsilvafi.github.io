/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.server.dispatcher.siena;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.util.HashMap;
import java.util.Iterator;

import siena.AttributeValue;
import siena.HierarchicalDispatcher;
import siena.Notifiable;
import siena.Notification;
import siena.SienaException;
import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.GenericEvent;
import edu.uci.isr.yancees.SubscriptionInterface;
import edu.uci.isr.yancees.server.core.DispatcherException;
import edu.uci.isr.yancees.server.core.EventDispatcherInterface;
import edu.uci.isr.yancees.server.core.EventDispatcherListenerInterface;
import edu.uci.isr.yancees.server.core.ParsingException;

public class SienaAdapter
      implements EventDispatcherInterface {

   // default address used in this implementation, case no other is provided
	private final String DEFAULT_SIENA_ADDRESS="tcp:localhost:1234";

   private HierarchicalDispatcher siena; // reference to siena.
   private String sienaAddress;
   private HashMap subscribersMap; // Associates subscribers to their SubscriberMediators

   private final boolean print = edu.uci.isr.yancees.server.YanceesServer.PRINT_DEBUG;

   /**
    * Constructor
    *
    * @param sienaAddress is the address where siena is executing. It must follow
    * the siena syntax.
    */
   public SienaAdapter(String address) throws DispatcherException {
      subscribersMap = new HashMap();
      connect(address);

   }

   public SienaAdapter() {
      subscribersMap = new HashMap();
      // this constructor requires the call of connect method
   }

	public void connect() throws DispatcherException {
		if (sienaAddress == null) {
			 sienaAddress = DEFAULT_SIENA_ADDRESS; 
   	} 
   
		 try {
			 if (print)
			 	System.out.print("SienaAdapter: Connecting to Siena...");
			 siena = new HierarchicalDispatcher();
			 siena.setMaster(sienaAddress);
			 if (print)
			 	System.out.println("[OK]");

		 } catch (SienaException ex) {
			 throw new DispatcherException("Siena error:" + ex.toString());
		 } catch (Exception ex) {
			 throw new DispatcherException("General error:" + ex.toString());
		 }

	}

   /**
    * Connects to siena bafore any method can be used.
    * this method is used by the architecture manager to initialize the dispatcher
    * and is not part of the EventDispatcherInterface
    * @param sienaAddress is the address provided in the configuration file, used
    * here to initialized the adapter
    */
   public void connect(String address) throws DispatcherException {

      sienaAddress = address;
      connect();
      
   }

   protected void finalize() throws Throwable {
      siena.clearSubscriptions();
      siena.shutdown();
      super.finalize();
   }

   /**
    * Publishes a Yancees event in the format of Siena event. It also makes
    * the namespace transformation to differentiate body and header events.
    * Special attributes are added to identify yancees events from regular ones
    * that may be used in siena
    *
    *  @param evnt The event to publish.
    *  @see Event
    **/
   public void publish(EventInterface e) throws DispatcherException {

      SienaEvent evnt = new SienaEvent(e);
      Notification n = new siena.Notification(); // Native Siena event to be composed

      String attName; // temporary name
      AttValue value; // temporary value

      //n.putAttribute("yancees.type", "Yancees 1.0"); // Marks the event as belonging to yancees

      // Parses the body of the event
      for (Iterator i = evnt.getAttributeNamesIterator(); i.hasNext(); ) {
         attName = (String) i.next();
         value = evnt.getAttribute(attName);

         switch (value.getType()) {
            case AttValue.STRING: // or BYTEARRAY are the same
               n.putAttribute(attName,
                              value.stringValue());
               break;
            case AttValue.LONG:
               n.putAttribute(attName,
                              value.longValue());
               break;
            case AttValue.BOOL:
               n.putAttribute(attName,
                              value.booleanValue());
               break;
            case AttValue.DOUBLE:
               n.putAttribute(attName,
                              value.doubleValue());
               break;

         }
      }

      
      try {
         //System.out.print("SienaAdapter: piblishing event...");
         if (print) {
            System.out.println("SienaAdapter: publishing: " + n.toString());
         }
         siena.publish(n);
         if (print)
         	System.out.println(" [OK]");
      } catch (SienaException ex) {
         System.out.println(" [ERROR]");
         throw new DispatcherException(
               "Error while sending event to Siena! \n" +
               ex.toString());
      }

   }

   /**
    *  subscribes for sequences of events matching subscription <b>p</b>.
    *
    *  <p>Notice that given the distributed nature of some
    *  implementations of Dispatcher interface, there exist race
    *  conditions that might affect the semantics of subscriptions.
    *  A subscriber might miss some notifications published before or
    *  while the subscription is processed by Dispatcher.
    *
    *  <p>Also, keep in mind that the current implementation of Dispatcher
    *  does not enforce any temporal order for the delivery of
    *  notifications.  This limitation might affect the recognition
    *  of patterns.  For example, two notifications <em>x</em> and
    *  <em>y</em>, generated at time <em>t<sub>x</sub></em> and
    *  <em>t<sub>y</sub></em> respectively, with
    *  <em>t<sub>x</sub></em> &lt; <em>t<sub>y</sub></em>, in that
    *  order matching a pattern <em>P=(f<sub>x</sub>
    *  f<sub>y</sub>)</em>, might in fact reach the subscriber at
    *  times <em>T<sub>x</sub></em> and <em>T<sub>y</sub></em>, with
    *  <em>T<sub>x</sub></em> &gt; <em>T<sub>y</sub></em>, in which
    *  case pattern <em>P</em> would not be matched.
    *
    *  @param li is the subscriber
    *  @param sub is a generic subscription containing a DOM tree. It is expected
    *  here that this subscription is in the format readable by the SienaAdapter.
    *  @see #unsubscribe
    **/
   public void subscribe(SubscriptionInterface sub, EventDispatcherListenerInterface li) throws
         DispatcherException {

      SubscriberMediator med;
      SienaSubscription sienaSub;

      if (sub == null) {
         throw new DispatcherException(
               "SienaAdapter: Null subscrtiption reference provided");
      }

      try {
         sienaSub = new SienaSubscription(sub.getDOM());
      } catch (ParsingException ex) {
         throw new DispatcherException(
               "SienaAdapter: Error while parsing siena subscription. "+ex.toString());
      }

      if (subscribersMap.containsKey(li)) {
         med = (SubscriberMediator) subscribersMap.get(li);
      } else {
         med = new SubscriberMediator(li);
         subscribersMap.put(li, med);
      }
      try {
         if (print) {
            System.out.println("SienaAdapter: Subscribing to event: " + sienaSub.toString());
         }
         siena.subscribe(sienaSub.getPattern(), med);
         med.incrementReferenceCounter();
      } catch (siena.SienaException ex) {
         throw new DispatcherException("SienaAdapter: Error while subscribing to Dispatcher " +
                                       ex.toString());
      }
   }

   /** cancels the subscriptions, posted by <b>li</b>, whose subscripton
    *  <b>sub'</b> is covered by subscripiton <b>p</b>.
    *
    *  <p>Unsubscriptions might incurr in the same kind of race
    *  conditions as subscriptions.  Dispatcher will stop sending
    *  notifications to the subscriber only after it has completed
    *  the processing of the unsubscription.  Due to the distributed
    *  nature of some implementations of Dispatcher, this might result in
    *  some additional ``unsolicited'' notifications.
    *
    *  @param li is the subscriber interface
    *  @see #subscribe
    **/
   public void unsubscribe(SubscriptionInterface sub, EventDispatcherListenerInterface li) throws
         DispatcherException {

      SubscriberMediator med;
      SienaSubscription sienaSub = (SienaSubscription) sub;

      if (subscribersMap.containsKey(li)) {
         med = (SubscriberMediator) subscribersMap.get(li);
         siena.unsubscribe(sienaSub.getPattern(), med);
         med.decrementReferenceCounter();
         if (med.getReferenceCounter() <= 0) {
            subscribersMap.remove(med);
         }
      }

   }

   /** cancels <i>all</i> the subscriptions posted by <b>li</b>.
    *
    *  @param li is event dispatcher listener interface
    *  @see #subscribe
    **/
   public void unsubscribe(EventDispatcherListenerInterface li) throws
         DispatcherException {

      SubscriberMediator med = (SubscriberMediator) subscribersMap.get(li);
      if (med != null) {
         
         try {
            siena.unsubscribe(med);
         } catch (siena.SienaException ex) {
            //if (print)
            	System.out.println("SienaAdapter: error when unsubscribing mediator");
            
            throw new DispatcherException(
                  "SienaAdapter: Error while UNsubscribing to Dispatcher" +
                  ex.toString());
         }        
      }
		subscribersMap.remove(li); // it will unsubscribe itself in the finalize() method...

   }

   /** suspends the delivery of notifications to the given subscriber
    *  <code>li</code>.
    *
    *  @param li subscriber to be suspended
    **/
   public void suspendDispatcher(EventDispatcherListenerInterface li) throws
         DispatcherException {

      SubscriberMediator med = (SubscriberMediator) subscribersMap.get(li);
      if (med != null) {
         try {
            siena.suspend(med);
         } catch (siena.SienaException ex) {
            throw new DispatcherException("SienaAdapter: Error while suspending Dispatcher" +
                                          ex.toString());
         }
      }

   }

   /** resumes the delivery of notifications to the given subscriber
    *  <code>n</code>.
    *
    *  @param li is the subscriber callback reference
    **/
   public void resumeDispatcher(EventDispatcherListenerInterface li) throws
         DispatcherException {

      SubscriberMediator med = (SubscriberMediator) subscribersMap.get(li);
      if (med != null) {
         try {
            siena.resume(med);
         } catch (siena.SienaException ex) {
            throw new DispatcherException("SienaAdapter: Error while resuming Dispatcher" +
                                          ex.toString());
         }
      }
   }

   /**
    *  closes this Dispatcher service access point.
    *
    *  This method releases any system resources associated with the
    *  access point.  In case this access point is connected to other
    *  Dispatcher servers, this method will properly disconnect it.
    **/
   public void shutdownDispatcher() throws DispatcherException {
      System.out.println("SienaAdapter: Shutting down siena.");
      siena.shutdown();

   }

   /**
    * This class represents a subscriber, receiving all the events from Siena
    * that are destinated to this particular EventDispatcherListenerInterface
    *
    *	This class here operates as a brides between YANCEES with SIENA.
    * It gets the events from siena, convets it to Events in Yancees and sends
    * to the corresponding EventDispatcherListenerInterface that it represents.
    */
   public class SubscriberMediator
         implements Notifiable {

      private int referenceCounter;
      private EventDispatcherListenerInterface subsInt;

      /**
       * Constructor
       * @param li is the subscriber this class represents
       */
      public SubscriberMediator(EventDispatcherListenerInterface li) {
         subsInt = li;
         referenceCounter = 0;
      }

      public void incrementReferenceCounter() {
         referenceCounter++;
      }

      public void decrementReferenceCounter() {
         referenceCounter--;
      }

      public int getReferenceCounter() {
         return referenceCounter;
      }

      /**
       * Used to receive events from siena
       * It transforms siena events to Yancees events and forwards the event
       * to the appropriate subscriber.
       * @param n is the notification as received from siena, in its native format.
       * 
       */
      public void notify(Notification n) {
         SienaEvent se = new SienaEvent(); // the event to be built

         String name;
         siena.AttributeValue sAttValue;
         
         for (Iterator i = n.attributeNamesIterator(); i.hasNext(); ) {
            name = (String) i.next();
            sAttValue = n.getAttribute(name);
            se.putAttribute(name, getAttValue(sAttValue));
            
         }
         
         // Wrapps the SienaEvent as a generic Event in Yancees, which stores
         // the XML DOM representatio of the event.
         GenericEvent result = null;
         try {
            result = new GenericEvent(se.getDOM());
         } catch (ParsingException ex) {
            System.out.println(
                  "SienaAdapter: Error when extracting result DOM tree from SienaEvent");
            System.out.println(ex);
         }

			// forwards the new generated event to the subscriber
         subsInt.receiveDispatcherNotification(result);
      }

      /**
       * Receives a list of events (a pattern) from siena.
       * It transforms siena events to Yancees events and forwards the event
       * to the appropriate subscriber.
       */
      public void notify(Notification[] n) {
         SienaEvent[] se = new SienaEvent[n.length];

         String name;
         siena.AttributeValue sAttValue;

         // Builds a Yancees event with the Siena Event attributes
         for (int t = 0; t < n.length; t++) {
            se[t] = new SienaEvent();
            for (Iterator it = n[t].attributeNamesIterator(); it.hasNext(); ) {
               name = (String) it.next();
               sAttValue = n[t].getAttribute(name);
               se[t].putAttribute(name, getAttValue(sAttValue));
               
            }
         }

			// Converts it to the generic internal format of Yancees, the Event object.
         GenericEvent[] results = new GenericEvent[se.length];
         try {
            for (int i = 0; i < se.length; i++) {
               results[i] = new GenericEvent(se[i].getDOM());
            }
         } catch (ParsingException ex) {
            System.out.println(
                  "SienaAdapter: error when extracting eventDOM trees from SienaEvents");
            System.out.println(ex);
         }
         
         // forwards the new event to the subscribers.
         subsInt.receiveDispatcherNotification(results);
      }

      /**
       * Convert from siena format to Yancees format of AttValue.
       */
      private AttValue getAttValue(siena.AttributeValue att) {
         switch (att.getType()) {
            case AttributeValue.BYTEARRAY:
               return new AttValue(att.byteArrayValue());
            case AttributeValue.LONG:
               return new AttValue(att.longValue());
            case AttributeValue.DOUBLE:
               return new AttValue(att.doubleValue());
            case AttributeValue.BOOL:
               return new AttValue(att.booleanValue());
            default:
               return new AttValue(att.stringValue());
         }
      }

      protected void finalize() throws Throwable {
         try {
				if (print)
					System.out.println("SienaAdapter: unsubscribing a mediator...");
            siena.unsubscribe(this);
         } catch (siena.SienaException ex) {
            System.out.println(
                  "SienaAdapter: error when finalizing mediator...");
            System.out.println(ex);
         }
         super.finalize();
      }

   }

}