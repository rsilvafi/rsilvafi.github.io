/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 /*
 * Created on Oct 9, 2003
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 * @version 1.0
 */
package edu.uci.isr.yancees.client.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.Hashtable;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.MessageInterface;
import edu.uci.isr.yancees.ProtocolSessionInterface;
import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.YanceesException;
import edu.uci.isr.yancees.YanceesInterface;
import edu.uci.isr.yancees.client.ClientProtocolSession;
import edu.uci.isr.yancees.server.rmi.RemoteProtocolSessionInterface;
import edu.uci.isr.yancees.server.rmi.RemoteSubscriberImplementation;
import edu.uci.isr.yancees.server.rmi.RemoteSubscriberInterface;
import edu.uci.isr.yancees.server.rmi.RemoteYanceesInterface;

/**
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 *
 * This is the API used by remote clients to interact with the server. It hides
 * from the end users, the code necessary to connect to the remote server.
 * In future extentions, it will also hide the client side plug-ins.
 */
public class YanceesRMIClient implements YanceesInterface {

	private RemoteYanceesInterface yanceesRemote;
	private Hashtable mediatorsMap = new Hashtable(); // associates the subscriber interface with the mediator 

	/**
	 * Creates a client implementation and automatically connects to the address
	 * provided
	 * @param hostname is the name of the host having the RMI registry where 
	 * the YANCEES interface is registered. This host name will compose 
	 */
	public YanceesRMIClient(String hostname) throws YanceesException {
		try {
			System.out.println(
				"YanceesPerformanceTest: Binding to yancees remote implementation at host "
					+ hostname
					+ "...");
			yanceesRemote =
				(RemoteYanceesInterface) Naming.lookup(
					"//" + hostname + "/" + RemoteYanceesInterface.LOOKUP_NAME);
		} catch (NotBoundException ex) {
			throw new YanceesException("Yancees RMI service not found. Make sure yancees server is running.");
		} catch (MalformedURLException ex) {
			throw new YanceesException("Wrong Yancees URI. Wrong hostname or Yancees server name.");
		} catch (RemoteException ex) {
			throw new YanceesException("Error bindign to the service: "+ex.toString());
		}

	}

	/* (non-Javadoc)
	 * @see yancees.YanceesInterface#createNewSession(yancees.core.MessageInterface, yancees.SubscriberInterface)
	 */
	public ProtocolSessionInterface createNewSession(
		MessageInterface msg,
		SubscriberInterface si)
		throws YanceesException {
			
			RemoteSubscriberInterface rsi = (RemoteSubscriberInterface) mediatorsMap.get(si);
			if (rsi == null) {
				try {
					rsi = new SubscriberMediator(si);
				} catch (RemoteException e1) {
					System.out.println("YanceesClient: remote exception");
					e1.printStackTrace();
				}
				mediatorsMap.put(si, rsi);
			}
			
			RemoteProtocolSessionInterface rpsi;
			try {
				rpsi = yanceesRemote.createNewSession(msg, rsi);
			} catch (RemoteException e) {
				throw new YanceesException ("YanceesClient: Communication error "+e.toString());
			}
			ProtocolSessionInterface psi = new ClientProtocolSession(rpsi);  

		return psi;
	}

	/* (non-Javadoc)
	 * @see yancees.YanceesInterface#publish(yancees.core.EventInterface)
	 */
	public void publish(EventInterface evt) throws YanceesException {
		
		
		try {
			yanceesRemote.publish(evt);
		} catch (RemoteException e) {
			throw new YanceesException("YanceesClient: remote error "+e.toString());
		} 
		
	}

	/* (non-Javadoc)
	 * @see yancees.YanceesInterface#resumeYancees()
	 */
	public void resumeYancees() throws YanceesException {
		try {
			yanceesRemote.resumeYancees();
		} catch (RemoteException e) {
			throw new YanceesException("YanceesClient: remote error "+e.toString());
		}

	}

	/* (non-Javadoc)
	 * @see yancees.YanceesInterface#shutdownYancees()
	 */
	public void shutdownYancees() throws YanceesException {
		try {
			yanceesRemote.shutdownYancees();
		} catch (RemoteException e) {
			throw new YanceesException("YanceesClient: remote error "+e.toString());
		}

	}

	/* (non-Javadoc)
	 * @see yancees.YanceesInterface#subscribe(yancees.core.MessageInterface, yancees.RemoteSubscriberInterface)
	 */
	public void subscribe(MessageInterface msg, SubscriberInterface si)
		throws YanceesException {
			
			RemoteSubscriberInterface rsi = (RemoteSubscriberInterface) mediatorsMap.get(si);
			if (rsi == null) {
				try {
					rsi = new SubscriberMediator(si);
				} catch (RemoteException e1) {
					System.out.println("YanceesClient: remote exception");
					e1.printStackTrace();
				}
				mediatorsMap.put(si, rsi);
			}
			try {
				yanceesRemote.subscribe(msg, rsi);
			} catch (RemoteException e) {
				throw new YanceesException("YanceesClient: remote error "+e.toString());
			}

	}

	/* (non-Javadoc)
	 * @see yancees.YanceesInterface#suspendYancees()
	 */
	public void suspendYancees() throws YanceesException {
		try {
			yanceesRemote.suspendYancees();
		} catch (RemoteException e) {
			throw new YanceesException("YanceesClient: remote error "+e.toString());
		}

	}

	/* (non-Javadoc)
	 * @see yancees.YanceesInterface#unsubscribe(yancees.SubscriberInterface, yancees.core.MessageInterface)
	 */
	public void unsubscribe(SubscriberInterface si, MessageInterface sub)
		throws YanceesException {

			RemoteSubscriberInterface rsi = (RemoteSubscriberInterface) mediatorsMap.get(si);
			if (rsi == null) {
				throw new YanceesException("No subscription received from this SubscriberInterface. Nothing to subscribe!");
			} else {
				try {
					yanceesRemote.unsubscribe(rsi, sub);
				} catch (RemoteException e) {
					throw new YanceesException("YanceesClient: remote error "+e.toString());
				}
			}

	}

	/* (non-Javadoc)
	 * @see yancees.YanceesInterface#unsubscribe(yancees.SubscriberInterface)
	 */
	public void unsubscribe(SubscriberInterface si) throws YanceesException {
		
		RemoteSubscriberInterface rsi = (RemoteSubscriberInterface) mediatorsMap.get(si);
		if (rsi == null) {
			throw new YanceesException("No subscription received from this SubscriberInterface. Nothing to subscribe!");
		} else {
			try {
				yanceesRemote.unsubscribe(rsi);
			} catch (RemoteException e) {
				throw new YanceesException("YanceesClient: remote error "+e.toString());
			}
		}

	}
	
	
	/**
	  * The subscriber mediator receives notifications from the plug-ins and forward
	  * them to their specific subscribers.
	 */
	public class SubscriberMediator extends RemoteSubscriberImplementation {

		private SubscriberInterface si; // the subscriber to be notified	
		
		/**
		 * Constructor
		 * @param s is the subscriber interface to be notified when the plug-in
		 * evaluation tree is completed.
		 */
		public SubscriberMediator(SubscriberInterface s) throws RemoteException {
			super();
			
			si = s;
		}

		/**
		 * Receives notification as RemoteSubscriberInterface and forwards 
		 * it to the client SubscriberInterface
		 * @param evt is the event received from the remote notification service
		 */
		public void notify(EventInterface evt) throws RemoteException {
			si.notify(evt);
		}

		/**
		 * Receives notification list as RemoteSubscriberInterface and forwards 
		 * it to the client SubscriberInterface
		 * @param evtList is the list of events received from the remote 
		 * notificaiton service 
		 */
		public void notify(EventInterface[] evtList) throws RemoteException {
			si.notify(evtList);
		}

	};

}
