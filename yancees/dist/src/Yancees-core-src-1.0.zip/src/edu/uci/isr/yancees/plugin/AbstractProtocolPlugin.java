/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package edu.uci.isr.yancees.plugin;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.SubscriberInterface;

/**
 * This abstract class defines the basic functionality of the plug-in as well
 * as its main attributes.
 */
public abstract class AbstractProtocolPlugin implements ProtocolPluginInterface {

	private boolean print = edu.uci.isr.yancees.YanceesProperties.getInstance().PRINT_DEBUG;

	private static long globalIdCounter = 0;
	private SubscriberInterface subscriber = null;

	private long myId;
	private String myTag;

	/**
	 * @param subTree is the DOM tree this plugin is responsible for executing
	 */
	public AbstractProtocolPlugin(SubscriberInterface si) {

		AbstractProtocolPlugin.globalIdCounter++;
		myId = AbstractProtocolPlugin.globalIdCounter;
		subscriber = si;
	}


	/**
	 * @return the unique Id of this plugin
	 */
	public long getId() {
		return myId;
	}

	/**
	 * @return the tag name that this plugin is representing. It corresponds to
	 * the type of this plugin instance. For example, if this is a plug-in that handles
	 * a subtree headed by the <followed-by> tag, its type will be "followed-by"
	 *
	 */
	public String getTag() {
		return myTag;
	}
	
	protected void notifySubscriber(EventInterface event) {
	   subscriber.notify(event);
	  
	}
	
	protected void notifySybscriber(EventInterface[] eventList) {
	   subscriber.notify(eventList);
	}



}