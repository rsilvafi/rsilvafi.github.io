/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 *
 * ===================================================================
 * The Apache Software License, Version 1.1
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 *
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 *
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.core;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

/**
 * This class implements the component that parses a generic DOM tree and activates the
 * appropriate plug-ins to handle each tag. These plug-ins are connected together in a
 * publish-subscribe stream, following a BFS search priority, issuing a final answer
 * at the first plug-in of the sequence. This class provides the generic methods used by the
 * NotificationManager to parse its specific DOM trees.
 * These managers extend this abstract class to implement their functionality.
 */

import java.util.HashMap;

import org.w3c.dom.Node;

import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.SubscriptionInterface;
import edu.uci.isr.yancees.plugin.MOPluginInterface;
import edu.uci.isr.yancees.plugin.MOPluginManagerInterface;
import edu.uci.isr.yancees.plugin.PluginManagerException;
import edu.uci.isr.yancees.util.DOMNodeAdapter;

/**
 * Parses a DOM tree using the plug-ins installed in the plug-in manager
 * The plug-in manager may be shared with other builder or may be exclusive for
 * this builder.
 */
public abstract class AbstractPluginTreeBuilder {

	protected boolean print = true;
   //protected boolean print = edu.uci.isr.yancees.YanceesProperties.getInstance().PRINT_DEBUG;

   protected MOPluginManagerInterface plugManager;
   protected final String ROOT_CONTEXT = DOMNodeAdapter.CONTEXT_SEPARATOR; // the '/' separator

   protected AbstractPluginTreeBuilder() {
      if (print) {
         System.out.println("Invoking AbstractPluginTreeBuilder constructor...");
         //plugManager = PluginManager.getInstance();
      }
   }

   /**
    * Configures the plug-in manager, that is used in the resolution of the tags
    * of the incoming subscriptions.
    * @param pm is the reference to the plug-in manager.
    */
   public void setPluginManager(MOPluginManagerInterface pm) {
      plugManager = pm;
   }

   /**
    *  Parses a generic message object, containing a valid parsed
    *  DOM tree, returning the head of the Plug-in structured generated.
    * @param si is the SubscriberInteface where the message came from
    * @param sub TODO
    * @param tree is the DOM Tree to be parsed
    * @return the root plugin interface of the head of the plugin parsing structure.
    **/
   public MOPluginInterface parse(SubscriberInterface si, 
   		SubscriptionInterface sub, org.w3c.dom.Node tree) throws
         ParserException {

      if (plugManager == null)
         throw new ParserException("AbstractPluginTreeBuilder: No Plug-in Manager defined");

      /**
       * Since we are building a reversed tree of required plugins,
       * the garbage collector will destroy it by the time we leave this method.
       * So, we invoke addRequiredPlugin when building the tree to make the father
       * plug-ins keep references to their children.
       *
       * This approach does not prevent plug-ins  from being used in different
       * subscriptions: RITE algorithm.
       */

      MOPluginInterface rootPlugin = null;
      HashMap pluginLookupTable = new HashMap();

      if (tree == null) {
         throw new ParserException(
               "AbstractPluginTreeBuilder: null DOM Tree provided!");
      }

      String[] pluginTags = plugManager.getRegisteredTags();
      DOMNodeAdapter subTree = new DOMNodeAdapter(tree);
      subTree.setVisibleTreeElementNames(pluginTags);

      if (print) {
         System.out.println("AbstractPluginTreeBuilder: operating with visible tags:");
         for (int i = 0; i < pluginTags.length; i++) {
            System.out.print(pluginTags[i]+", ");
         }
         System.out.println("");
      }

      subTree.setFilterNodes(true);
      // Apply the filter and get the nodes with available plugins to be handled
      // Note the use of BFS in order to keep the order of elements
      Node[] pluginNodes = subTree.getVisibleElementsBFS();

      if (pluginNodes == null || pluginNodes.length == 0) {
         throw new ParserException(
               "AbstractPluginTreeBuilder: could not find any of the registered plug-in parseable tags in this xml file!");
      }

      String myRootContext = DOMNodeAdapter.getFullContext(pluginNodes[0]);

      String context; // path name without the name of the tag. It is also the path o a Node father.
      String tagName; // tag name of the plugin.
      String path; // full tree name of the plugin. It is the context + tagName
      MOPluginInterface plugin = null;

      if (print) {
         System.out.println(
               "AbstractPluginTreeBuilder: number of nodes returned " +
               pluginNodes.length);
         System.out.print("They are: ");
         for (int i = 0; i < pluginNodes.length; i++) {
            System.out.print(pluginNodes[i].getNodeName()+", ");
         }
         System.out.println("");
      }

      for (int i = 0; i < pluginNodes.length; i++) {
         context = DOMNodeAdapter.getFullContext(pluginNodes[i]); // context looks like: /a/b
         path = DOMNodeAdapter.getFullPath(pluginNodes[i]); // path looks like: /a/b/plugin_name
         tagName = pluginNodes[i].getLocalName(); // is the plugin_name

         try {
            if (print) {
               System.out.println(
                     "AbstractPluginTreeBuilder: creating plugin instance for: " +
                     tagName);
            }
         
            // Ask the plug-in manager to create a plugin for the specificed tag,
            // having pluginNodes[] as children
            plugin = plugManager.createMOPluginInstance(si, sub, tagName, pluginNodes[i]);
         
         } catch (PluginManagerException ex) {
            System.out.println("Error when querying plugin: " +
                               pluginNodes[i].getLocalName() +
                               "\n\n" + ex);
         }

         if (plugin != null) {
            if (context.equals(myRootContext)) {
               // The root plugin, usually the <subscription>, <notification> or
               // others tag, will inform its correspondent PluginRecord when the
               // evaluation is over.
               if (print)
                  System.out.println("AbstractPluginTreeBuilder: assigning this plug-in as root.");
               rootPlugin = plugin;
            } else {
               if (print)
                  System.out.println("AbstractPluginTreeBuilder: assigning this plug-in as child.");
               // Are there any plugin I need to report to?
               // Search for the "father" of its context
               MOPluginInterface father = (MOPluginInterface) pluginLookupTable.get(
                     context);
               if (father != null) {
                  // makes the father a subscriber of the events of this plugin.

                  if (print) {
                  	System.out.println("AbstractPluginTreeBuilder: adding '"+plugin.getTag()+"' as required by: '"+father.getTag()+"'");
                  }

                  plugin.addListener(father);
                  father.addRequiredPlugin(plugin);
               } else {
                  if (print)
                  System.out.println("AbstractPluginTreeBuilder: no father found, doing nothing with this plugin.");
               }
            }

            // Add new plugin, with its context, to the table for future reference by this parser
            pluginLookupTable.put(path, plugin);
         } else {
            if (print)
               System.out.println("AbstractPluginTreeBuilder: plugin manager returned null for this plug-in creation");
         }

      }

      return rootPlugin;
   }

   /**
    * Parses a generic message object, containing a valid parsed
    * DOM tree, and return the plug-in structured built. It provides a common
    * source plug-in that all leaf plug-ins need to subscribe to. This method
    * is used to merge plug-in evaluation trees, as the case with notification
    * and subscription subtrees.
    * @param si TODO
    * @param sub TODO
    * @param tree is the DOM tree to be parsed
    * @param commonSource is a plug-in that all leafs must subscribe to.
    * @return the root plugin interface.
    **/
   public MOPluginInterface parse(SubscriberInterface si,
                                SubscriptionInterface sub, org.w3c.dom.Node tree, MOPluginInterface commonSource) throws
         ParserException {

      if (tree == null) {
         throw new ParserException(
               "AbstractPluginTreeBuilder: null message provided!");
      }

      MOPluginInterface parsedTree = parse(si, sub, tree);
      addCommonSourceToLeafs(parsedTree, commonSource);

      return parsedTree;
   }

   /**
    *
    * @param pluginNode is the node or subtree that will have a commonSource added to it. In other
    * words, is the node that will become a listener to the commonSource in case it is a leaf.
    * @param commonSource is the node to be set as required by the leafs of pluginNode
    */
   private void addCommonSourceToLeafs(MOPluginInterface pluginNode, MOPluginInterface commonSource) {
      if (! pluginNode.hasChildren()) {
         if (print) {
            System.out.print("AbstractPluginTreeBuilder: adding " +
                               commonSource.getTag() + " under ");
            System.out.println(pluginNode.getTag());
         }
         commonSource.addListener(pluginNode);
         pluginNode.addRequiredPlugin(commonSource);
      } else {
         MOPluginInterface[] subtrees = pluginNode.getRequiredPluginsList();
         for (int i = 0; i < subtrees.length; i++) {
            addCommonSourceToLeafs(subtrees[i], commonSource);
         }
      }
   }


}
