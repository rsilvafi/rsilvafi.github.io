/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.server.dispatcher.siena;

/**
 * <p>Title: Yancees SienaEvent Server</p>
 * <p>Description: Yet ANother Configurable Extensible SienaEvent Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.core.MessageParsingException;
import edu.uci.isr.yancees.util.DOMParser;

/**
 *  An event
 *
 *  An event is structured as a set of named and typed bodyAttributes.  Attribute
 *  names are strings. <p>
 *
 *  A valid attribute name must begin with a letter
 *  (<code>'a'</code>-<code>'z'</code>,
 *  <code>'A'</code>-<code>'Z'</code>) or an underscore character
 *  (<code>'_'</code>), and may contain only letters, underscores,
 *  digits (<code>'0'</code>-<code>'9'</code>), the dot character
 *  (<code>'.'</code>), the forward slash character
 *  (<code>'/'</code>), and the dollar sign
 *  (<code>'$'</code>). Attribute names must be unique within a
 *  <code>SienaEvent</code>.  <p>
 *
 *  Example:
 *  <p>
 *  <pre><code>
 *      SienaEvent alert = new SienaEvent();
 *      alert.putAttribute("threat", "virus");
 *      alert.putAttribute("name", "melissa");
 *      alert.putAttribute("total_infected", 25);
 *      alert.putAttribute("os/name", "win32");
 *      alert.putAttribute("os/version", "98");
 *  </pre></code>
 *
 **/
public class OldSienaEvent implements EventInterface {

	private Map bodyAttributes; //  Map of AttValue elements
	private Map headerAttributes; //  Map of AttValue elements

	/** Tags used from the event to express siena constraints.
	 * these tags are imported from the sienaEvent.xsd schema and used in the
	 * sienaSubscriptin.xsd
	 */
	public static final String EVENT          = "event";
	public static final String BODY           = "body";
	public static final String HEADER         = "header";
	public static final String NAME           = "name";
	public static final String VALUE          = "value";
	public static final String ATTRIBUTE      = "attribute";
	public static final String TYPE_ATTRIBUTE = "type"; // XML elemnt attribute

	private Node eventDOM;
	private Document currentDoc;
	
	private Date dateCreated;
	private Date dateReceivedInServer;

	private  boolean print = edu.uci.isr.yancees.YanceesProperties.getInstance().PRINT_DEBUG;

	private static long globalID = 0;
	private long id; // local id

	/**
	 * Reset or initialize the body and header attributes array.
	 */
	private void initialize() {
		bodyAttributes = new TreeMap();
		headerAttributes = new TreeMap();
		//eventDOM = buildEventDOM();
	}

	/**
	 *  constructs an empty SienaEvent.
	 **/
	public OldSienaEvent() {
		OldSienaEvent.globalID++;
		this.id = globalID;
		this.dateCreated= new Date();
		this.dateReceivedInServer= null;
		
		initialize();
	}

	/**
	 * initialized the current object using the generic event provided.
    * In other words, gets a generic event and initializes this specific SienaEvent.
    * Searches the already parsed DOM tree and extracts the attributes and values.
	 * @param evt is an object of type Event which will be narrowed and parsed
	 * according to the SienaEvent representation.
	 **/
	public OldSienaEvent(EventInterface evt) {
		OldSienaEvent.globalID++;
		this.id = globalID;
	   this.dateCreated=evt.getDateCreated();
	   this.dateReceivedInServer=evt.getDateReceivedInServer();
	   
		initialize();
		try {
			DOMParser parser = new DOMParser();
			parser.setXMLContent(evt.getXMLTextContent());
			
			extractAttributes(parser.getDocument());
		} catch (MessageParsingException ex) {
			System.out.println(
				"SienaEvent: Error when extractiong attributes from provided Event.");
			System.out.println(ex);
		}

	}

	/**
	 * initialized the current object using the generic event represented in the
	 * form of a DOM tree.
	 **/
	public OldSienaEvent(org.w3c.dom.Node n) throws MessageParsingException {
		OldSienaEvent.globalID++;
		this.id = globalID;
		this.dateCreated= new Date();
		this.dateReceivedInServer= null;

		initialize();
		extractAttributes(n);
	}

	public long getId() {
		return id;
	}

	/**
	 * Changes current event node, parsing it.
	 * @param n
	 * @throws EventParsingException
	 */
	public void setDOM(org.w3c.dom.Node n) throws MessageParsingException {
		initialize();
		eventDOM = n;
		currentDoc = eventDOM.getOwnerDocument();
		extractAttributes(n);
	}

	/**
	 *
	 * @return a reference to the current eventDOM model tree.
	 */
	public org.w3c.dom.Node getDOM() {
		this.checkDOMTree(); // if the DOM tree is empty, an empty XML document is buit 
		return eventDOM;
		
	}

	/**
	 * Extracts the attributes from the body and header from the given DOM tree
	 * @param n DOM tree to be processed, having its attributes extracted.
	 */
	private void extractAttributes(org.w3c.dom.Node node)
		throws MessageParsingException {

		Node eventSubtree = null;

		/**
		 * Makes sure the DOM corresponds to a valid event representation.
		 */
		if (node.getNodeName().endsWith(":" + EVENT)
			|| node.getNodeName().equals(EVENT)) {
			eventSubtree = node;
			parseEvent(eventSubtree);
			// a subscription in siena is a pattern or a filter.
		} else {
			if (node.hasChildNodes()) {
				NodeList list = node.getChildNodes();
				//System.out.println("Tree has : "+list.getLength()+" children");
				for (int i = 0; i < list.getLength(); i++) {
					Node myNode = list.item(i);
					//System.out.println("Checking for : "+myNode.getNodeName());
					if (myNode.getNodeName().endsWith(":" + EVENT)
						|| myNode.getNodeName().equals(EVENT)) {
						eventSubtree = myNode;
						//System.out.println("Found : "+myNode.getNodeName());
						break;
					}
				}
				if (eventSubtree == null) {
					throw new MessageParsingException(
						"Could not find a <event> node "
							+ "in tree headed by :"
							+ node.getNodeName());
				}
			}
			//System.out.println("Found 'subscription' node. Parsing it...");
			parseEvent(eventSubtree);
		}
	}

	/**
	 * Parses a subtree headed by <event> tag.
	 * We assume that the XML DOM tree is gramatiacally correct.
	 *
	 * @param node is the reference to a DOM subtree head representing an event
	 */
	private void parseEvent(org.w3c.dom.Node node) {
		if (node.hasChildNodes()) {
			NodeList list = node.getChildNodes();
			//System.out.println("Tree has : "+list.getLength()+" children");
			for (int i = 0; i < list.getLength(); i++) {
				Node myNode = list.item(i);
				if (myNode.getNodeName().startsWith(BODY)
					|| myNode.getNodeName().endsWith(":" + BODY)) {
					parseBody(myNode);
				} else if (
					myNode.getNodeName().startsWith(HEADER)
						|| myNode.getNodeName().endsWith(":" + HEADER)) {
					parseHeader(myNode);
				}

			}
		}

	}

	/**
	 * Poppulates the bodyAttributes map with AttValue objects
	 * @param node is the DOM tree reference to a <body> node.
	 */
	private void parseBody(org.w3c.dom.Node node) {

		bodyAttributes = new TreeMap();
		if (node.hasChildNodes()) {
			NodeList list = node.getChildNodes();
			//System.out.println("Tree has : "+list.getLength()+" children");
			for (int i = 0; i < list.getLength(); i++) {
				Node myNode = list.item(i);
				if (myNode.getNodeName().startsWith(ATTRIBUTE)
					|| myNode.getNodeName().endsWith(":" + ATTRIBUTE)) {
					parseAttribute(myNode, bodyAttributes);
				}

			}
		}

	}

	/**
	 * Poppulates the headerAttributes map with AttValue objects
	 * @param node is the DOM tree reference to a <hedader> node.
	 */
	private void parseHeader(org.w3c.dom.Node node) {

		headerAttributes = new TreeMap();
		if (node.hasChildNodes()) {
			NodeList list = node.getChildNodes();
			//System.out.println("Tree has : "+list.getLength()+" children");
			for (int i = 0; i < list.getLength(); i++) {
				Node myNode = list.item(i);
				if (myNode.getNodeName().startsWith(ATTRIBUTE)
					|| myNode.getNodeName().endsWith(":" + ATTRIBUTE)) {
					parseAttribute(myNode, headerAttributes);
				}

			}
		}

	}

	/**
	 *
	 * @param node is a subtree reference headed by <attribute> tag
	 * @param destinationMap is the destination structure to be poppulated with
	 * AttValue objects represented in this tree.
	 */
	private void parseAttribute(
		org.w3c.dom.Node attributeDOM,
		Map destinationMap) {
		String attributeName = this.parseAttributeName(attributeDOM);
		AttValue value = this.parseAttValue(attributeDOM);
		destinationMap.put(attributeName, value);

	}

	/**
	 * Gets a construction like that:
	 *
	 * <attribute>
	 *   <name> someName </name>
	 *   <value type="someType"> someValue </value>
	 * </attribute>
	 *
	 * and returns the content "someValue", which is between <value> tags.
	       * It also returns the type "someType" in the construction. These are wrapped
	 * in an AttValue object.
	 *
	 */
	private AttValue parseAttValue(org.w3c.dom.Node attributeDOM) {
		if (print) {
			System.out.println("parseAttValue");

		}
		AttValue attVal;
		String valueType;
		String stringValue;

		if (attributeDOM != null) {

			// selects the <value type="blabla"> 1234 <value> tag and
			// extracts its content and type
			NodeList list = attributeDOM.getChildNodes();
			int nodeType;
			Node n;
			for (int i = 0; i < list.getLength(); i++) {
				n = list.item(i);
				nodeType = n.getNodeType();
				if (nodeType == Node.ELEMENT_NODE) {
					if (n.getNodeName().startsWith(VALUE)
						|| n.getNodeName().endsWith(":" + VALUE)) {
						stringValue = parseNodeTextContent(n);
						valueType = parseNodeType(n);
						return new AttValue(stringValue, valueType);
					}
				}
			}

		}

		return null;
	}

	/**
	 * Gets a construction like that:
	 *
	 * <sienaOP>
	 *   <name> someName </name>
	 *   <value> someValue </value>
	 * </sienaOP>
	 *
	 * and returns the content "someName", which is between <name> tags.
	 * null is returned in case the value is not found
	 * sienaOP is one of the valid OPERATORS supported by siena.
	 *
	 */
	private String parseAttributeName(org.w3c.dom.Node attributeDOM) {
		if (print) {
			System.out.println("parseAttributeName");

		}
		if (attributeDOM != null) {

			NodeList list = attributeDOM.getChildNodes();
			int nodeType;
			Node n;
			for (int i = 0; i < list.getLength(); i++) {
				n = list.item(i);
				nodeType = n.getNodeType();
				if (nodeType == Node.ELEMENT_NODE) {
					if (n.getNodeName().startsWith(NAME)
						|| n.getNodeName().endsWith(":" + NAME)) {
						return parseNodeTextContent(n);
					}
				}
			}

		}

		return null;

	}

	/**
	 * @returns the value of the type attribute of a node if it exists, or
	 * null if it was not found.
	 *
	 * In other words, gets a constuction like:
	 *
	 * <tag type="someType"> blablabla </tag>
	 *
	 * and returns "someType", which is the content of the type attribute in the
	 * tag.
	 */
	private String parseNodeType(org.w3c.dom.Node node) {
		if (print) {
			System.out.println("parseNodeType");

		}
		Node tempNode;
		String name;
		if (node.hasAttributes()) {
			NamedNodeMap map = node.getAttributes();
			for (int i = 0; i < map.getLength(); i++) {
				tempNode = map.item(i);
				name = tempNode.getNodeName();
				if (name.equals(TYPE_ATTRIBUTE)
					|| name.endsWith(":" + TYPE_ATTRIBUTE)) {
					return tempNode.getNodeValue();
				}
			}

		}

		return null;
	}

	/**
	 * @return the text 'value' of a node like <element> value <element>
	 * or null in case this value does not exist.
	 */
	private String parseNodeTextContent(org.w3c.dom.Node node) {
		if (print) {
			System.out.println("parseNodeTextContent");
		}
		NodeList list = node.getChildNodes();
		int nodeType;
		Node n;
		for (int i = 0; i < list.getLength(); i++) {
			n = list.item(i);
			nodeType = n.getNodeType();
			if (nodeType == Node.TEXT_NODE) {
				return n.getNodeValue().trim();
			}
		}

		return null;
	}

	/**
	 * Checks if the DOM tree is null, if it is, creates a new one according to
	 * the gramar used here.
	 */
	private void checkDOMTree() {
		if (eventDOM == null) {
			eventDOM = buildEventDOM();
		}
	}

	/**
	 * Builds a new event dom tree with empty body and header. The purpose of this
	 * method is to return a XML document representing the empty event.
	 * @return a new event dom tree with empty header and body
	 */
	private Document buildEventDOM() {

		Document document = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			document = builder.newDocument(); // Create from whole cloth

			Element root = (Element) document.createElement(EVENT);
			document.appendChild(root);
			root.appendChild(document.createElement(HEADER));
			root.appendChild(document.createElement(BODY));

			// normalize text representation
			document.getDocumentElement().normalize();

		} catch (ParserConfigurationException pce) {
			// Parser with specified options can't be built
			System.out.println("SienaEvent: Error when creating a new document");
			System.out.println(pce);

		}

		currentDoc = document;

		return document;
	} // buildEventDOM

	/**
	 *
	 * @param node subtree reference which is a Body or a Header
	 * @param name the name of the attribute
	 * @param value the attribute value (includding the type embedded)
	 */
	private void insertAttribute(
		org.w3c.dom.Node node,
		String name,
		AttValue value) {
		Document doc;

		if (node != null) {
			doc = node.getOwnerDocument();
			Element attributeNode = doc.createElement(ATTRIBUTE);
			Element nameNode = doc.createElement(NAME);
			Element valueNode = doc.createElement(VALUE);

			node.appendChild(attributeNode);
			attributeNode.appendChild(nameNode);
			attributeNode.appendChild(valueNode);

			Node textNode;
			textNode = doc.createTextNode(name);
			nameNode.appendChild(textNode);

			textNode = doc.createTextNode(value.toString());
			valueNode.appendChild(textNode);
			valueNode.setAttribute(TYPE_ATTRIBUTE, value.getAttributeType());

			node.normalize();
		} else {
			System.out.println(
				"cannot insert attribute: "
					+ name
					+ ": "
					+ value
					+ " in null node");
		}

	}

	/**
	 *
	 * @return the <body> element node of the current eventDOM
	 */

	private org.w3c.dom.Node getBodySubtree() {
		Node bodyNode = findSubtree(BODY);

		return bodyNode;
	}

	/**
	 *
	 * @return the <header> element node of the current eventDOM
	 */
	private org.w3c.dom.Node getHeaderSubtree() {
		Node headerNode = findSubtree(HEADER);

		return headerNode;
	}

	/**
	 * removes all the elements under the <header> subtree in this <event>
	 * DOM tree
	 */
	private void clearHeaderSubtree() {
		Node header = getHeaderSubtree();
		NodeList list = header.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			header.removeChild(list.item(i));

		}
	}

	/**
	 * removes all the elements under the <body> subtree in this <event>
	 * DOM tree
	 */
	private void clearBodySubtree() {
		Node body = getHeaderSubtree();
		NodeList list = body.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			body.removeChild(list.item(i));

		}

	}

	/**
	 * searches the current eventDOM for a subtree which ELEMENT_NODE name is
	 * the one provided. null is returned if the search is not successful.
	 * @param element_name is element to search for
	       * @return the ELEMENT_NODE with name element_name or null if it was not found.
	 */
	private org.w3c.dom.Node findSubtree(String element_name) {
		//Node targetNode = null;
		Vector queue = new Vector();

		//System.out.println("findSubtree: looking for: "+element_name);
		//System.out.println("on eventDom "+eventDOM);
		if (eventDOM != null) {

			NodeList list;
			int nodeType;
			Node n = eventDOM;

			queue.add(n);
			while (queue.size() > 0) {
				list = ((Node) queue.get(0)).getChildNodes();
				queue.removeElementAt(0);

				//System.out.println("findSubtree: "+list.getLength()+"  nodes on branch");

				for (int i = 0; i < list.getLength(); i++) {
					n = list.item(i);
					nodeType = n.getNodeType();
					if (nodeType == Node.ELEMENT_NODE) {

						//System.out.println("findSubtree: found element: "+n.getNodeName());

						if (n.getNodeName().startsWith(element_name)
							|| n.getNodeName().endsWith(":" + element_name)) {
							//System.out.println("findSubtree: returning element: "+n.getNodeName());
							return n;
						} else {
							//System.out.println("findSubtree: queueing element: "+n.getNodeName());
							queue.add(n);
						}
					}
				}

			}
		}

		return null;
	}

	/**
	 *  creates a deep copy of a given SienaEvent.
	 **/
	public OldSienaEvent(OldSienaEvent n) {
		bodyAttributes = new TreeMap();

		for (Iterator i = n.bodyAttributes.entrySet().iterator(); i.hasNext();) {
			Map.Entry entry = (Map.Entry) i.next();
			bodyAttributes.put(
				(String) entry.getKey(),
				new AttValue((AttValue) entry.getValue()));
		}

		headerAttributes = new TreeMap();
		for (Iterator i = n.headerAttributes.entrySet().iterator();
			i.hasNext();
			) {
			Map.Entry entry = (Map.Entry) i.next();
			headerAttributes.put(
				(String) entry.getKey(),
				new AttValue((AttValue) entry.getValue()));

		}
		this.eventDOM = n.getDOM();

	}

	/**
	 * @return a list of AttValue objects of the body of the event
	 */
	public AttValue[] getBodyAttValues() {

		Collection c = bodyAttributes.values();
		Object[] elements = c.toArray();
		AttValue[] attVals = new AttValue[elements.length];
		for (int i = 0; i < elements.length; i++) {
			attVals[i] = (AttValue) elements[i];
		}
		return attVals;
	}

	/**
	 * @return a list of AttValue objects of the header of the event
	 */
	public AttValue[] getHeaderAttValues() {

		Collection c = headerAttributes.values();
		Object[] elements = c.toArray();
		AttValue[] attVals = new AttValue[elements.length];
		for (int i = 0; i < elements.length; i++) {
			attVals[i] = (AttValue) elements[i];
		}
		return attVals;

	}

	/**
	 *  set the value of an attribute.
	 *
	 *  Add the attribute if that is not present.
	 *  @param name attribute name.
	 *  @param value String value.
	 **/
	public void putBodyAttribute(String name, String value) {
		checkDOMTree();
		insertAttribute(getBodySubtree(), name, new AttValue(value));
		bodyAttributes.put(name, new AttValue(value));

	}

	/**
	 *  sets the value of an attribute.
	 *
	 *  Add the attribute if that is not present.
	 *  @param name attribute name.
	 *  @param value byte array value.
	 **/
	public void putBodyAttribute(String name, byte[] value) {
		checkDOMTree();
		insertAttribute(getBodySubtree(), name, new AttValue(value));
		bodyAttributes.put(name, new AttValue(value));
	}

	/**
	 *  set the value of an attribute.
	 *
	 *  Add the attribute if that is not present.
	 *  @param name attribute name.
	 *  @param value integer value.
	 **/
	public void putBodyAttribute(String name, long value) {
		checkDOMTree();
		insertAttribute(getBodySubtree(), name, new AttValue(value));
		bodyAttributes.put(name, new AttValue(value));
	}

	/**
	 *  set the value of an attribute.
	 *
	 *  Add the attribute if that is not present.
	 *  @param name attribute name.
	 *  @param value double value.
	 **/
	public void putBodyAttribute(String name, double value) {
		checkDOMTree();
		insertAttribute(getBodySubtree(), name, new AttValue(value));
		bodyAttributes.put(name, new AttValue(value));
	}

	/**
	 *  set the value of an attribute.
	 *
	 *  Add the attribute if that is not present.
	 *  @param name attribute name.
	 *  @param value boolean value.
	 **/
	public void putBodyAttribute(String name, boolean value) {
		checkDOMTree();
		insertAttribute(getBodySubtree(), name, new AttValue(value));
		bodyAttributes.put(name, new AttValue(value));
	}

	/**
	 *  set the value of an attribute.
	 *
	 *  Add the attribute if that is not present.
	 *  @param name attribute name.
	 *  @param value value.
	 **/
	public void putBodyAttribute(String name, AttValue value) {
		checkDOMTree();
		insertAttribute(getBodySubtree(), name, value);
		bodyAttributes.put(name, value);
	}

	/**
	 *  returns the value of an attribute or <code>null</code> if
	 *  that attribute does not exist in this SienaEvent.
	 *
	 *  @param name attribute name.
	 **/
	public AttValue getBodyAttribute(String name) {
		return (AttValue) bodyAttributes.get(name);
	}

	/**
	 *  returns the number of bodyAttributes in this SienaEvent.
	 *
	 *  @param name attribute name.
	 **/
	public int getBodySize() {
		return bodyAttributes.size();
	}

	/**
	 *  set the value of an attribute.
	 *
	 *  Add the attribute if that is not present.
	 *  @param name attribute name.
	 *  @param value String value.
	 **/
	public void putHeaderAttribute(String name, String value) {
		checkDOMTree();
		insertAttribute(getHeaderSubtree(), name, new AttValue(value));
		headerAttributes.put(name, new AttValue(value));
	}

	/**
	 *  sets the value of an attribute.
	 *
	 *  Add the attribute if that is not present.
	 *  @param name attribute name.
	 *  @param value byte array value.
	 **/
	public void putHeaderAttribute(String name, byte[] value) {
		checkDOMTree();
		insertAttribute(getHeaderSubtree(), name, new AttValue(value));
		headerAttributes.put(name, new AttValue(value));
	}

	/**
	 *  set the value of an attribute.
	 *
	 *  Add the attribute if that is not present.
	 *  @param name attribute name.
	 *  @param value integer value.
	 **/
	public void putHeaderAttribute(String name, long value) {
		checkDOMTree();
		insertAttribute(getHeaderSubtree(), name, new AttValue(value));
		headerAttributes.put(name, new AttValue(value));
	}

	/**
	 *  set the value of an attribute.
	 *
	 *  Add the attribute if that is not present.
	 *  @param name attribute name.
	 *  @param value double value.
	 **/
	public void putHeaderAttribute(String name, double value) {
		checkDOMTree();
		insertAttribute(getHeaderSubtree(), name, new AttValue(value));
		headerAttributes.put(name, new AttValue(value));
	}

	/**
	 *  set the value of an attribute.
	 *
	 *  Add the attribute if that is not present.
	 *  @param name attribute name.
	 *  @param value boolean value.
	 **/
	public void putHeaderAttribute(String name, boolean value) {
		checkDOMTree();
		insertAttribute(getHeaderSubtree(), name, new AttValue(value));
		headerAttributes.put(name, new AttValue(value));

	}

	/**
	 *  set the value of an attribute.
	 *
	 *  Add the attribute if that is not present.
	 *  @param name attribute name.
	 *  @param value value.
	 **/
	public void putHeaderAttribute(String name, AttValue value) {
		checkDOMTree();
		insertAttribute(getHeaderSubtree(), name, new AttValue(value));
		headerAttributes.put(name, value);
	}

	/**
	 *  returns the value of an attribute or <code>null</code> if
	 *  that attribute does not exist in this SienaEvent.
	 *
	 *  @param name attribute name.
	 **/
	public AttValue getHeaderAttribute(String name) {
		return (AttValue) headerAttributes.get(name);
	}

	/**
	 *  returns the number of headerAttributes in this SienaEvent.
	 *
	 *  @param name attribute name.
	 **/
	public int getHeaderSize() {
		return headerAttributes.size();
	}

	/**
	 * returns the number of bodyAttributes in this SienaEvent.
	 *
	 *  @param name attribute name.
	 **/
	public int size() {
		return bodyAttributes.size() + headerAttributes.size();
	}

	/**
	 *  removes every body attribute from this SienaEvent.
	 **/
	public void clearBody() {
		bodyAttributes.clear();
		clearBodySubtree();
	}

	/**
	 *  Removes every header attribute from this SienaEvent.
	 **/
	public void clearHeader() {
		headerAttributes.clear();
		clearHeaderSubtree();
	}

	/**
	 *  Removes every attribute from this SienaEvent.
	 **/
	public void clearAll() {
		bodyAttributes.clear();
		headerAttributes.clear();
		eventDOM = buildEventDOM();
	}

	/**
	 * Returns an iterator for the set of attribute names of this
	 *	SienaEvent body.
	 **/
	public Iterator getBodyAttributeNamesIterator() {
		return bodyAttributes.keySet().iterator();
	}

	/**
	 *  returns an iterator for the set of attribute names of this
	 *	SienaEvent header.
	 **/
	public Iterator getHeaderAttributeNamesIterator() {
		return headerAttributes.keySet().iterator();
	}

	/**
	 * Prints the structure of the evetn using a free notation.
	 */
	public String toString() {
		StringBuffer sb = new StringBuffer();

		sb.append("\nEVENT:\n\n");

		sb.append("HEADER:\n");

		for (Iterator i = headerAttributes.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			sb.append(key);
			sb.append(" = ");
			sb.append((AttValue) headerAttributes.get(key));
			sb.append('\n');
		}

		sb.append("BODY:\n");
		for (Iterator i = bodyAttributes.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			sb.append(key);
			sb.append(" = ");
			sb.append((AttValue) bodyAttributes.get(key));
			sb.append('\n');
		}

		return sb.toString();
	}

	/**
	 * Prints the XML hierarchy that represents the current event.
	 */
	public String toXML() {
		StringBuffer sb = new StringBuffer();
		sb.append("<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n");
		sb.append(
			"<event "
				+ "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n"
				+ "       xsi:noNamespaceSchemaLocation=\"sienaEvent.xsd\">\n");

		sb.append("   <header>\n");

		for (Iterator i = headerAttributes.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			String ident = "      ";
			String step = "   ";
			sb.append(ident + "<attribute>\n");
			sb.append(ident + step + "<name>\n");
			sb.append(ident + step + step + key + '\n');
			sb.append(ident + step + "</name>\n");
			sb.append(ident + step + "<value");
			sb.append(
				" type = \""
					+ ((AttValue) headerAttributes.get(key)).getAttributeType()
					+ "\"");
			sb.append(">\n");
			sb.append(
				ident + step + step + (AttValue) headerAttributes.get(key) + '\n');
			sb.append(ident + step + "</value>\n");
			sb.append(ident + "</attribute>\n");
			sb.append('\n');

		}
		sb.append("   </header>\n");

		sb.append("   <body>\n");
		for (Iterator i = bodyAttributes.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			String ident = "      ";
			String step = "   ";
			sb.append(ident + "<attribute>\n");
			sb.append(ident + step + "<name>\n");
			sb.append(ident + step + step + key + '\n');
			sb.append(ident + step + "</name>\n");
			sb.append(ident + step + "<value");
			sb.append(
				" type = \""
					+ ((AttValue) bodyAttributes.get(key)).getAttributeType()
					+ "\"");
			sb.append(">\n");
			sb.append(
				ident + step + step + (AttValue) bodyAttributes.get(key) + '\n');
			sb.append(ident + step + "</value>\n");
			sb.append(ident + "</attribute>\n");
			sb.append('\n');
		}
		sb.append("   </body>\n");
		sb.append("</event>\n");

		return sb.toString();

	}

	/**
	* Changes the content of this message. Replaces it with the XML content
	* provided in the String provided
	* @param content is the new XML format contnet in the form of a String
	*/
	public void setXMLTextContent(String content) {
		/**@todo Implement this method*/
		throw new java.lang.UnsupportedOperationException(
			"Method setXMLTextContent() not yet implemented.");
	}

	/**
	 * @return the content of this message in the text form, as a string.
	 */
	public String getXMLTextContent() {
		return toXML();
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public Date getDateReceivedInServer() {
		return dateReceivedInServer;
	}

}