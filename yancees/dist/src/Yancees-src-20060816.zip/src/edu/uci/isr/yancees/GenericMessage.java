/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package edu.uci.isr.yancees;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;
import java.util.Random;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import edu.uci.isr.yancees.core.MessageParsingException;
import edu.uci.isr.yancees.util.DOMNodeAdapter;
import edu.uci.isr.yancees.util.DOMParser;

public class GenericMessage implements MessageInterface {

	transient protected Node messageDOM; // is the content in DOM format
	protected String textContent; // is the content in textual XML format.

	/**
	 * In order to have the proper comparison between dates, timezone differences
	 * must be considered here.
	 */
	protected Date dateCreated;
	protected Date dateReceivedInServer;
	
	private static long globalID = 0;

	protected long myId; // the unique id that identifies this object

	private final String tempDir = ".";
	//private final String alternativeTempDir = ".";
	private final String tempFileName = "Message";
	private final String tempSufix = ".tmp";

	private static Random generator = new Random((new Date()).getTime());

	public GenericMessage(Node n) throws MessageParsingException {

		if (n == null) {
			throw new MessageParsingException("Message: null DOMTree provided");
		}
		//message = n.cloneNode(true);
		messageDOM = n;
		// for performance reasons, does not compute textContent until it is needed (if any)
		textContent = null;
		initialize();

	}

	public GenericMessage() {
		super();
		textContent = null;
		messageDOM = null;
		initialize();
		// all variables should be null here
		
	}
	
	/**
	 * Initializes the message with a file. Do not parse it so it can be
	 * exchanged remotely.
	 * @param file is the XML file having the message text content.
	 */
	public GenericMessage(File file) throws IOException {

		textContent = getFileContent(file);
		// message DOM Tree is computed only when necessary
		messageDOM = null;
		initialize();

	}

	/**
	 * Initializes the file with the content provided in a String
	 * We assume that the String has a XML message able to be parsed
	 * @param content
	 */
	public GenericMessage(String content) {
		textContent = content;
		// message DOM Tree is computed only when necessary, by the subclasses of this class
		messageDOM = null;

		initialize();

	}

	/**
	 * Computes the ID and the creation timestamp. These values can be overwritten
	 * by the methods setID() and setCreationDate(). This happens when an event is
	 * sent from a producer and arrives in the server through the dispatcher. Since a new
	 * instance of the event needs to be created locally, this value is lost. Hence, the
	 * need for transporting it in the body of the event, as metainfo, and then setting
	 * it back in the event.
	 */
	private void initialize() {	
		dateCreated = new Date();
		myId = dateCreated.getTime();
		
		dateReceivedInServer = null;
	}

	/**
	 * Changes the content of this Message object to the message tree provided.
	 */
	public void setDOM(Node n) throws MessageParsingException {
		messageDOM = n;
		textContent = null; // invalidate the text content
	}

	/**
	 * @return a data structure in memory having the Document Object Model of this
	 * message.
	 */
	public Node getDOM() {
		if (messageDOM == null && textContent != null) {
			// we need to update the message DOM tree with the new file, which text
			// content is in memory right now.

			
			messageDOM = convertTextToMessageDOM(textContent);
		}

		return messageDOM;
	}


	/**
	 * Writes the text to a temp file, with a special name and in the global 
	 * temporary directory
	 * @param text the text to be written
	 * @return the path of the file created so it can be opened and used elsewhere
	 */
	protected String writeTextToTempFile(String text) {
		
		// creates the temp directory if necessary.
		File tempDirDirectory = new File(tempDir);
		boolean created;
		if (! tempDirDirectory.exists()) {
			 created = tempDirDirectory.mkdir();
			 if (!created) {
				System.out.println("GenericMessage: could not create temp dir: "+tempDir);
				System.out.println("This is necessary to serialize the events in XML");
			 }
			 	
		}
			
		//	the file name is created here in order to get a random name, based on the
		// time this method is called.
		String tempFilePath =
			tempDir
				+ "/"
				+ tempFileName
				+ "_"
				+ myId
				+ "_"
				+ generator.nextInt()
				+ tempSufix;
		File tempFile = new File(tempFilePath);
		try {
			writeFileContent(tempFile, text);
		} catch (IOException ex) {
			System.out.println(ex);
		}
		
		return tempFilePath;
	}

	/**
	 * Writes the contents of the file in memory to the disk, in a temporary
	 * directory, then parses it with a DOM parser, generating a data sturcture
	 * in memory.
	 * 
	 * @param return the document generated
	 *
	 */
	protected Document convertTextToMessageDOM(String text) {
		
		if (text.equals("")) {
			return null;
		}
		
		String tempFilePath = writeTextToTempFile(text);
		// we need to open it again here because it is closed by the writeFileContent method...
		File tempFile = new File(tempFilePath);
		
		DOMParser parser = new DOMParser(tempFile);
		Document tempDOM = parser.getDocument();
		tempFile.delete(); // do not let trash behind...
		
		return tempDOM;
	}
	
	
	

	/**
	 * Changes the content of this message. Replaces it with the XML content
	 * provided in the String provided
	 * @param content is the new XML format contnet in the form of a String
	 * @throws MessageParsingException is thrown if the content is not syntatically correct
	 */
	public void setXMLTextContent(String content) {
		textContent = content;
		messageDOM = null; // invalidate the content
		//messageDOM = getDOM();
	}

	/**
	 * @return the content of this message in the text form, as a string.
	 */
	public String getXMLTextContent() {
		if (textContent == null && messageDOM != null) {
			DOMNodeAdapter adapter = new DOMNodeAdapter(messageDOM);
			// compute the text content now...
			textContent = adapter.toXML();
		}
		return textContent;
	}

	public String toString() {
		return getXMLTextContent();
	}

	/**
	 * Messages have unique ids inside an address space.
	 * @return the unique id for this message
	 */
	public long getId() {
		return myId;
	}

	/**
	 *
	 * @return the local date when this object was created
	 */
	public Date getDateCreated() {
		return dateCreated;
	}

	/**
	 *
	 * @return the data this message reached the server
	 */
	public Date getDateReceivedInServer() {
		return dateReceivedInServer;
	}

	/**
	 * This method is not shown in the MessageInterface and is used internally,
	 * by the Yancees APIs to stamp the date received
	 * @param date is the current time and date
	 */
	public void setDateReceivedInServer(Date date) {
		dateReceivedInServer = date;

		// This solves the problem when the same message is published many times, one
		// after another, and the temporary file name becomes the same. If it was not
		// done, the file was usually closed or deleted before parsing by another thread.
		//tempFilePath = tempDir+"/"+tempFileName+myId+"_"+date.getTime()+"_"+tempSufix;
	}

	//-------------------------- Auxiliary methods ------------------------------

	/**
	 * Reads the content of a text file to a String in memory.
	 * @param file is the file to be read
	 * @return a string with the content of the file
	 * @throws IOException in case of errors
	 */
	private String getFileContent(File file) throws IOException {
		FileReader fileRead = null;
		BufferedReader inFile = null;
		String s;
		StringBuffer sb = new StringBuffer();

		fileRead = new FileReader(file);
		inFile = new BufferedReader(fileRead);

		while ((s = inFile.readLine()) != null) {
			sb.append(s + "\n");
		}
		if (fileRead != null)
			fileRead.close();

		return sb.toString();
	}

	/**
	 * Write the content to the destination file. The destintion file is first
	 * erased and then created a new.
	 * @param destination is the destination file
	 * @param content is the content to be written
	 * @throws IOException in case of some error
	 */
	private void writeFileContent(File destination, String content)
		throws IOException {
		//destination.delete();
		destination.createNewFile();
		FileWriter fileWrite = null;
		BufferedWriter outFile = null;
		String s;

		fileWrite = new FileWriter(destination);
		outFile = new BufferedWriter(fileWrite);

		outFile.write(content);
		outFile.flush();
		outFile.close();
	}

	//--------------------------- Object Serialization methods -----------------

	/**
	 * This method is invoked by the JVM when this object is serialized
	 * @param out
	 * @throws IOException
	 */
	private void writeObject(ObjectOutputStream out) throws IOException {
		// We will make sure that we have the XML TextVersion of the
		// DOM Tree this object is using before it gets serialized. Otherwise,
		// we will loose the content of the object.

		if (messageDOM != null && textContent == null) {
			textContent = this.getXMLTextContent();
		}
		out.defaultWriteObject();
	}

	/**
	 * This method is automatically invoked by the JVM when this object is
	 * de-serialized.
	 * @param in
	 * @throws IOException
	 * @throws java.lang.ClassNotFoundException
	 */
	private void readObject(ObjectInputStream in)
		throws IOException, ClassNotFoundException {
		// our "pseudo-constructor"
		in.defaultReadObject();

	}

}
