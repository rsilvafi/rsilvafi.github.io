/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.core;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.rmi.RemoteException;
import java.util.HashMap;

import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.plugin.PluginManagerException;
import edu.uci.isr.yancees.plugin.ProtocolPluginInterface;
import edu.uci.isr.yancees.plugin.ProtocolPluginManagerInterface;

/**
 * There is only one instance of subscriptionManager per process (core or client)
 * The protocol manager handles the creation of protocol plug-in instances, to be
 * manipulated by the ProtocolAPI
 */
public class ProtocolManager {
   
   // Unique instance of this singleton.
   private static ProtocolManager myInstance;
   private ProtocolPluginManagerInterface plugManager;
   
   private HashMap activePluginsMap; // associates the protocolId with the plug-in instances.
   
   protected boolean print = edu.uci.isr.yancees.YanceesProperties.getInstance().PRINT_DEBUG;

   /**
    * The only way to access the unique instance of ProtocolManager is by
    * using this access method
    * @return the unique instance of this class.
    */
   public static ProtocolManager getInstance() {
      if (myInstance == null) {
         myInstance = new ProtocolManager();
      }
      return myInstance;
   }

   /**
    * Protected here prevents direct instantiation of this singleton but allows
    * the extension of this class and the invocation of this construction by the
    * specializatio class.
    */
   protected ProtocolManager() {
      super();
      if (print) {
         System.out.println("ProtocolManager: Invoking ProtocolManager constructor...");
      }
      
      activePluginsMap = new HashMap();
   }
   
   /**
    * Configures the plug-in manager to be used in the resoluiton of the tags
    * in the incomming subscriptions.
    * @param pm is the reference to the plug-in manager.
    */
   public void setPluginManager(ProtocolPluginManagerInterface pm) {
      plugManager = pm;
   }
   
   /**
    * This method allows the protocol mananger to share plug-in instances
    * 
    * @param protocolId is the name of the protocol to be created
    * @param si is the subscriber interface that uniquely identifies the caller.
    * @return an instance of the protocol plug-in with the respective name.
    * 
    */
   public ProtocolPluginInterface getSharedPluginInstance(String protocolId, SubscriberInterface si) throws ProtocolManagerException {
      ProtocolPluginInterface pluginInstance;
      pluginInstance = (ProtocolPluginInterface) activePluginsMap.get(protocolId);
      
      if (pluginInstance == null) {
      	try {
            pluginInstance = plugManager.createProtocolPluginInstance(protocolId, si);
            
            // save plug-in instance reference to be sent as response to new calls
            activePluginsMap.put(protocolId, pluginInstance);
         } catch (PluginManagerException e) {
            e.printStackTrace();
            throw new ProtocolManagerException("ProtocolManager: Error when creating a new protocol instance: "+e.toString());
       
         }
      } 
            
      return pluginInstance;
   }
   
   /**
    * Creates a new instance of a protocol plug-in
    * @param protocolId is the name of the protocol object to create
    * @return an unshared protocol object instance
    * @throws ProtocolManagerException
    */
   public ProtocolPluginInterface getNewUnsharedPluginIntance(String protocolId, SubscriberInterface si) throws ProtocolManagerException {
      ProtocolPluginInterface pluginInstance;
      
      try {
         pluginInstance = plugManager.createProtocolPluginInstance(protocolId, si);
      } catch (PluginManagerException e) {
         e.printStackTrace();
         throw new ProtocolManagerException("ProtocolManager: Error when creating a new protocol instance: "+e.toString()); 
      }
      
      return pluginInstance;
   }
   
   /**
    * Terminates a shared plug-in instance. This method must be called when the plug-in
    * is no longer necessary. The unshared protocol instances are automatically 
    * terminated.
    * @param pi is a reference to the protocol plug-in to be terminated
    */
   public void terminateSharedProtocolPluginInstance(ProtocolPluginInterface pi) {
   	try {
			activePluginsMap.remove(pi.getTag());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   }
   
}