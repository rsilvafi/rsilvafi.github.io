/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.server.plugin.protocol.polling;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.util.Vector;

import org.w3c.dom.Node;

import edu.uci.isr.yancees.ArchitectureManager;
import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.GenericEvent;
import edu.uci.isr.yancees.MessageInterface;
import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.core.ActivePluginInstancesRegistry;
import edu.uci.isr.yancees.plugin.AbstractMOPlugin;
import edu.uci.isr.yancees.plugin.MOPluginInterface;
import edu.uci.isr.yancees.plugin.PluginException;
import edu.uci.isr.yancees.server.plugin.notification.pull.PullPlugin;
import edu.uci.isr.yancees.util.DOMNodeAdapter;
import edu.uci.isr.yancees.util.DOMParser;

public class MOPollProtocolPlugin
      extends AbstractMOPlugin {

   boolean print = edu.uci.isr.yancees.YanceesProperties.getInstance().PRINT_DEBUG;

   private final String PULL_TAG = "pull"; // notification plugin tag to search for
   private final String POLL_TAG = "poll"; // this protocol plug-in tag

   private final String POLL_INTERVAL = "pollInterval";
   private final String POLL_COMMAND_TAG = "command";
   private final String COMMAND_START = "start";
   private final String COMMAND_STOP = "stop";
   private final String COMMAND_PAUSE = "pause";
   private final String COMMAND_RESUME = "resume";

   private int pollInterval = 1000;
   private String lastCommand = null;
   private PollingMechanism pollThread;

   private boolean started = false;

   /**
    * @param subTree is the DOM tree this plugin is responsible for executing
    * evalutation of this plugin is published.
    */
   public MOPollProtocolPlugin(Node subTree) {
      super(subTree);

      if (print) {
         System.out.println("PollPlugin: new instance...");
      }

   }

   /**
    * Receives a notification from another plug-in
    * @param evt is the event received
    * @param source is the plug-in sending the notification.
    */
   public void receivePluginNotification(EventInterface evt, MOPluginInterface source) {
      if (print) {
         System.out.println("PollPlugin: got a plugin notification...");
      }
      publishOutput(evt);
   }

   /**
    * Receives a list of events as notifications from another plug-in
    * @param evtList is the list of events received
    * @param source is the plug-in sending the notification.
    **/
   public void receivePluginNotification(EventInterface[] evtList,
                                         MOPluginInterface source) {

      if (print) {
         System.out.println(
               "PollPlugin: got plugin notification with multiple events...");
      }
      publishOutput(evtList);
   }

   //--------------------------- Protocol plug-in specific ---------------------
   /**
    * Gracefully terminates the current plugin as a result of the end of the
    * communicatoin session.
    */
   public void terminateSession() {
      pollThread.terminate();
   }

   /**
    * Receive messages from this protocol
    * @param msg is a message according to the protocol that the plug-in implements.
    * @param si is the subscriber that originated the message.
    */
   public void receiveProtocolMessage(MessageInterface msg,
                                      SubscriberInterface si)
         throws PluginException {

	  
	  DOMParser parser = new DOMParser();
	  parser.setXMLContent(msg.getXMLTextContent());
	  
      DOMNodeAdapter adapt = new DOMNodeAdapter(parser.getDocument());
      Node pollNode = adapt.getFirstElementByName(POLL_TAG);

      if (print)
         System.out.println("PollProtocolPlugin: Receiving protocol message...");

      if (pollNode == null) {
         throw new PluginException(
               "PollProtocolPlugin: Could not find <" + POLL_TAG +
               "> in provided message");
      }

      adapt = new DOMNodeAdapter(pollNode);
      Node pollIntervalNode = adapt.getFirstElementByName(POLL_INTERVAL);
      if (pollIntervalNode != null) {
         adapt = new DOMNodeAdapter(pollIntervalNode);
         pollInterval = Integer.parseInt(adapt.getNodeText());
      }

      adapt = new DOMNodeAdapter(pollNode);
      Node commandNode = adapt.getFirstElementByName(POLL_COMMAND_TAG);
      String command = null;
      if (commandNode != null) {
         adapt = new DOMNodeAdapter(commandNode);
         command = adapt.getNodeText();
      }

      if (command != null) {
         lastCommand = command;

         if (command.equals(COMMAND_START)) {
            if (! started) {
               if (print)
                  System.out.println(
                        "PollProtocolPlugin: Performing START command...");
               pollThread = new PollingMechanism(pollInterval, si, this);
               pollThread.start();
               started = true;
            }

         } else if (command.equals(COMMAND_PAUSE)) {
            if (started) {
               if (print)
                  System.out.println(
                        "PollProtocolPlugin: Performing PAUSE command...");
               pollThread.pausePolling();
            }

         } else if (command.equals(COMMAND_RESUME)) {
            if (started) {
               if (print)
                  System.out.println(
                        "PollProtocolPlugin: Performing RESUME command...");
               pollThread.resumePolling();
            }

         } else if (command.equals(COMMAND_STOP)) {
            if (print)
               System.out.println("PollProtocolPlugin: Performing STOP command...");
            pollThread.terminate();
         }
      }
   }

   /**
    *
    * Implements a thread that periodically polls all the pull plug-ins under the
    * provides subscriber interface and publishes the output of this plug-in using
    * the events stored in the pull plug-ins.
    */
   protected class PollingMechanism
         extends Thread {

      private SubscriberInterface subscriber = null;
      private int pollInterval = 1000; //default value
      private boolean paused = false;
      private MOPollProtocolPlugin plugin;
      private boolean terminated = false;

      // constructor
      public PollingMechanism(int interval, SubscriberInterface si,
                              MOPollProtocolPlugin ownerPlugin) {
         pollInterval = interval;
         subscriber = si;
         plugin = ownerPlugin;

      }

      /**
       * Infinite loop that collects the events for the current subscriber, periodically,
       * according to the pollInterval. It publishes the output using the appropriate plug-in
       * method.
       */
      public void run() {
         if (print)
            System.out.println("PollingMechanism: starting main loop");

         while (!terminated) {

            try {
               if (print)
                  System.out.println("PollingMechanism: sleeping for "+pollInterval+"s");
               Thread.sleep(pollInterval);
            } catch (InterruptedException ex) {
               System.out.println("PollProtocolPlugin: error when sleeping...");
               System.out.println(ex);
            }

            if (!paused) {
               GenericEvent[] events = collectPullEvents();
               plugin.publishOutput(events);
            }
         }

      }

      /**
       * Colelcts all the evens stored in pull plug-ins for the current subscriber
       * @return the list of events stored in the server (pull notificatoin plug-ins) for
       * the current subscriber.
       */
      private synchronized GenericEvent[] collectPullEvents() {
         GenericEvent[] output;
         Vector outputList = new Vector(0);

         if (print)
            System.out.println("PollingMechanism: Collecting pull events...");

         ActivePluginInstancesRegistry treesDB = ArchitectureManager.getInstance().
               getActiveSubscriptionTreesDB();

         if (print)
            System.out.println("PollingMechanism: querying active trees DB...");

         MOPluginInterface[] pullNotificationInstances = treesDB.getActivePlugins(
               this.subscriber, PULL_TAG);

         PullPlugin pullPlugin;

         if (print)
            System.out.println("PollingMechanism: Found "+ pullNotificationInstances.length+" pull plug-ins for this subscriber...");

         for (int i = 0; i < pullNotificationInstances.length; i++) {
            pullPlugin = (PullPlugin) pullNotificationInstances[i];
            outputList.addAll(pullPlugin.poll()); // collect the events
         }

         output = new GenericEvent[outputList.size()];
         outputList.copyInto(output);

         if (print)
            System.out.println("PollingMechanism: Collected "+output.length+" events");

         return output;
      }

      public void pausePolling() {
         paused = true;
      }

      public void resumePolling() {
         paused = false;
      }

      public void setPollInterval(int interval) {
         pollInterval = interval;
      }

      public void setSubscriber(SubscriberInterface si) {
         subscriber = si;
      }

      public void terminate() {
         terminated = true;
      }

   } // PollingMechanism

}