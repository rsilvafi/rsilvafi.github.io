/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.util;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.util.Vector;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * This class wraps a DOM node and returns the text we want to
 * display in the tree. It also returns children, index values,
 * and child counts.
 *
 * This class is used by the Managers, by the Event class and others to perform
 * common operations around the DOM tree.
 */

public class DOMNodeAdapter {

   private boolean print = edu.uci.isr.yancees.YanceesProperties.getInstance().PRINT_DEBUG;
   private boolean VALIDATING = edu.uci.isr.yancees.YanceesProperties.getInstance().PERFORM_XML_VALIDATION;

   // An array of names for DOM node-types
   // (Array indexes = nodeType() values.)
   final String[] typeName = {
         "none",
         "Element",
         "Attr",
         "Text",
         "CDATA",
         "EntityRef",
         "Entity",
         "ProcInstr",
         "Comment",
         "Document",
         "DocType",
         "DocFragment",
         "Notation",
   };

   static final int ELEMENT_TYPE = Node.ELEMENT_NODE;
   static final int ATTR_TYPE = Node.ATTRIBUTE_NODE;
   static final int TEXT_TYPE = Node.TEXT_NODE;
   static final int CDATA_TYPE = Node.CDATA_SECTION_NODE;
   static final int ENTITYREF_TYPE = Node.ENTITY_REFERENCE_NODE;
   static final int ENTITY_TYPE = Node.ENTITY_NODE;
   static final int PROCINSTR_TYPE = Node.PROCESSING_INSTRUCTION_NODE;
   static final int COMMENT_TYPE = Node.COMMENT_NODE;
   static final int DOCUMENT_TYPE = Node.DOCUMENT_NODE;
   static final int DOCTYPE_TYPE = Node.DOCUMENT_TYPE_NODE;
   static final int DOCFRAG_TYPE = Node.DOCUMENT_FRAGMENT_NODE;
   static final int NOTATION_TYPE = Node.NOTATION_NODE;

   // identifies a type attribute in an element
   public static final String TYPE_ATTRIBUTE = "type";

   // an xml file can be represented as a set of elements nested within one
   // another, as a filesystem folder/file hierarchy.
   // this is used to separate each one of these contexts in a full element path
   public static final String CONTEXT_SEPARATOR = "/";

   boolean filterNodes = false;

   // The list of elements to display in the tree
   String[] visibleTreeElementNames = {
         ""}; // initially empty

   org.w3c.dom.Node domNode; // The DOM node being wrapped by this class.

   // Construct an Adapter node from a DOM node
   public DOMNodeAdapter(org.w3c.dom.Node node) {
      domNode = node;
   }

   /**
    * @param node is the head of the subtree
    * @param validNames is the visibleTreeElementNames
    */
   public DOMNodeAdapter(org.w3c.dom.Node node, String[] validNames) {
      domNode = node;
      visibleTreeElementNames = validNames;
   }

   /**
    * @param node is the head of the subtree
    * @param validNames is the visibleTreeElementNames
    */
   public DOMNodeAdapter(org.w3c.dom.Node node, String[] validNames,
                         boolean doFilter) {
      domNode = node;
      visibleTreeElementNames = validNames;
      filterNodes = doFilter;
   }

   /**
    * Return a string that identifies this node in the tree
    */
   public String toString() {
      String s = typeName[domNode.getNodeType()];
      String nodeName = domNode.getNodeName();
      if (!nodeName.startsWith("#")) {
         s += ": " + nodeName;
      }
      if (filterNodes) {
         String t = getHTMLContent().trim();
         int x = t.indexOf("\n");
         if (x >= 0) {
            t = t.substring(0, x);
         }
         s += " " + t;
         return s;
      }
      if (domNode.getNodeValue() != null) {
         if (s.startsWith("ProcInstr")) {
            s += ", ";
         } else {
            s += ": ";
            // Trim the value to get rid of NL's at the front
         }
         String t = domNode.getNodeValue().trim();
         int x = t.indexOf("\n");
         if (x >= 0) {
            t = t.substring(0, x);
         }
         s += t;
      }
      return s;
   }

   /**
    * Prints the HTML content of the current Node.
    * You can probably use it to display the current node content in a web
    * browser.
    */
   public String getHTMLContent() {
      String s = "";
      org.w3c.dom.NodeList nodeList = domNode.getChildNodes();
      for (int i = 0; i < nodeList.getLength(); i++) {
         org.w3c.dom.Node node = nodeList.item(i);
         int type = node.getNodeType();
         DOMNodeAdapter adpNode = new DOMNodeAdapter(node,
               visibleTreeElementNames, filterNodes);
         if (type == ELEMENT_TYPE) {
            // Skip subelements that are displayed in the tree.
            if (isTreeElement(node.getNodeName())) {
               //System.out.println("node: "+node.getNodeName()+" is a tree element");

               // EXTRA-CREDIT HOMEWORK:
               //   Special case the SLIDE element to use the TITLE text
               //   and ignore TITLE element when constructing the tree.

               // EXTRA-CREDIT
               //   Convert ITEM elements to html lists using
               //   <ul>, <li>, </ul> tags

               s += "<" + node.getNodeName() + ">";
               s += adpNode.getHTMLContent();
               s += "</" + node.getNodeName() + ">";
            } else {
               //System.out.println("node: "+node.getNodeName()+" is NOT a tree element");
               s += adpNode.getHTMLContent();
            }
         } else if (type == TEXT_TYPE) {
            s += node.getNodeValue();
         } else if (type == ENTITYREF_TYPE) {
            // The content is in the TEXT node under it
            s += adpNode.getHTMLContent();
         } else if (type == CDATA_TYPE) {
            // The "value" has the text, same as a text node.
            //   while EntityRef has it in a text node underneath.
            //   (because EntityRef can contain multiple subelements)
            // Convert angle brackets and ampersands for display
            StringBuffer sb = new StringBuffer(node.getNodeValue());
            for (int j = 0; j < sb.length(); j++) {
               if (sb.charAt(j) == '<') {
                  sb.setCharAt(j, '&');
                  sb.insert(j + 1, "lt;");
                  j += 3;
               } else if (sb.charAt(j) == '&') {
                  sb.setCharAt(j, '&');
                  sb.insert(j + 1, "amp;");
                  j += 4;
               }
            }
            s += "<pre>" + sb + "\n</pre>";
         }

         // Ignoring these:
         //   ATTR_TYPE      -- not in the DOM tree
         //   ENTITY_TYPE    -- does not appear in the DOM
         //   PROCINSTR_TYPE -- not "data"
         //   COMMENT_TYPE   -- not "data"
         //   DOCUMENT_TYPE  -- Root node only. No data to display.
         //   DOCTYPE_TYPE   -- Appears under the root only
         //   DOCFRAG_TYPE   -- equiv. to "document" for fragments
         //   NOTATION_TYPE  -- nothing but binary data in here
      }
      return s;
   }

   /**
          * @return a list of elements which are visible according to the filter specified
          * with the setVisibleTreeElementNames() method. The answer is given as a list of
    * nodes obtained in a Depth First Search (DFS) search of the tree.
    */
   public Node[] getVisibleElementsDFS() {
      Vector tempVect = new Vector();
      getVisibleElementsDFSAux(domNode, tempVect);
      Node[] nodesList = new Node[tempVect.size()];
      tempVect.copyInto(nodesList);
      return nodesList;
   }

   /**
    * Auxiliary method to get all the visible element nodes using DFS
    * The DFS uses a stack to store the nodes, which is implicitly provided
    * by the recursion stack.
    */
   private void getVisibleElementsDFSAux(Node n, Vector tempList) {
      int type;
      type = n.getNodeType();
      if (type == ELEMENT_TYPE || type == DOCUMENT_TYPE) {
         if (isTreeElement(n.getNodeName())) {
            tempList.add(n);
         }
      }

      NodeList nodeList = n.getChildNodes();
      Node node;
      for (int i = 0; i < nodeList.getLength(); i++) {
         node = nodeList.item(i);
         type = node.getNodeType();
         if (type == ELEMENT_TYPE) {
            // keep searching in subnodes for this element...
            getVisibleElementsDFSAux(node, tempList);
         }
      }

   }

   /**
    * @return a list of elements which are visible according to the filter specified
    * with the setVisibleTreeElementNames() method. The answer is given as a list of
    * nodes obtained in a Breadth first Search (BFS) search of the tree.
    */
   public Node[] getVisibleElementsBFS() {
      Vector tempVect = getVisibleElementsBFSAux(domNode);
      Node[] nodesList = new Node[tempVect.size()];
      tempVect.copyInto(nodesList);
      return nodesList;
   }

   /**
    * Auxiliary method to get all the visible element nodes using BFS
    * In the BFS search, the nodes are searched using a FIFO policy, which is
    * provided by a queue.
    * @param answerList is the list of visible nodes returned
    * @param queue is an auxiliary queue used in the recursion
    * @param node is the subtree examined.
    */
   private Vector getVisibleElementsBFSAux(Node n) {
      Vector queue = new Vector();
      Vector answerList = new Vector();

      int type;
      type = n.getNodeType();

      if (print) {
         System.out.println("DOMNodeAdapter: Node type= " + type);
         System.out.println("DOCUMENT_TYPE = " + DOCUMENT_TYPE);
         System.out.println("ELEMENT_TYPE = " + ELEMENT_TYPE);
      }

      if (n != null && (type == ELEMENT_TYPE || type == DOCUMENT_TYPE)) {
         if (print)
            System.out.println("DOMNodeAdapter: Enqueueing element " +
                               n.getNodeName());
         queue.add(n); // add the first element to the queue
      }

      Node node;
      while (queue.size() > 0) {
         node = (Node) queue.get(0);
         queue.removeElementAt(0);

         if (isTreeElement(node.getNodeName())) {
            answerList.add(node); // keep track of the path
         }

         if (node.hasChildNodes()) {
            NodeList nodeList = node.getChildNodes();
            Node tempNode;

            // Examine each child node and enqueue the ELEMENT_TYPE ones
            for (int i = 0; i < nodeList.getLength(); i++) {
               tempNode = nodeList.item(i);
               type = tempNode.getNodeType();
               if (type == ELEMENT_TYPE) {
                  if (print)
                     System.out.println("DOMNodeAdapter: Enqueueing element " +
                                        tempNode.getNodeName());

                  queue.add(tempNode); // add at the end for future search

               }
            }
         }
      }

      return answerList;

   }

   /**
    * @return the full path name from this node to the very father of the tree
    */
   public String getFullPath() {
      String context = "";
      Node father = domNode;
      while (father.getParentNode() != null) {
         if (context.equals("")) {
            context = father.getLocalName();
         } else {
            context = father.getLocalName() + CONTEXT_SEPARATOR + context;
         }
         father = father.getParentNode();
      }
      return CONTEXT_SEPARATOR + context;
   }

   /**
    * @param child a node to be searched among the immediate chindren of this
    * node.
          * @return the index of a provided node in the current represented node (and its
          * subelements) in this DOMNodeAdapter. Returns -1 if the provided node is not
    * a child of the current node.
    */
   public int index(DOMNodeAdapter child) {
      //System.err.println("Looking for index of " + child);
      int count = childCount();
      for (int i = 0; i < count; i++) {
         DOMNodeAdapter n = this.child(i);
         if (child.domNode == n.domNode) {
            return i;
         }
      }
      return -1; // Should never get here.
   }

   /**
    * Gets the child indexed. If compression is on, considers only nodes
    * of type ELEMENT_TYPE.
          * @param searchIndex is the index of the children of current node to be returned
    * as a DOMNodeAdapter
    */
   public DOMNodeAdapter child(int searchIndex) {
      //Note: JTree index is zero-based.
      org.w3c.dom.Node node =
            domNode.getChildNodes().item(searchIndex);
      if (filterNodes) {
         // Return Nth displayable node
         int elementNodeIndex = 0;
         for (int i = 0; i < domNode.getChildNodes().getLength(); i++) {
            node = domNode.getChildNodes().item(i);
            if (node.getNodeType() == ELEMENT_TYPE
                && isTreeElement(node.getNodeName())
                && elementNodeIndex++ == searchIndex) {
               break;
            }
         }
      }
      return new DOMNodeAdapter(node, visibleTreeElementNames, filterNodes);
   }

   /**
    * Count the number of children of the current node. Counts only
    * the element type nodes.
    */
   public int childCount() {
      if (!filterNodes) {
         // Indent this
         return domNode.getChildNodes().getLength();
      }
      int count = 0;
      for (int i = 0; i < domNode.getChildNodes().getLength(); i++) {
         org.w3c.dom.Node node = domNode.getChildNodes().item(i);
         if (node.getNodeType() == ELEMENT_TYPE
             && isTreeElement(node.getNodeName())) {
            // Note:
            //   Have to check for proper type.
            //   The DOCTYPE element also has the right name
            ++count;
         }
      }
      return count;
   }

   /**
    *
    * @param elementName is the name of the ELEMENT_TYPE node to search
    * @return true if the current node has a child element called elementName
    */
   public boolean hasChildElement(String elementName) {

      NodeList nodesList = domNode.getChildNodes();
      String nodeName;

      for (int i = 0; i < nodesList.getLength(); i++) {
         org.w3c.dom.Node node = nodesList.item(i);

         nodeName = node.getNodeName();
         if (node.getNodeType() == ELEMENT_TYPE
             && (nodeName.equals(elementName)
                 || nodeName.endsWith(":" + elementName)
                 )
             ) {

            if (!filterNodes) {
               return true;
            } else if (filterNodes && isTreeElement(node.getNodeName())) {
               return true;
            } else {
               return false;
            }
         }
      }

      return false;
   }

   /**
    * @return the text 'value' of a node like <element> value <element>
    * or null in case this value does not exist or this operatio does not
    * apply to the current node.
    */
   public String getNodeText() {
      org.w3c.dom.Node node = this.domNode;
      StringBuffer sb = new StringBuffer();

      NodeList list = node.getChildNodes();
      int nodeType;
      Node n;
      for (int i = 0; i < list.getLength(); i++) {
         n = list.item(i);
         nodeType = n.getNodeType();
         if (nodeType == Node.TEXT_NODE) {
            sb.append(n.getNodeValue());
         }
      }

      return sb.toString().trim();
   }

   /**
    * @returns the value of the type attribute of a node if it exists, or
    * null if it was not found.
    *
    * In other words, gets a constuction like:
    *
    * <tag type="someType"> blablabla </tag>
    *
    * and returns "someType", which is the content of the type attribute in the
    * tag.
    */
   private String getNodeType() {
      org.w3c.dom.Node node = this.domNode;

      Node tempNode;
      String name;
      if (node.hasAttributes()) {
         NamedNodeMap map = node.getAttributes();
         for (int i = 0; i < map.getLength(); i++) {
            tempNode = map.item(i);
            name = tempNode.getNodeName();
            if (name.equals(TYPE_ATTRIBUTE) ||
                name.endsWith(":" + TYPE_ATTRIBUTE)) {
               return tempNode.getNodeValue();
            }
         }

      }

      return null;
   }

   /**
    * Searches the current DOM tree recursively looking for elements with
    * the provided name.
    */
   public Node[] getElementsByName(String tagName) {
      Vector tempList = new Vector(0);

      getElementsByNameAux(this.domNode, tagName, tempList);

      // Poppulate the list of nodes
      Node[] list = new Node[tempList.size()];
      tempList.copyInto(list);

      return list;
   }

   /**
    * Recursively adds all the matched nodes to the nodeList vector, returning
    * when the whole subtree is explored.
    * @param subTree is the tree being examined in the moment
    * @param tagName is the name of the ELEMENT_NODEs to be considered
    * @param nodeList is the list containing the answer
    */
   private void getElementsByNameAux(Node subTree, String tagName,
                                     Vector nodeList) {
      if (subTree != null) {

         int type = subTree.getNodeType();
         String nodeName = subTree.getNodeName();

         if (type == Node.ELEMENT_NODE &&
             (nodeName.equals(tagName) || nodeName.endsWith(":" + tagName))
             ) {
            nodeList.add(subTree);
         }

         if (subTree.hasChildNodes()) {
            NodeList nodesToExplore = subTree.getChildNodes();
            for (int i = 0; i < nodesToExplore.getLength(); i++) {
               getElementsByNameAux(nodesToExplore.item(i), tagName, nodeList);
            }

         }
      }

   }

   /**
    * Searches the current DOM tree recursively looking for the first element with
    * the provided name.
    * @return the first occurreence of the provided element or null if not found.
    */
   public Node getFirstElementByName(String tagName) {
      Node initialNode = domNode;
      return getFirstElementByNameAUX(tagName, initialNode);
   }

   private Node getFirstElementByNameAUX(String tagName, Node subTree) {

      if (subTree != null) {

         int type = subTree.getNodeType();
         String nodeName = subTree.getNodeName();

         if (type == Node.ELEMENT_NODE &&
             (nodeName.equals(tagName) || nodeName.endsWith(":" + tagName))
             ) {
            return subTree;
         } else if (subTree.hasChildNodes()) {
            NodeList nodesToExplore = subTree.getChildNodes();
            Node result;
            for (int i = 0; i < nodesToExplore.getLength(); i++) {
               result = getFirstElementByNameAUX(tagName,
                                                 nodesToExplore.item(i));
               if (result != null)
                  return result;
            }

         }
      }

      return null;

   }

   /**
    * Used to filter the XML Schema elements to consider while parsing this
    * DOM tree. It uses the contents of the treeElementNames for that.
    */
   public boolean isTreeElement(String elementName) {
      elementName.trim();
      //System.out.println(visibleTreeElementNames.length);
      for (int i = 0; i < visibleTreeElementNames.length; i++) {
         if (elementName.equals(visibleTreeElementNames[i]) ||
             elementName.endsWith(":" + visibleTreeElementNames[i])) {
            return true;
         }
      }
      return false;
   }

   /**
          * Allows the specification of a list of elements to filter in all operations.
    * The other elements, not specified in this list are not considered.
    */
   public void setVisibleTreeElementNames(String[] names) {
      visibleTreeElementNames = names;
      /*
             System.out.println("valid nodes:");
             for (int i = 0; i < names.length; i++) {
         System.out.println(names[i]);
             }
       */
   }

   /**
    * Sets the display of visible tree nodes to be active or inactive.
    */
   public void setFilterNodes(boolean mode) {
      filterNodes = mode;
   }

   /**
    * @return wether the display of only visibleTreeNodes is on or off
    */
   public boolean isFilteringNodes() {
      return filterNodes;
   }

   /**
    * Recursively parsers the dom model, using the facilities of the
    * DOMNodeAdapter class, and prints it to the standard output.
    */
   public void printNodeTree() {
      org.w3c.dom.Node n = domNode;
      System.out.println("");
      System.out.println(printAux("","   ", n));
      System.out.println("");

   }

   /**
    * Recursively parsers the dom model, using the facilities of the
    * DOMNodeAdapter class, and prints it to the standard output.
    */
   public void printNodeTree(org.w3c.dom.Node n) {
      System.out.println("");
      System.out.println(printAux("","   ", n));
      System.out.println("");

   }

   /**
    *
    * @return a compact xml version of the dom tree headed in this adapter.
    */
   public String toXML() {
      return "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n" + printAux("", "", domNode);
   }

   /**
    *
    * @return a human-readable xml text, with enters and indentation, of the tree
    * this object represents.
    */
   public String toXMLIndented() {
      return "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n" + printAux("","   ",domNode);
   }


   /**
    * Recursively prints the document with the proper identation.
    * This method is used by printNodeTree to add identation.
    *
    * If enters and spaces are used, enumerations are not parsed well, generationg
    * parsing errors. Because of that, if indentation is empty, we also supress the
    * enters at the end. This means that this xml document becomes not human readable
    * but syntatically correct to the parser. If you want human readable printing,
    * use toXMLIndented()
    *
    */
   private String printAux(String ident, String identStep, org.w3c.dom.Node n) {
      StringBuffer sb = new StringBuffer();
      if (n != null) {
         int type = n.getNodeType();

         switch (type) {
            case ELEMENT_TYPE:
               sb.append(ident + "<" + n.getNodeName());
               if (n.hasAttributes()) {
                  sb.append(" ");
                  NamedNodeMap map = n.getAttributes();
                  for (int i = 0; i < map.getLength(); i++) {
                     sb.append(printAux(ident, identStep, map.item(i)));
                  }
               }
               if (identStep.equals("")) {
                  sb.append(">");
               } else {
                  sb.append(">\n");
               }

               if (n.hasChildNodes()) {
                  NodeList list = n.getChildNodes();
                  for (int i = 0; i < list.getLength(); i++) {
                     sb.append(printAux(ident + identStep, identStep, list.item(i)));
                  }
               }
               if (identStep.equals("")) {
                  sb.append("</" + n.getNodeName() + ">");
               } else {
                  sb.append(ident + "</" + n.getNodeName() + ">\n");
               }
               break;
            case ATTR_TYPE:
               sb.append(n.getNodeName() + " = \"" + n.getNodeValue() +
                         "\" ");
               break;
            case TEXT_TYPE:
               if (identStep.equals("")) {
                  sb.append(n.getNodeValue().trim());
               } else {
                  sb.append(ident + n.getNodeValue().trim() + "\n");
               }
               break;

            default:

               // Recursively call the child.
               if (n.hasChildNodes()) {
                  NodeList list = n.getChildNodes();
                  for (int i = 0; i < list.getLength(); i++) {
                     sb.append(printAux(ident, identStep, list.item(i)));
                  }
               }
         }

      } else {
         System.out.println("ERROR: document was not parsed properly...");
      }

      return sb.toString();

   }

   /**
    * This method is declared static for performance reasons, preventing the
    * creation of a DOMNodeAdapter for each node that one would like to parse.
    *
    * @return the full path name from this node to the very father of the tree
    */
   public static String getFullPath(Node father) {
      String context = "";
      while (father != null && father.getParentNode() != null) {
         if (context.equals("")) {
            context = father.getLocalName();
         } else {
            context = father.getLocalName() + CONTEXT_SEPARATOR + context;
         }
         father = father.getParentNode();
      }
      return CONTEXT_SEPARATOR + context;
   }

   /**
    * This method is declared static for performance reasons, preventing the
    * creation of a DOMNodeAdapter for each node that one would like to parse.
    *
    * @return the full context (path without the node name) from this node
    * to the very father of the tree.
    */
   public static String getFullContext(Node father) {
      String path = getFullPath(father);
      int contextEnd = path.lastIndexOf(CONTEXT_SEPARATOR);
      String context = path.substring(0, contextEnd);
      if (context.equals("")) { // root element
         context = CONTEXT_SEPARATOR;

      }
      return context;
   }

}