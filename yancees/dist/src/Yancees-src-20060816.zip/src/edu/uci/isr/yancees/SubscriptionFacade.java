/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package edu.uci.isr.yancees;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.util.HashMap;
import java.util.Vector;

import org.w3c.dom.Node;

import edu.uci.isr.yancees.core.ActivePluginInstancesRegistry;
import edu.uci.isr.yancees.core.NotificationManager;
import edu.uci.isr.yancees.core.ParserException;
import edu.uci.isr.yancees.core.SubscriptionManager;
import edu.uci.isr.yancees.filter.FilterManagerInterface;
import edu.uci.isr.yancees.plugin.MOPluginInterface;
import edu.uci.isr.yancees.plugin.MOPluginListenerInterface;
import edu.uci.isr.yancees.util.DOMNodeAdapter;
import edu.uci.isr.yancees.util.DOMParser;

/**
 * This is the subscriber fa�ade for publishing and subscribing events to 
 * Yancees. It performs all necessary operations with both notification and
 * subscripton managers.
 * 
 * It also invokes the appropriate output filters if they are installed
 * 
 * This class stays behind the YanceesServer class 
 * 
 */
public class SubscriptionFacade {

	private String NOTIFICATION_TAG = NotificationManager.NOTIFICATION_TAG;
	private String SUBSCRIPTION_TAG = SubscriptionManager.SUBSCRIPTION_TAG;

	private NotificationManager notifMan;
	private SubscriptionManager subsMan;
	private ActivePluginInstancesRegistry subscriptionsDB;

	private FilterManagerInterface outputFilterManager = null;
	protected boolean filtersInstalled = false;

	private HashMap activeSubscriptionsMap;
	// maps subscribers to their subscription mediators list
	//private HashMap subscriptionSubscriberMap; // maps mediators to subscribers

	private boolean print = edu.uci.isr.yancees.YanceesProperties.getInstance().PRINT_DEBUG;

	// single instance of this class
	static SubscriptionFacade myInstance;

	// can only be accessed by the YancessAPI or anyone else inside yancess package
	static protected SubscriptionFacade getInstance() {
		if (myInstance == null) {
			myInstance = new SubscriptionFacade();
		}
		return myInstance;
	}

	// private here prevents direct instantiation
	private SubscriptionFacade() {
		ArchitectureManager archMan = ArchitectureManager.getInstance();

		// The ArchitectueManager should do this instead.
		//notifMan = archMan.getNotificationManager();
		//subsMan = archMan.getSubscriptionManager();

		activeSubscriptionsMap = new HashMap();
		// maps subscribers to a list of mediators
		subscriptionsDB = archMan.getActiveSubscriptionTreesDB();
	}

	/**
	  * Installs the inputqueue managed by filterManager in this API
	  * @param filterManager is the outputFilterManager to be used
	  */
	protected void installOutputFilters(FilterManagerInterface filterMan) {
		outputFilterManager = filterMan;
		filtersInstalled = true;
	}

	/**
	 *  look for the <subscribe> tag on the message
	 *  extract the <subscripton> and <notification> subtrees
	 *  parse the <subscription> and extract the plug-in evaluation tree
	 *  parse the <notification> part if any. If it does not exist, the default
	 *  <push> notificatoin policy is used. When parsing the notificaton, inform the
	 *  parsed <subscription> tree so the NotificationManager can connect it to its
	 *  selected policy.
	 *
	 * @param msg is a message having <subscription> and optional <notification> part.
	 * @param si is a callback interface of the subscriber.
	 */
	public void subscribe(MessageInterface msg, SubscriberInterface si)
		throws YanceesException {
		((GenericMessage) msg).setDateReceivedInServer(new java.util.Date());

		DOMParser parser = new DOMParser();
		parser.setXMLContent(msg.getXMLTextContent());
		
		DOMNodeAdapter adapt = new DOMNodeAdapter(parser.getDocument());
		Node notificationNode = adapt.getFirstElementByName(NOTIFICATION_TAG);
		Node subscriptionNode = adapt.getFirstElementByName(SUBSCRIPTION_TAG);

		// The publish/subscribe trees of plug-ins that will be generated by this
		// parser, if notification and subscriptions are propertly provided.
		MOPluginInterface subscriptionTree = null;
		MOPluginInterface notificationTree = null;

		if (subscriptionNode == null) {
			throw new YanceesException(
				"SubscriptionFacade: Could not find <"
					+ SUBSCRIPTION_TAG
					+ "> node on message.");
		} else {
			try {
				if (print)
					System.out.println(
						"SubscriptionFacade: parsing "
							+ subscriptionNode.getNodeName()
							+ " node");
				subscriptionTree = subsMan.parse(subscriptionNode);
			} catch (ParserException ex) {
				System.out.println(ex);
				System.out.println("Error when parsing subscription tree");
			}
		}

		SubscriberMediator mediator = null;
		// We consider the notification part of the message as optional, in case
		// it is not specified, the pull policy is used.
		if (notificationNode != null) {
			try {
				if (print)
					System.out.println(
						"SubscriptionFacade: parsing "
							+ notificationNode.getNodeName()
							+ " node");
				
				// The notification tree is combined with the subscription tree by
				// the notification manager, hence, we provide it as a paramater.
				notificationTree =
					notifMan.parse(notificationNode, subscriptionTree);
			} catch (ParserException ex) {
				System.out.println(ex);
				System.out.println(
					"SubscriptionFacade: Error when parsing subscription tree");

			}
			
			// the mediator will receive events from the topmost <notification> plug-in
			// once all the notification policies/procedures are performed. In case of a
			// <pull> notification, for example, the events will not be published but
			// saved in a stable memory (event box) for further query by the client.
			mediator = new SubscriberMediator(si, notificationTree, msg.getId());
			
			// this allows the notification/subscription to be shared by other components
			// of the system if necessary.
			subscriptionsDB.registerPluginTree(notificationTree, si);
		} else {
			if (print)
				System.out.println(
					"SubscriptionFacade: No notification part for this subscription: bypassing...");
			mediator = new SubscriberMediator(si, subscriptionTree, msg.getId());
			subscriptionsDB.registerPluginTree(subscriptionTree, si);
		}

		Vector subscriptionsList = (Vector) activeSubscriptionsMap.get(si);
		if (subscriptionsList == null) {
			subscriptionsList = new Vector();
			activeSubscriptionsMap.put(si, subscriptionsList);
		}
		// keeps active subscriptions in memory
		subscriptionsList.add(mediator);

	}

	/**
	 * Removes all the subscriptions associated to the provided subscriber
	 * @param si the callbabk interface of the subscriber
	 * @throws YanceesException in case there is no subscriptions associated to this subscriber
	 */
	public void unsubscribe(SubscriberInterface si) throws YanceesException {
		/*
		System.out.println("SubscriptionAPI: unsubscribing "+si.hashCode());
		java.util.Iterator it = activeSubscriptionsMap.keySet().iterator();
		while(it.hasNext()) {
			System.out.println("key: "+it.next());
		}
		*/
		Vector subscriptionsList = (Vector) activeSubscriptionsMap.get(si);
		if (subscriptionsList == null) {
			throw new YanceesException("SubscriptionFacade: No active subscriptins associated to this subscriber");
		} else {
			if (activeSubscriptionsMap.remove(si) == null) {
				System.out.println(
					"SubscriptionFacade: could not find subscriber record.");
			}
			subscriptionsDB.uregisterSubscriber(si);
			//System.gc();
			//System.runFinalization();
		}
	}

	/**
	 *  Removes all the subscriptions associated to the provided subscriber
	 * @param si the callbabk interface of the subscriber
	 * @param sub the specifi subscription to be descontinued
	 * @throws YanceesException in case there is no subscriptions associated to this subscriber
	 */
	public void unsubscribe(SubscriberInterface si, MessageInterface sub)
		throws YanceesException {
		((GenericMessage) sub).setDateReceivedInServer(new java.util.Date());
		Vector subscriptionsList = (Vector) activeSubscriptionsMap.get(si);
		if (subscriptionsList == null) {
			throw new YanceesException("SubscriptionFacade: No active subscriptins associated to this subscriber");
		} else {
			SubscriberMediator med = null;
			for (int i = 0; i < subscriptionsList.size(); i++) {
				med = (SubscriberMediator) subscriptionsList.get(i);
				if (med.getMessageId() == sub.getId()) {
					subscriptionsList.remove(i);
					subscriptionsDB.unregisterPluginTree(med.getPluginTree(), si);
					break;
				}
			}
		}
	}

	/**
	 * This method is used by the protocol plug-ins to have access to the active
	 * subscriptoin evaluatoin trees.
	 * @param si is the subscriber interface, which uniquely identifies a subscriber
	 * @return a list of active subcription processing trees composed of plug-ins.
	 */
	/*
	       protected PluginInterface[] getActiveSubscriptionTrees(SubscriberInterface si) {
	   PluginInterface[] subscriptionTrees = new PluginInterface[0];
	   Vector activeSubs = (Vector) activeSubscriptionsMap.get(si);
	   if (activeSubs != null) {
	      subscriptionTrees = new PluginInterface[activeSubs.size()];
	      activeSubs.copyInto(subscriptionTrees);
	   }
	   return subscriptionTrees;
	    }
	 */

	/**
	 * Used by the Yancees fa�ade, during bootstrap, to register a notification manager component
	 * @param nm the NotificatoinManager instance to be used.
	 */
	protected void setNotificationManger(NotificationManager nm) {
		notifMan = nm;
	}

	/**
	 * Used by the Yancees fa�ade, during bootstrap, to register the subscription manager component
	 * @param nm the SubscriptionManager instance to be used.
	 */
	protected void setSubscriptionManager(SubscriptionManager sm) {
		subsMan = sm;
	}

	/**
	 * The subscriber mediator receives notifications from the plug-ins and forward
	 * them to their specific subscribers.
	 * 
	 * We need a mediator here to make a mapping between the plug-in subscription
	 * tree and the subscriber interface.
	 * 
	 * It is also used to handle the input and output filters.
	 * 
	 * The management of active subscriptions is also performed here, so mediators 
	 * represente active subscriptions. When a mediator is destroyed it triggers the
	 * garbage collection process of the whole subscription tree of plug-ins
	 */
	public class SubscriberMediator implements MOPluginListenerInterface {

		private SubscriberInterface si; // the subscriber to be notified
		private MOPluginInterface plugin; // head of the plug-in evalutation tree
		private long messageID;
		// the message that originated the creation of the plugin eval tree.

		/**
		 * Constructor
		 * @param s is the subscriber interface to be notified when the plug-in
		 * evaluation tree is completed.
		 * @param pi is the plug-in that is the head of the parsed message. It will
		 * send a notification when the subscription is fully evaluated.
		 * @param mesgId is the id of the message (the subscription DOM), which
		 * after parsed, generated the plug-ins I am subscribing to.
		 */
		public SubscriberMediator(
			SubscriberInterface s,
			MOPluginInterface pi,
			long msgID) {
				
			plugin = pi;
			si = s;
			messageID = msgID;

			plugin.addListener(this);
		}

		public long getMessageId() {
			return messageID;
		}

		public MOPluginInterface getPluginTree() {
			return plugin;
		}

		/**
		 * Receives a notification from root plug-in's, and sends it to the output
		 * filters
		 * @param evt is the event received
		 * @param source is the plug-in sending the notification.
		 */
		public void receivePluginNotification(
			EventInterface evt,
			MOPluginInterface source) {
			EventInterface[] filteredEventList; // the output of the filtering process.

			if (filtersInstalled) {
				filteredEventList = outputFilterManager.filterEvent(evt);
				si.notify(filteredEventList);
			} else {
				si.notify(evt);
			}

		}

		/**
		 * Receives a list of events as notifications from root plug-in's and send
		 * them to the ouptut filters if they are present
		 * @param evtList is the list of events received
		 * @param source is the plug-in sending the notification.
		 **/
		public void receivePluginNotification(
			EventInterface[] evtList,
			MOPluginInterface source) {
				
			EventInterface[] filteredEventList;
			
			if (filtersInstalled) {
				filteredEventList = outputFilterManager.filterEventList(evtList);
				si.notify(filteredEventList);
			} else {
				si.notify(evtList);
			}
		}

		/**
		 * This class is invoked by the Garbage Collector...
		 * May be used to release any resource allocated to this record.
		 */
		protected void finalize() throws Throwable {

			ActivePluginInstancesRegistry subscriptionsDB =
				ActivePluginInstancesRegistry.getInstance();
			if (subscriptionsDB != null)
				subscriptionsDB.unregisterPluginTree(plugin, si);
			super.finalize();
		}

	};

}