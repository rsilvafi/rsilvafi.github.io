/*
 * Copyright (c) 2003, Regents of the University of California.
 * All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 
/*
 * Created on Mar 10, 2004
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 * @version 1.0
 */
package edu.uci.isr.yancees.plugin;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import edu.uci.isr.yancees.GenericEvent;


/**
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class OrderedEventBuffer {

	Vector buffer = new Vector();
	HashMap idToEventMap = new HashMap(); // stores the ids of events in buffer.

	public void addPluginNotification(GenericEvent evt, MOPluginInterface source) {
		BufferRecord record = new BufferRecord(evt, source);
		boolean ignore = false;

		if (idToEventMap.get(record.getId()) != null) {
			// ignore the event, it is repeated
			ignore = true;
		} else {
			idToEventMap.put(record.getId(), evt);
		}
		
		if (! ignore && buffer.size() > 0) {
			BufferRecord currentElement;
			int position = buffer.size();
			
			// we assume the buffer is ordered with respect to the date received in server,
			// in ascendant order.
			while (position > 0 ) {
				currentElement = (BufferRecord) buffer.get(position-1);
				if (currentElement.getEventArrivalTime() < record.getEventArrivalTime()) {
					buffer.insertElementAt(record, position);
					break;	
				}
				position--;
			}
		} else if (! ignore){
			// add the first record in buffer
			buffer.add(record);
		}
	
	}
	
	/**
	 * 
	 * @return ALL the events in the buffer and empty it
	 */
	public BufferRecord[] getAndEmptyCurrentBuffer() {
		BufferRecord[] response = new BufferRecord[buffer.size()];
		buffer.copyInto(response);
		
		buffer.clear();
		idToEventMap.clear();
		
		return response;
	}
	
	/**
	 * Events need to stay in the buffer for some time, waiting for late events
	 * to come, which may come out of order. This method collects the events
	 * that are older than the specified time in milliseconds.
	 * @return the evnets that are in the buffer for more than <b>time</b> ms
	 */
	public BufferRecord[] getAndEmptyEventsOlderThan(long time) {
		BufferRecord[] response = null;
		Vector tempList = new Vector();
		
		long currentTime = (new Date()).getTime();
		BufferRecord currentRec;
		for (Iterator iter = buffer.iterator(); iter.hasNext();) {
			currentRec = (BufferRecord) iter.next();
			if (currentRec.getRecordTime() + time > currentTime) {
				tempList.add(currentRec);
				buffer.remove(currentRec);
			}
		}
		
		response = new BufferRecord[tempList.size()];
		tempList.copyInto(response);
		
		return response;
	}
	
	/**
	 * 
	 * @return the current buffer size
	 */
	public int getCurrentSize() {
		return buffer.size();
	}
	
	/**
	 * This is a record used to store the event and its source plug-in reference
	 */
	public class BufferRecord {
		private MOPluginInterface source;
		private GenericEvent event;
		private Date recordCreationTime;		
		
		// constructor
		public BufferRecord(GenericEvent evt, MOPluginInterface src) {
			source = src;
			event = evt;
			recordCreationTime = new Date();
		}
		
		/**
		 * @return the value used to compare this record with others.
		 */
		public MOPluginInterface getSource() {
			return source;
		}
		
		public GenericEvent getNotification() {
			return event;
		}
		
		public long getRecordTime() {
			return recordCreationTime.getTime();
		}
		
		public long getEventArrivalTime() {
			return event.getDateReceivedInServer().getTime();
		}
		
		public Long getId() {
			return new Long(event.getId());
		}
	}
	
	

}
