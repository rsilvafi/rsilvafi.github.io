/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package test.performance;

// used to get attributes// used to get child nodes
// used to get attributes
// used to get child nodes
import java.util.Date;

import org.elvin.je4.Consumer;
import org.elvin.je4.ElvinURL;
import org.elvin.je4.Notification;
import org.elvin.je4.NotificationListener;
import org.elvin.je4.Producer;

public class ElvinPublishTest implements NotificationListener {

	static int repetitions = 100000;
	
	Date[] beginSubscribe = new Date[repetitions];
	Date[] endSubscribe = new Date[repetitions];
	Date[] beginPublish = new Date[repetitions];
	Date[] endPublish = new Date[repetitions];
	Date eventSent;
	Date[] notificationReceived = new Date[repetitions];
	Date[] averageCycles = new Date[repetitions];
	
	int notifCounter = 0; // number of notifications received

	public static void main(String argv[]) {
		Producer elvinProducer = null;
		Consumer elvinConsumer = null;
		ElvinURL url;
		
		String hostname;
		String subscriptionFileName;
		String eventFileName;

		if (argv.length != 1) {
			System.err.println(
				"Usage: java SienaNotificationTest hosthame ");
			System.exit(1);
		}

		hostname = argv[0];
		
		url = new ElvinURL(hostname);
		try {
		elvinProducer = new Producer(url);
		elvinConsumer = new Consumer(url);
		} catch (java.io.IOException ex) {
			System.out.println("Error when reating producer and consumer obejects!");
			System.out.println(ex);
		}
		
		// Create an instance of this class
		ElvinPublishTest myInstance = null;
				
		try {
			myInstance = new ElvinPublishTest();	
			
			Notification event;
			
			System.out.println("SienaPerformanceTest: Publishing "+repetitions+" events...");
			event = myInstance.newEvent(1);
			for (int i=0; i<repetitions; i++) {

				myInstance.beginPublish[i] = new Date();
				elvinProducer.notify(event);
				myInstance.endPublish[i] = new Date();
				
			}
		
         //	We need to wait some time in order to re ceive all the remaining notifications
			// before we close the connection.
			try {
				Thread.sleep(2000);
			} catch (InterruptedException ex) {
				System.out.println(ex);
			}
			
			System.out.println("Finalizing...");
			elvinConsumer.close();
			elvinProducer.close();
		
		} catch (java.io.IOException ex) {
			System.out.println(ex);
		}

		myInstance.printStatistics();
		
		/*
		while (true) {
		   try {
		      Thread.sleep(500);
		   } catch (InterruptedException ex) {
		      System.out.println(ex);
		   }
		}
		*/

	} // main

	public Notification newEvent(int counter) {
		Notification event = new Notification();
		event.put("name", "Roberto");
		event.put("age", 29);
		event.put("counter", counter);

		return event;
	}

	public void printStatistics() {
		long period;
		long sum;
		System.out.println("\n Performance data: \n");
			
		System.out.println("\nPublication delays:");
		sum = 0;		for (int i=0; i<repetitions; i++) {
			period = endPublish[i].getTime() - beginPublish[i].getTime();
			System.out.println("Period: "+period+" ms");
			sum = sum + period;
		}
		System.out.println("Average = "+(sum / repetitions)+" ms");
		
		
	}




	/* (non-Javadoc)
	 * @see org.elvin.je4.NotificationListener#notificationAction(org.elvin.je4.Notification)
	 */
	public void notificationAction(Notification arg0) {
		notificationReceived[notifCounter] = new Date();
		notifCounter++;

	}

}