package test.performance;

import org.elvin.je4.Consumer;
import org.elvin.je4.ElvinURL;
import org.elvin.je4.Notification;
import org.elvin.je4.NotificationListener;
import org.elvin.je4.Subscription;

//import AwacsSimulatorEvent;

public class ElvinThroughputConsumer
	extends Thread
	implements NotificationListener {

	int numberOfEvents = 0;
	int eventsPerCycle = 0;
	int CYCLE_TIME = 1000; // 1 second

	public static void main(String args[]) throws Exception {
		ElvinURL url = new ElvinURL("elvin://localhost");
		//ElvinURL url = new ElvinURL("elvin://awareness.ics.uci.edu");
		// connect to the "test" scope
		Consumer cons = new Consumer(url);

		// create a subscription
		Subscription sub = new Subscription("name == 'Roberto'");

		ElvinThroughputConsumer consumer = new ElvinThroughputConsumer();

		// register a listener
		sub.addNotificationListener(consumer);

		// activate the subscription
		cons.addSubscription(sub);

		System.out.println("waiting for events...");
		consumer.start();
	}

	public void run() {

		while (true) {
			System.out.println("Total events received: " + numberOfEvents);
			System.out.println("Throughput: " + eventsPerCycle + " events/s");
			eventsPerCycle = 0;
			try {
				Thread.sleep(CYCLE_TIME);
			} catch (InterruptedException e) {
				System.out.println(e);
				e.printStackTrace();
			}

		}
	}

	/* (non-Javadoc)
	 * @see org.elvin.je4.NotificationListener#notificationAction(org.elvin.je4.Notification)
	 */
	public void notificationAction(Notification arg0) {
		numberOfEvents++;
		eventsPerCycle++;
	}

}
