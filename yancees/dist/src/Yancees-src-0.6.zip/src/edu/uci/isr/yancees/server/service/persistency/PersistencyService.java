/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 /*
 * Created on Sep 1, 2003
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */
package edu.uci.isr.yancees.server.service.persistency;

import java.util.Date;
import java.util.HashMap;
import java.util.Vector;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.server.service.AbstractService;

/**
 * This persistency service stores the events in main memory. Future extensions
 * will store them in a secondary memory device.
 */
public class PersistencyService extends AbstractService {

	HashMap eventsMap; // associates a subscriber interface with a list of events
	
	/**
	 * constructor
	 */
	public PersistencyService() {
		super();
		eventsMap = new HashMap();
	}
	
	/**
	 * Stores the event in the database in the si account.
	 * @param si is the account to store the event
	 * @param event is the event to be stored
	 */
	public void storeEvent(SubscriberInterface si, EventInterface event) {
		Vector eventList = (Vector) eventsMap.get(si);
		if (eventList == null) {
			eventList = new Vector();
			eventsMap.put(si, eventList);
		}
		eventList.add(event);
	}
	
	/**
	 * Gets all the events stored for a subscriber
	 * @param si is the subscriber account identifier
	 * @return a list of events or an empty list if no events found
	 */
	public EventInterface[] getEvents(SubscriberInterface si) {
		EventInterface[] responseEvents = new EventInterface[0];
		Vector eventList = (Vector) eventsMap.get(si);
		if (eventList != null) {
			responseEvents = new EventInterface[eventList.size()];
			eventList.copyInto(responseEvents);
		}
		return responseEvents;
	}
	
	/**
	 * Gets all the events from a subscriber
	 * @param si is the accoutn where the events are stored
	 * @return a list of events or an empty list if no event is found
	 */
	public EventInterface[] getAndRemoveEvents(SubscriberInterface si) {
		EventInterface[] answer = getEvents(si);
		removeEvents(si);
		return answer;
	}
	
	/**
	 * Gets all the events after a given date, for a given subscriber
	 * @param date is the date to be used as reference
	 * @param si is the subscriber account identifier
	 * @return a list of events stored in the database or an empty list if no event
	 * matched the query.
	 */
	public EventInterface[] getEventsAfter(Date date, SubscriberInterface si) {
		EventInterface[] responseEvents = new EventInterface[0];
		Vector eventList = (Vector) eventsMap.get(si);
		Vector afterDateEvents = new Vector();
		
		if (eventList != null) {
			EventInterface currentEvent;
			for (int i = 0; i < eventList.size(); i++) {
				currentEvent = (EventInterface) eventList.get(i);
				if (currentEvent.getDateReceivedInServer().compareTo(date) > 0) {
					afterDateEvents.add(currentEvent);
				}
			}
			responseEvents = new EventInterface[afterDateEvents.size()];
			afterDateEvents.copyInto(responseEvents);
		}
		
		return responseEvents;
	}

	/**
	 * Gets all the events before a given date
	 * @param date is the reference date to be considered
	 * @param si is the subscriber interface (account) to query
	 * @return a list of events before a referecne date or an empty list if no 
	 * events matching the query are found
	 */
	public EventInterface[] getEventsBefore(Date date, SubscriberInterface si) {
		EventInterface[] responseEvents = new EventInterface[0];
		Vector eventList = (Vector) eventsMap.get(si);
		Vector afterDateEvents = new Vector();
		
		if (eventList != null) {
			EventInterface currentEvent;
			for (int i = 0; i < eventList.size(); i++) {
				currentEvent = (EventInterface) eventList.get(i);
				if (currentEvent.getDateReceivedInServer().compareTo(date) < 0) {
					afterDateEvents.add(currentEvent);
				}
			}
			responseEvents = new EventInterface[afterDateEvents.size()];
			afterDateEvents.copyInto(responseEvents);
		}
		
		return responseEvents;
	}

	/**
	 * Get the events after a given date and remove them from the database
	 * @param date is the reference date
	 * @param si is the account to be considered
	 * @return the list of events removed from the database or an empty list if no
	 * event was found 
	 */
	public EventInterface[] getAndRemoveEventsAfter(Date date, SubscriberInterface si) {
		EventInterface[] answer = getEventsAfter(date, si);
		removeEvents(si, answer);
		return answer;
	}

	/**
	 * Gets all the events before a given date for the especified account
	 * @param date is the reference date considered
	 * @param si is the subscriber account to be queried
	 * @return the list of the events removed or an empty list if no event is found
	 */
	public EventInterface[] getAndRemoveEventsBefore(Date date, SubscriberInterface si) {
			EventInterface[] answer = getEventsBefore(date, si);
			removeEvents(si, answer);
			return answer;
	}

	/**
	 * Removes all the events, stored in the database, that are associated to the
	 * provided subscriber
	 * @param si is the subscriber account to be removed
	 */
	public void removeEvents(SubscriberInterface si) {
		eventsMap.remove(si);
	}
	
	/**
	 * Removes specific events form a subscriber account
	 * @param si is the subscriber interface (account) to be considered
	 * @param eventList is the list of events to be removed
	 */
	public void removeEvents(SubscriberInterface si, EventInterface[] eventList) {
		Vector subscriberVector = (Vector) eventsMap.get(si);
		for (int i = 0; i < eventList.length; i++) {
			subscriberVector.remove(eventList[i]);
		}
	}
	
	
	/**
	 * Removes all the events from all the accounts of the database
	 */
	public void clearAllEvents() {
		eventsMap.clear();
	}
	
	
}
