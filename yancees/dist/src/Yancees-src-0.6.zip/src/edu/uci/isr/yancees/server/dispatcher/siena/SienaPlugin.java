/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.server.dispatcher.siena;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import org.w3c.dom.Node;

import edu.uci.isr.yancees.ArchitectureManager;
import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.core.ParsingException;
import edu.uci.isr.yancees.dispatcher.DispatcherException;
import edu.uci.isr.yancees.dispatcher.EventDispatcherInterface;
import edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface;
import edu.uci.isr.yancees.plugin.AbstractPlugin;
import edu.uci.isr.yancees.plugin.PluginInterface;

/**
 * This plug-in deals with <filter> tags that are handled by Siena. This is the
 * only plug-in that talks with Siena directly.
 */
public class SienaPlugin
      extends AbstractPlugin {

   SienaSubscription mySubscription;
   NotificationHandler myNotificationHandler;
   EventDispatcherInterface dispatcher;

   private boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG;

   /**
    * @param subTree is the DOM tree this plugin is responsible for executing
    * evalutation of this plugin is published.
    */
   public SienaPlugin(Node subTree) {
      super(subTree);
      try {
         mySubscription = new SienaSubscription(subTree);
      } catch (ParsingException ex) {
         System.out.println(
               "SienaPlugin: Error while parsing subscription tree");
         System.out.println(ex);
      }

      dispatcher = ArchitectureManager.getInstance().getEventDispatcher();
      myNotificationHandler = new NotificationHandler();
      try {
         dispatcher.subscribe(mySubscription, myNotificationHandler);
      } catch (DispatcherException ex) {
         System.out.println(
               "SienaPlugin: Error while subscribing to dispatcher");
         System.out.println(ex);
      }

   }

   /**
    * Invoked by the GC...
    * We perform the unsubscripe action here...
    */
   protected void finalize() throws Throwable {
      try {
         if (print) {
            System.out.println("SienaPlugin: finalizing and unsubscribing...");
         }
         dispatcher.unsubscribe(myNotificationHandler);
      } catch (DispatcherException ex) {
         System.out.println("SienaPlugin: Error when unsubscribing to siena.");
         System.out.println(ex);
      }
      super.finalize();
   }

   /**
    * Receives a notification from another plug-in
    * @param evt is the event received
    * @param source is the plug-in sending the notification.
    */
   public void receivePluginNotification(EventInterface evt, PluginInterface source) {
      // This plug-in is a leaf in the tree and this method is not used.
   }

   /**
    * Receives a list of events as notifications from another plug-in
    * @param evtList is the list of events received
    * @param source is the plug-in sending the notification.
    **/
   public void receivePluginNotification(EventInterface[] evtList, PluginInterface source) {
      // This plug-in is a leaf in the tree and this method is not used.
   }

   /**
    * Callback object to receive events from the dispatcher.
    */
   public class NotificationHandler
         implements EventDispatcherListenerInterface {

      /**
       * sends an <code>Event</code> to this <code>Subscriber</code>
       * @param n Event passed to the Subscriber
       **/
      public void receiveDispatcherNotification(EventInterface evt) {
         publishOutput(evt);
      }

      /**
       * sends a sequence of <code>Event</code> evt to this
       * <code>Subscriber</code>
       * @param s sequence of Events passed to the Subscriber
       **/
      public void receiveDispatcherNotification(EventInterface[] evtList) {
         publishOutput(evtList);
      }

   }

}