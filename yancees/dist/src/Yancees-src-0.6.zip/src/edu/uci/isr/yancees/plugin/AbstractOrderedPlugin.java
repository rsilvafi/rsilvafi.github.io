/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 
package edu.uci.isr.yancees.plugin;

import org.w3c.dom.Node;
import edu.uci.isr.yancees.GenericEvent;

 /*
 * Created on Aug 29, 2003
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */


/**
 * This plug-in performs event ordering. For such, it uses the time the event
 * arrived in the server. The strategy used to sort the events is to age them for a
 * period of time in a buffer, where they are inserted in order, before publishing
 * them. Hence, this approach adds a delay to the system and is only supposed to
 * be used by applications such as event correlation, which deals with a subset 
 * of all the events of the system.
 */
public abstract class AbstractOrderedPlugin extends AbstractPlugin {

	private NotificaitonBufferScheduler buffer;
	
	/**
	 * @param subTree is a reference to the DOM tree representing the tag
	 * which originated this plug-in.
	 */
	public AbstractOrderedPlugin(Node subTree) {
		super(subTree);
		
		// The scheduler keeps running in the background, publishing events in the
		// buffer that have aged.
		buffer = new NotificaitonBufferScheduler();
		buffer.start();
	}

	/**
	 * This mehod now bufferizes the events received, rearranging them according to
	 * the order they are published in the notification server, removing repetitions.
	 * @see yancees.server.plugins.PluginListenerInterface#receivePluginNotification(yancees.core.Event, yancees.server.plugins.PluginInterface)
	 */
	public void receivePluginNotification(GenericEvent evt, PluginInterface source) {
		buffer.enqueueNotification(evt, source);
	}
	
	/**
	 * This mehod now bufferizes the event pattern received, rearranging it according to
	 * the order they are published in the notification server, removing repetitions.
	 * @see yancees.server.plugins.PluginListenerInterface#receivePluginNotification(yancees.core.Event[], yancees.server.plugins.PluginInterface)
	 */
	public void receivePluginNotification(
		GenericEvent[] evtList,
		PluginInterface source) {
			
		//TODO Implement
		
		/* A sequence of events (pattern) cannot be split in individual events.
		* for example, A OR (B AND C). The A will produce single events, whereas
		* the (B AND C) will produce chunks, patterns of events. A or () will handle
		* the () part as a single event. 
		*/
		
		/*
		 * In a pattern, the timestamp will be the biggest time stamp of the
		 * events that compose this pattern. 
		 */
		
	}


	/**
	 * This method allows the subclass to receive ordered events
	 * The events are ordered according to the time they arrive in the server
	 * Repeated events, with same Id, are also discarded, ma here.
	 * @param evt is the event in the order of arrival in the server, without repetition
	 * @param source is the plug-in that originated the event.
	 */
	public abstract void receiveOrderedPluginNotification(GenericEvent evt, PluginInterface source);
	
	
	/**
	 * This class periodically flushes the conents of the buffer to the plug-in
	 * The buffer waits for half a second in order to allow late events to arrive.
	 * The events are rearranged in the OrderedEventBuffer 
	 * 
	 */
	private class NotificaitonBufferScheduler extends Thread {
		private final int BUFFER_SLEEP_TIME = 500; // 1/2 second
		private OrderedEventBuffer buffer = new OrderedEventBuffer();
		
		public void enqueueNotification(GenericEvent evt, PluginInterface source) {
			buffer.addPluginNotification(evt, source);
		}
		
		public void run() {
			while(true) {
				if (buffer.getCurrentSize() > 0) {
					OrderedEventBuffer.BufferRecord[] records = buffer.getAndEmptyEventsOlderThan(BUFFER_SLEEP_TIME);
					for (int i = 0; i < records.length; i++) {
						receiveOrderedPluginNotification(records[i].getNotification(), records[i].getSource());
					}
				}
				
				// wait some time for new events to come...
				try {
					Thread.sleep(BUFFER_SLEEP_TIME);
				} catch (InterruptedException e) {
					System.out.println("NotificationBuffer: error when sleeping"+e);				
					e.printStackTrace();
				}
			}
		}
	}

}
