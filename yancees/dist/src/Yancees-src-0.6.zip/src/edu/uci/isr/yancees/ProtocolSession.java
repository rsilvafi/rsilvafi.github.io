/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import edu.uci.isr.yancees.core.ParserException;
import edu.uci.isr.yancees.core.ProtocolManager;
import edu.uci.isr.yancees.plugin.PluginInterface;
import edu.uci.isr.yancees.plugin.PluginListenerInterface;
import edu.uci.isr.yancees.plugin.ProtocolPluginException;
import edu.uci.isr.yancees.plugin.ProtocolPluginInterface;


/**
 *
 * It represents a session, a context, that deals with the exchange of messages
 * between the clients and the corresponding plug-in instance that handles this
 * protocol. It implements the same idea as a File a TCP connection object.
 *
 * In a protocol session there are two moments, an initial parsing and determinatoin of
 * what plug-in to instantiate, followed by a sequence of messages, which replies are
 * sent as events to the ProtocolListenerInterface, and then a termination of the
 * session.
 */
public class ProtocolSession
      implements PluginListenerInterface, ProtocolSessionInterface {

   private SubscriberInterface subscriberInterface; // receives events from the service.

   private ProtocolManager protocolManager;
   private ProtocolPluginInterface protocolPlugin; // is the plug-in tree this session represents
   private boolean initialized = false;

   private boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG;

   /**
    * The protected here allows only the ProtocolAPI to initialize this object.
    * @param si is the subscriptin listener interface, which will receive all the
    * events (data) generated as a result of the protocol.
    * @param pm is the protocol manager, with plug-in factories, to be used.
    */
   protected ProtocolSession(SubscriberInterface si,
                             ProtocolManager pm) {
      subscriberInterface = si;
      protocolManager = pm;
   }

   /**
    * Issues an initialization message to initiate this session. This message
    * will result in the creation of the protocol plug-in instance that will
    * handle all the communication from now on.
    * @param msg is the initial message of this session.
    */
   protected void initialize(MessageInterface msg)
         throws YanceesException {
      PluginInterface parsedTree = null;
      try {
         parsedTree = protocolManager.parse(msg.getDOM());
      } catch (ParserException ex) {
         System.out.println(
               "ProtocolSession: error when initializing protocol plugin.");
         throw new YanceesException(ex.toString());
      }
      protocolPlugin = (ProtocolPluginInterface) parsedTree;

      if (protocolPlugin == null) {
         throw new YanceesException("Unsuccessful parsing of message, null returned");
      } else {

         protocolPlugin.addListener(this);

         /**
          * The first message sets all necessary plug-ins and required plug-ins for this
          * protocol, thus it assembly the tree. The message is then passed again, with
          * the subscriberInterface, so the protocolPlugin can configurate itself using
          * the options in the message and the subscriberInterface.
          */
         try {
            protocolPlugin.receiveProtocolMessage(msg, subscriberInterface);
         } catch (ProtocolPluginException ex) {
            System.out.println(ex);
         }
         initialized = true;
      }
   }

   /**
    * Issues a termination message to finalze this session.
    * This message finalizes the plug-in and terminates its instance.
    * @param msg is the finalization messsage
    */
   public void terminate(MessageInterface msg)
         throws YanceesException {
      if (!initialized) {
         throw new YanceesException(
               "ProtocolSession: termination invoked without previous initialization!");
      }

      if (protocolPlugin != null) {
         try {
            protocolPlugin.receiveProtocolMessage(msg, subscriberInterface);
         } catch (ProtocolPluginException ex) {
            System.out.println(ex);
         }
         protocolPlugin.removeListener(this);
         protocolPlugin.terminateSession();
      }
   }

   /**
    * Terminates the session without sending a termination message
    * This message finalizes the plug-in and terminates its instance.
    */
   public void terminate()
         throws YanceesException {
      if (!initialized) {
         throw new YanceesException(
               "ProtocolSession: ERROR, termination invoked without previous initialization!");
      }

      if (protocolPlugin != null) {
         protocolPlugin.removeListener(this);
         protocolPlugin.terminateSession();
      }
   }

   /**
    * This class is invoked by the Garbage Collector...
    * May be used to release any resource allocated by this object and perform
    * finalizations.
    */
   protected void finalize()
         throws Throwable {
      // here goes the finalization calls.
      if (print)
         System.out.println("ProtocolSession: terminating this session...");
      terminate();
      super.finalize(); // should be the last mathod to be invoked here.
   }

   //------------------------------ public methods -----------------------------

   /**
    * Send a message to the protocol plug-in that is responsible for this
    * context
    * @param message is an XML document wrapped in the message.
    */
   public void sendMessage(MessageInterface message)
         throws YanceesException {
      if (initialized) {

         /** @todo: may want to do some preprocessing here to eliminate the <protocol> tag. */
         try {
            protocolPlugin.receiveProtocolMessage(message, subscriberInterface);
         } catch (ProtocolPluginException ex) {
            System.out.println(ex);
         }

      } else {
         throw new YanceesException(
               "Could not send message, procotocol session was not initialized.");
      }

   }

   //------------------- BEGIN Plug-in listener interface ----------------------

   /**
    * Receives a DATA notification from another plug-in
    * @param evt is the event received
    * @param source is the plug-in sending the notification.
    */
   public void receivePluginNotification(EventInterface evt, PluginInterface source) {
      //protocolListenerInterface.receiveProtocolNotification(evt);
      subscriberInterface.notify(evt);
   }

   /**
    * Receives a list of DATA events as notifications from another plug-in
    * @param evtList is the list of events received
    * @param source is the plug-in sending the notification.
    **/
   public void receivePluginNotification(EventInterface[] evtList,
                                         PluginInterface source) {
      //protocolListenerInterface.receiveProtocolNotification(evtList);
      subscriberInterface.notify(evtList);
   }


}