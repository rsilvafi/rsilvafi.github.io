/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.server.dispatcher.elvin;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.util.Date;
import java.util.Vector;

import org.elvin.je4.Subscription;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import edu.uci.isr.yancees.SubscriptionInterface;
import edu.uci.isr.yancees.core.ParsingException;


/* this class implements a siena subscription parser. It parses and converts an
 * XML subscription in the Elvin format to the native siena subscription.
 *
 * Hence, this subscription represents the main functionality of the core event
 * dispatcher component, on top of which all other subscription extensions are
 * build.
 *
 * In other words, the subscription is an adapter around a DOM node that is able
 * to map the specific sienaSubscriptio.xsd elements to filters in Elvin internal
 * representation. Hence, it works as a container and a translator of the
 * subscription subtrees that are understood by siena.
 */
public class ElvinSubscription implements SubscriptionInterface {

	private static long globalID = 0;
	private long id;

	private org.w3c.dom.Node domTree;
	// For memory purposes, we may need to get rid of it.
	
	private Subscription compiledSubscription;
	// The elvin subscription represented by this xml file
	
	private String[] compiledPattern; 
	// String representation of the parsed pattern (set of filters)

	private Date dateCreated;
	private Date dateReceivedInServer;

	/** string representation of all supported OPERATORS as described in the
	       * sienaSubscription.xsd. This array is used to validate these know OPERATORS
	 **/
	public static final String[] OPERATORS =
		{ null, "EQ", "LT", "GT", "GE", "LE", "PF", "SF", "ANY", "NE", "SS" };

	// TODO: The other elements, borrowed from siena, will not work here. Fix it later
	public static final String[] OPERATOR_STRINGS =
		{ null, "==", "<", ">", ">=", "<=", "PF", "SF", "ANY", "!=", "SS" };

	/** Tags used from the event to express siena constraints.
	 * these tags are imported from the sienaEvent.xsd schema and used in the
	 * sienaSubscriptin.xsd
	 */
	public static final String NAME = "name";
	public static final String VALUE = "value";
	public static final String SUBSCRIPTION = "subscription";
	public static final String TYPE_ATTRIBUTE = "type";

	// Delimiters a filter as defined in the sienaSubscription.xsd
	public static final String FILTER = "filter";

	private boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG; // togles print of trancing debug messages

	/**
	 * Initializes this object with a DOM tree to be parsed
	 * we assume here that the subscription is provided according
	 * to sienaSubscription.xsd and the node provided here corresponds to the
	 * <subscription> tag.
	 */
	public ElvinSubscription(org.w3c.dom.Node node) throws ParsingException {

		ElvinSubscription.globalID++;
		this.id = globalID;
		this.dateCreated = new Date();
		this.dateReceivedInServer = null;

		// Subscription in an incomplete format, just a <filter> node provided.
		// This part of the code helps in the siena plugin.
		if (node.getNodeName().endsWith(":" + FILTER)
			|| node.getNodeName().equals(FILTER)) {
			domTree = node;
			String[] f = new String[1];
			f[0] = parseFilter(node);
			compiledPattern = f;

		} else if (
			node.getNodeName().endsWith(":" + SUBSCRIPTION)
				|| node.getNodeName().equals(SUBSCRIPTION)) {
			domTree = node;
			compiledPattern = parsePattern(domTree);
			// a subscription in siena is a pattern or a filter.
		} else {
			domTree = null;
			// the attribute of this class that stores the subscription DOM tree
			if (node.hasChildNodes()) {
				NodeList list = node.getChildNodes();
				//System.out.println("Tree has : "+list.getLength()+" children");
				for (int i = 0; i < list.getLength(); i++) {
					Node myNode = list.item(i);
					//System.out.println("Checking for : "+myNode.getNodeName());
					if (myNode.getNodeName().endsWith(":" + SUBSCRIPTION)
						|| myNode.getNodeName().equals(SUBSCRIPTION)) {
						domTree = myNode;
						//System.out.println("Found : "+myNode.getNodeName());
						break;
					}
				}
				if (domTree == null) {
					throw new ParsingException(
						"Could not find a <subscripton> node "
							+ "in tree headed by :"
							+ node.getNodeName());
				}
			}
			//System.out.println("Found 'subscription' node. Parsing it...");
			compiledPattern = parsePattern(domTree);

		}

	}

	public long getId() {
		return id;
	}

	/**
	 * Changes the current subscription DOM tree
	 */
	public void setDOM(org.w3c.dom.Node node) throws ParsingException {

		if (node.getNodeName().endsWith(":" + FILTER)
			|| node.getNodeName().equals(FILTER)) {
			domTree = node;
			String[] f = new String[1];
			f[0] = parseFilter(node);
			compiledPattern = f;

		} else if (
			node.getNodeName().endsWith(":" + SUBSCRIPTION)
				|| node.getNodeName().equals(SUBSCRIPTION)) {
			domTree = node;
			compiledPattern = parsePattern(domTree);
			// a subscription in siena is a pattern or a filter.
		} else {
			domTree = null;
			if (node.hasChildNodes()) {
				NodeList list = node.getChildNodes();
				for (int i = 0; i < list.getLength(); i++) {
					Node myNode = list.item(i);
					if (myNode.getNodeName().endsWith(":" + SUBSCRIPTION)
						|| myNode.getNodeName().equals(SUBSCRIPTION)) {
						domTree = myNode;
						break;
					}
				}
				if (domTree == null) {
					throw new ParsingException("Could not find a <subscripton> node");
				}
			}
			compiledPattern = parsePattern(domTree);

		}

	}

	/**
	 * @return the current DOM tree representing this subscription
	 */
	public org.w3c.dom.Node getDOM() {
		return domTree;
	}

	public String getSubscriptionString() {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < compiledPattern.length; i++) {
			sb.append("(");
			sb.append(compiledPattern[i]);
			sb.append(")");
	
			// Combine all restrictions with an end
			if (i < compiledPattern.length - 1) {
				sb.append(" && ");
			}
		}
		
		return sb.toString();
	}
	
	/**
	 * @return an elvin Subscription object representing the set of Filter siena objects.
	 * This is computed by the parsing of the DOM tree of this subscripton.
	 */
	public Subscription getSubscription() {
		StringBuffer sb = new StringBuffer("");
		if (compiledSubscription == null) {
			compiledSubscription = new Subscription(getSubscriptionString());
		}
		return compiledSubscription;
	}
	
	public String[] getPattern() {
		return compiledPattern;
	}

	/**
	 * Parses the tree providing the correspondent set of filters (pattern)
	 * as described in the sienaSubscription.xsd.
	 *
	 * @returns a siena Pattern object representing the provided subscription
	 */
	private String[] parsePattern(org.w3c.dom.Node patternDOM) {
		if (print) {
			System.out.println("parsePattern");

		}

		Vector filters = new Vector(0, 5);
		String[] filterArray;

		if (patternDOM != null && patternDOM.hasChildNodes()) {
			NodeList list = patternDOM.getChildNodes();
			int type;
			Node n;
			for (int i = 0; i < list.getLength(); i++) {
				n = list.item(i);
				type = n.getNodeType();
				if (type == Node.ELEMENT_NODE) {
					if (n.getNodeName().equals(FILTER)
						|| n.getNodeName().endsWith(":" + FILTER)) {
						String f = parseFilter(n);
						filters.add(f);
					}
				}
			}
		}

		filterArray = new String[filters.size()];
		for (int i = 0; i < filters.size(); i++) {
			filterArray[i] = (String) filters.get(i);
		}

		return filterArray;
	}

	/**
	 * Parses a DOM subtree representing a Filter Node as described in the
	       * sienaSubscription.xsd. In other words, gets the subtree under <filter> ...
	 * </filter>, parses and converts it to an actual Filter siena object.
	 *
	       * @return a siena Filter object representing the subscription information in
	 * the DOM tree.
	 */
	private String parseFilter(org.w3c.dom.Node filterDOM) {
		if (print) {
			System.out.println("ElvinAdapter: invoking parseFilter");

		}
		StringBuffer filter = new StringBuffer("");

		if (filterDOM != null && filterDOM.hasChildNodes()) {
			NodeList list = filterDOM.getChildNodes();
			int type;
			Node n;
			for (int i = 0; i < list.getLength(); i++) {
				n = list.item(i);
				type = n.getNodeType();
				if (type == Node.ELEMENT_NODE) {
					if (isValidElvinOperator(n.getNodeName())) {
						parseAttributeConstraint(filter, n);
					}
				}
			}
		}
		
		System.out.println("ElvinSubscription: subscribing to : "+filter);

		return filter.toString();

	}

	/**
	 * For each constraint represented in teh contraintDOM subtree, this method
	 * populates teh provided filter object.
	 *
	 * In other words, it parses a construct as:
	 * <EQ>
	 *   <name> ... </name> <value> ... </value>
	 * </EQ>
	 * <LT>
	 *   <name> ... </name> <value> ... </value>
	 * </LT>
	 * ...
	 *
	 * into sets of calls to the filter.addConstraint() method.
	 */
	private void parseAttributeConstraint(
		StringBuffer filter,
		org.w3c.dom.Node constraintDOM) {
		if (print) {
			System.out.println("parseAttributeConstraint");

		}
		String operatorName = null; // name of the operator as parsed
		short operatorType = 0; // type of the operator
		String attributeName = null; // attribute name of the constraint
		AttValue attributeValue = null; // Attribute value of the constraint

		if (constraintDOM != null && constraintDOM.hasChildNodes()) {
			operatorName = constraintDOM.getNodeName();
			operatorType = getOperatorType(operatorName);

			if (print) {
				System.out.println(
					"Processing constraint " + operatorName + ":" + operatorType);
			}
			attributeName = parseAttributeName(constraintDOM);
			attributeValue = parseAttValue(constraintDOM);

		}

		if (print) {
			System.out.println("populating filter...");
		}
		if (attributeValue != null) {
			
			if (filter.length() > 0)
				filter.append(" && "); // concatenate each filter with an AND
				
			switch (attributeValue.getType()) {
				
				// In elvin, strings need to be around 's
				case AttValue.BYTEARRAY : // covers strings too.
					filter.append(
						new String(
							"( "+attributeName + " "
								+ OPERATOR_STRINGS[operatorType]+ " "
								+ "'"+attributeValue.stringValue()+"'"+" )"));
					break;
				case AttValue.LONG :
					filter.append(
						new String(
							"( "+attributeName + " "
								+ OPERATOR_STRINGS[operatorType]+ " "
								+ attributeValue.longValue()+" )"));
					break;
				case AttValue.DOUBLE :
					filter.append(
				new String(
					"( "+attributeName + " "
						+ OPERATOR_STRINGS[operatorType]+ " "
								+ attributeValue.doubleValue()+" )"));
					break;
				case AttValue.FLOAT :
					filter.append(
				new String(
					"( "+attributeName + " "
						+ OPERATOR_STRINGS[operatorType]+ " "
								+ attributeValue.floatValue()+" )"));
					break;
				case AttValue.BOOL :
					filter.append(
				new String(
					"( "+attributeName + " "
						+ OPERATOR_STRINGS[operatorType]+ " "
								+ attributeValue.booleanValue()+" )"));
					break;
			}
		}

	}

	/**
	 * Gets a construction like that:
	 *
	 * <sienaOP>
	 *   <name> someName </name>
	 *   <value type="someType"> someValue </value>
	 * </sienaOP>
	 *
	 * and returns the content "someValue", which is between <value> tags.
	       * It also returns the type "someType" in the construction. These are wrapped
	 * in an AttValue object.
	 * sienaOP is one of the valid operations supported by siena.
	 *
	 */
	private AttValue parseAttValue(org.w3c.dom.Node attributeDOM) {
		if (print) {
			System.out.println("parseAttValue");

		}
		AttValue attVal;
		String valueType;
		String stringValue;

		if (attributeDOM != null) {

			// selects the <value type="blabla"> 1234 <value> tag and
			// extracts its content and type
			NodeList list = attributeDOM.getChildNodes();
			int nodeType;
			Node n;
			for (int i = 0; i < list.getLength(); i++) {
				n = list.item(i);
				nodeType = n.getNodeType();
				if (nodeType == Node.ELEMENT_NODE) {
					if (n.getNodeName().equals(VALUE)
						|| n.getNodeName().endsWith(":" + VALUE)) {
						stringValue = parseNodeTextContent(n);
						valueType = parseNodeType(n);
						return new AttValue(stringValue, valueType);
					}
				}
			}

		}

		return null;
	}

	/**
	 * Gets a construction like that:
	 *
	 * <sienaOP>
	 *   <name> someName </name>
	 *   <value> someValue </value>
	 * </sienaOP>
	 *
	 * and returns the content "someName", which is between <name> tags.
	 * null is returned in case the value is not found
	 * sienaOP is one of the valid OPERATORS supported by siena.
	 *
	 */
	private String parseAttributeName(org.w3c.dom.Node attributeDOM) {
		if (print) {
			System.out.println("parseAttributeName");

		}
		if (attributeDOM != null) {

			NodeList list = attributeDOM.getChildNodes();
			int nodeType;
			Node n;
			for (int i = 0; i < list.getLength(); i++) {
				n = list.item(i);
				nodeType = n.getNodeType();
				if (nodeType == Node.ELEMENT_NODE) {
					if (n.getNodeName().equals(NAME)
						|| n.getNodeName().endsWith(":" + NAME)) {
						return parseNodeTextContent(n);
					}
				}
			}

		}

		return null;

	}

	/**
	 * @returns the value of the type attribute of a node if it exists, or
	 * null if it was not found.
	 *
	 * In other words, gets a constuction like:
	 *
	 * <tag type="someType"> blablabla </tag>
	 *
	 * and returns "someType", which is the content of the type attribute in the
	 * tag.
	 */
	private String parseNodeType(org.w3c.dom.Node node) {
		if (print) {
			System.out.println("parseNodeType");

		}
		Node tempNode;
		String name;
		if (node.hasAttributes()) {
			NamedNodeMap map = node.getAttributes();
			for (int i = 0; i < map.getLength(); i++) {
				tempNode = map.item(i);
				name = tempNode.getNodeName();
				if (name.equals(TYPE_ATTRIBUTE)
					|| name.endsWith(":" + TYPE_ATTRIBUTE)) {
					return tempNode.getNodeValue();
				}
			}

		}

		return null;
	}

	/**
	 * @return the text 'value' of a node like <element> value <element>
	 * or null in case this value does not exist.
	 */
	private String parseNodeTextContent(org.w3c.dom.Node node) {
		if (print) {
			System.out.println("parseNodeTextContent");
		}
		NodeList list = node.getChildNodes();
		int nodeType;
		Node n;
		for (int i = 0; i < list.getLength(); i++) {
			n = list.item(i);
			nodeType = n.getNodeType();
			if (nodeType == Node.TEXT_NODE) {
				return n.getNodeValue().trim();
			}
		}

		return null;
	}

	/**
	 * @return the index of the operator which equals its type. the operator is
	 * a valid siena subsciptoin language one.
	 */
	public short getOperatorType(String strop) {
		for (short i = 1; i < OPERATORS.length; ++i) {
			if (strop.equals(OPERATORS[i])
				|| strop.endsWith(":" + OPERATORS[i])) {
				return i;
			}
		}
		return 0;
	}

	/**
	 * Compares the provided operator as a String, to the valid OPERATORS
	 * suported by this subscription and as described in sienaSubscripion.xds
	 *
	 * @return true if valid operator, false if not.
	 */
	public boolean isValidElvinOperator(String strop) {
		for (short i = 1; i < OPERATORS.length; ++i) {
			if (strop.equals(OPERATORS[i])
				|| strop.endsWith(":" + OPERATORS[i])) {
				return true;
			}
		}
		return false;
	}

	public String toString() {
		return getSubscriptionString();
	}

	/**
	 * Changes the content of this message. Replaces it with the XML content
	 * provided in the String provided
	 * @param content is the new XML format contnet in the form of a String
	 */
	public void setXMLTextContent(String content) {
		/**@todo Implement this method*/
		throw new java.lang.UnsupportedOperationException(
			"Method setXMLTextContent() not yet implemented.");
	}

	/**
	 * @return the content of this message in the text form, as a string.
	 */
	public String getXMLTextContent() {
		/**@todo Implement this method*/
		throw new java.lang.UnsupportedOperationException(
			"Method getXMLTextContent() not yet implemented.");

	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public Date getDateReceivedInServer() {
		return dateReceivedInServer;
	}

}