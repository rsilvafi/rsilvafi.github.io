/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.server.rmi;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import edu.uci.isr.yancees.EventInterface;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

/**
 * This class provides the common functionality for a remote subscriber in the
 * yancees framework. It provides a remote callback interface to receive events
 * coming from the yancees remote server. This is a convenience class.
 * It can be extended in order to implement custom subscribers.
 * It provides all necessary RMI initializations.
 */
public abstract class AbstractRemoteSubscriberImplementation
      extends UnicastRemoteObject
      implements RemoteSubscriberInterface {

   /**
    * Initialized this remote interface and registers it with the localhost
    * rmiregistry
    * @throws RemoteException
    */
   public AbstractRemoteSubscriberImplementation() throws RemoteException {
      super();
   }

   /**
    * Receives notification from the remote server.
    * @param evt is an event container (text or DOM parsed XML)
    * @throws RemoteException in case of connection errors.
    */
   public abstract void notify(EventInterface evt) throws RemoteException;

   /**
    * Receives notification from the remote server.
    * @param evtList is a list event containers (text or DOM parsed XML)
    * @throws RemoteException in case of connection errors.
    */
   public abstract void notify(EventInterface[] evtList) throws RemoteException;
   
   /**
    * Receives a buffer of single event notifications (not patterns), from the
    * RMI Yancees server. We need to deserialize them here.
    */
	public void notifyBuffer(EventInterface[] evtList) throws RemoteException {
		for (int i = 0; i < evtList.length; i++) {
			notify(evtList[i]);
		}
	}

}