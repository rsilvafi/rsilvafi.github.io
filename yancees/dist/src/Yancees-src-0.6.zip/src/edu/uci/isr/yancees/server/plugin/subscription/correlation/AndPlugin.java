/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.server.plugin.subscription.correlation;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */


import org.w3c.dom.Node;

import java.util.Iterator;
import java.util.Vector;

/**
 *	This plug-in detects the orrurrence of two or more events A and B and C...
 * such that all events must happen but the order is not enforced
 * 
 * Additionally, the <b>within</b> and <b>after</b> clauses can be enforced
 * A and B within 10 min means that the whole and clause must be matched within
 * this time frame, otherwise, the match is not valid
 * 
 * A and B after 1 min means that between either event there must be a gap of
 * 1 minute.
 *  
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 *
 */
public class AndPlugin
      extends AbstractCorrelationPlugin {

	private boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG;
 
   /**
    * @param subTree is the DOM tree this plugin is responsible for executing
    * evalutation of this plugin is published.
    */
   public AndPlugin(Node subTree) {
      super(subTree);

    }
   
 	
	/**
	 * A new event came from a given source (represented from its id).
	 * @param element is the new arrived event 
	 * @param id is the id of the plug-in that sent the event
	 */
	protected void processObject(Object object, long id) {
      
       if (print) {
			 System.out.print("AndPlugin: expecting ID pattern: [ ");
			 for (int i = 0; i < eventSourceIDPattern.length; i++) {
				 System.out.print(eventSourceIDPattern[i]+", ");
			 }
			 System.out.println(" ]");
       } 
 
		/*
		 * At this point, we know that the event belongs to the pattern at some 
		 * position since the event was filtered up to this level.
		 * 
		 * We then need to start another pattern, offer the event to all open
		 * patterns, chekcing if they are still valid.
		 */
		 if (print) {
		 	System.out.println("AndPlugin: received object "+object.toString());
		 	System.out.println("AndPlugin: creating new buffer..."); 
		 }
		 
		// AND does not have order envorcement. 
		ObjectBuffer newBuffer = new ObjectBuffer(eventSourceIDPattern.length,
		                                        withinInterval,
		                                        afterInterval,
		                                        false);
		listOfBuffers.add(newBuffer);
		
		int position = getPluginIdIndex(id); // the position of the vector where it came from
		
		//Vector patternsExpired = new Vector();
		ObjectBuffer buffer;
		Vector buffersToRemove = new Vector();
		for (Iterator iter = listOfBuffers.iterator(); iter.hasNext();) {
			buffer = (ObjectBuffer) iter.next();
			buffer.objectArrivedForPosition(object, position);
			
			if (buffer.isExpired()) {
				if (print)
					System.out.println("AndPlugin: buffer expired, removing...");
				//listOfBuffers.removeElement(buffer);
				buffersToRemove.add(buffer);
				
			// not expired and full, we deliver it!!
			} else if (buffer.isFull()){
				System.out.println("AndPlugin: buffer is valid ang got full, publishing...");
				//listOfBuffers.removeElement(buffer);
				buffersToRemove.add(buffer);
				this.publishOutput(buffer.getBufferContent());
				
			}
		}
		
		if (print)
			System.out.println("AndPlugin: effectively removing all stale buffers...");
		for (int i = 0; i < buffersToRemove.size(); i++) {
			listOfBuffers.remove(buffersToRemove.get(i));
		}
	}

 }
