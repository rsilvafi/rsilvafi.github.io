/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package edu.uci.isr.yancees.plugin;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.util.Vector;

import org.w3c.dom.Node;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.util.DOMNodeAdapter;

/**
 * This abstract class defines the basic functionality of the plug-in as well
 * as its main attributes.
 */
public abstract class AbstractPlugin implements PluginInterface {

	private boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG;

	private static long globalIdCounter = 0;

	private long myId;
	private String myContext;
	private String myPath;
	private String myTag;
	private Node mySubtree;
	// Dom tree which head is a tag of the expression handled by the plugin

	protected Vector myListeners;
	protected Vector myRequiredPlugins;

	/**
	 * @param subTree is the DOM tree this plugin is responsible for executing
	 */
	public AbstractPlugin(Node subTree) {

		AbstractPlugin.globalIdCounter++;
		myId = AbstractPlugin.globalIdCounter;

		myContext = DOMNodeAdapter.getFullContext(subTree);
		myPath = DOMNodeAdapter.getFullPath(subTree);
		myTag = subTree.getLocalName();
		mySubtree = subTree;

		myListeners = new Vector();
		myRequiredPlugins = new Vector();	

	}

	/**
	 * This method is used by the subscription parser to inform the plugin of all
	 * the plug-ins that are supposed to notify this plugin when they
	 * are finished with their processing. This method is invoked in the BFS order
	 * in which the tags each plugin processes are parsed in the DOM tree.
	 *
	 * This information is necessary for plug-ins as the sequence detection in which
	 * the order of notifications may be important.
	 *
	 * This also prevents that plug-ins get garbage colleted, keeping required plug-ins
	 * in memory while necessary.
	 *
	 * @param id is an id of a plug-in that will notify this instance
	 */
	public void addRequiredPlugin(PluginInterface plugin) {
		myRequiredPlugins.add(plugin);
	}

	/**
	 *
	 * @return the list of plug-ins this plug-in depends on
	 */
	public PluginInterface[] getRequiredPluginsList() {
				
		PluginInterface[] pluginsList =
			new PluginInterface[myRequiredPlugins.size()];
		myRequiredPlugins.copyInto(pluginsList);
		return pluginsList;
	}

	/**
	 * Determines whether this plug-in requires other plug-ins or not.
	 * @return true if this plug-in requires other plug-ins or false if not
	 */
	public boolean hasChildren() {
		if (myRequiredPlugins.size() > 0)
			return true;
		else
			return false;
	}

	/**
	 * @return a list of plug-in IDs, which notifications are expected by this
	 * plugin. The result is provided in a BFS order.
	 *
	 */
	public long[] getExpectedPluginIDs() {
		int size = myRequiredPlugins.size();
		long[] response = new long[size];
		for (int i = 0; i < size; i++) {
			response[i] = ((PluginInterface) myRequiredPlugins.get(i)).getId();
		}
		return response;

	}

	/**
	 * @return the unique Id of this plugin
	 */
	public long getId() {
		return myId;
	}

	/**
	 * @return the tag name that this plugin is representing. It corresponds to
	 * the type of this plugin instance. For example, if this is a plug-in that handles
	 * a subtree headed by the <followed-by> tag, its type will be "followed-by"
	 *
	 */
	public String getTag() {
		return myTag;
	}

	/**
	 * @return a string separated by '/' that expresses the context, or sequence of
	 * tags from the root of a subscription DOM subtree to the subtree that this plug-in
	 * represents. For example, if this plug-in will handle the subtree headed by
	 * the tag <followed-by> in a subscripton
	 * like:
	 *   <subscription>
	 *      <rule>
	 *        <followed-by>
	 *           <filter>...
	 *           <filter>...
	 *        </followed-by>
	 *      </rule>
	 *      <action>
	 *         ...
	 *      </action>
	 *   </subscription>
	 *
	 * its full context will be 'subscription/rule' because followed-by is inside this
	 * path. The context is the path without the tag name.
	 *
	 * This information will be part of all events produced by this component.
	 * This information helps the subscription node to identify the events coming
	 * from this component, knowing that that specific branch of his was evaluated
	 * and the answer comes in that event.
	 */
	public String getFullContext() {
		return myContext;
	}

	/**
	 * @return a string separated by '/' that expresses the path, or sequence of
	 * tags from the root of a subscription DOM subtree to the subtree that this plug-in
	 * represents. For example, if this plug-in will handle the subtree headed by
	 * the tag <followed-by> in a subscripton
	 * like:
	 *   <subscription>
	 *      <rule>
	 *        <followed-by>
	 *           <filter>...
	 *           <filter>...
	 *        </followed-by>
	 *      </rule>
	 *      <action>
	 *         ...
	 *      </action>
	 *   </subscription>
	 *
	 * its full path will be 'subscription/rule/followed-by'
	 *
	 * This information will be part of all events produced by this component.
	 * This information helps the subscription node to identify the events coming
	 * from this component, knowing that that specific branch of his was evaluated
	 * and the answer comes in that event.
	 */
	public String getFullPath() {
		return myPath;
	}

	/**
	 * @return the DOM subtree that is handled (and headed) by this plug-in
	 */
	public Node getSubtree() {
		return mySubtree;
	}

	/**
	 * Publishes the provided output to the event dispatcher.
	 *
	 * @param evt is the event to be published to the dispather to whoever may
	 * be interested in
	 */
	protected void publishOutput(EventInterface evt) {
		
		if (evt != null) {
			for (int i = 0; i < myListeners.size(); i++) {
				if (print)
					System.out.println("AbstractPlugin: notifying listener...");
				(
					(PluginListenerInterface) myListeners.get(
						i)).receivePluginNotification(
					evt,
					this);
			}
		}
	}

	/**
	 * Publishes the provided event pattern to the event dispatcher
	 *
	 * @param evtPat is the event pattern to be published to the dispather to
	 * whoever may be interested in
	 */
	protected void publishOutput(EventInterface[] evtPat) {

		if (evtPat != null && evtPat.length > 0) {
			for (int i = 0; i < myListeners.size(); i++) {
				if (print)
					System.out.println("AbstractPlugin: notifying listener...");
				(
					(PluginListenerInterface) myListeners.get(
						i)).receivePluginNotification(
					evtPat,
					this);
			}
		} else {
			if (print)
				System.out.println(
					"AbstractPlugin: nothing to notify, empty or null event list");
		}
	}

	/**
	 * Receives a notification from another plug-in
	 * @param evt is the event received
	 * @param source is the plug-in sending the notification.
	 */
	public abstract void receivePluginNotification(
		EventInterface evt,
		PluginInterface source);

	/**
	 * Receives a list of events as notifications from another plug-in
	 * @param evtList is the list of events received
	 * @param source is the plug-in sending the notification.
	 **/
	public abstract void receivePluginNotification(
		EventInterface[] evtList,
		PluginInterface source);

	/**
	 * Makes this plug-in notify another provided plugin whenever it computers its output
	 */
	public void addListener(PluginListenerInterface plugin) {
		myListeners.add(plugin);
	}

	/**
	 * Removes a plug-in registered as listener of this plug-in
	 */
	public void removeListener(PluginListenerInterface plugin) {
		myListeners.remove(plugin);
	}

	/**
	 * This method is part of the plug-in memory and resources management.
	 * 
	 * Clear all the resources allocated by this plug-in i.e. the plug-in references
	 * this plug-in depends on, as well as the listeners. This makes this object 
	 * be eligible for garbage collection. 
	 */
	public void dispose() {
		myListeners.clear();
		PluginInterface plugin;
		for (int i = 0; i < myRequiredPlugins.size(); i++) {
			plugin = (PluginInterface) myRequiredPlugins.get(i);
			plugin.dispose();
		}
		myRequiredPlugins.clear();

		// The super class here is the Object class, no need to call finalize() now.
		// It will be called by the garbage collector automatically. 
		/*
		try {
			super.finalize();
		} catch (Throwable ex) {
			System.out.println(
				"AbstractPlugin: error when finalizing on dispose() method...");
			ex.printStackTrace();
			System.out.println(ex);
		}
		*/
	}
	
	protected void finalize() throws Throwable {
		dispose();
		if (print) {
			System.out.println("AbstractPlugin: garbage collecting plugin: "+this.getId());
			System.out.println("AbstractPlugin: of type: "+this.getClass().getName());
		}
		super.finalize();
	}


}