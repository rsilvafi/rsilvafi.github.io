/*
 * Copyright (c) 2003, Regents of the University of California.
 * All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 
/*
 * Created on Feb 27, 2004
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 * @version 1.0
 */
package edu.uci.isr.yancees.server.plugin.subscription.correlation;

import java.util.Date;
import java.util.Vector;
import java.util.HashMap;

import edu.uci.isr.yancees.EventInterface;

   /**
    * This class stores the events collected in each incomplete sequence. It represents
    * a partially matched pattern. A pattern may be matched without time bounds, or 
    * it can be defined to detect events that all arrive within certain time interval, 
    * or it can detect events that come one, after another, with some time interval, 
    * in between.
    */ 
   public class ObjectBuffer {
   	
   	private Object[] elementsBuffer;
   	private Date creationDate = null; // the time this pattern started being considered
   	private Date lastEventArrivalTime = null; // the time the last event got accepted to the buffer
   	private int elementsInBuffer = 0; // number of events in the buffer.
   	private long withinTimeFrame = -1; // event A follows event B within some time. -1 if not apply
   	private long afterTimeFrame  = -1;  // event A follows event B after some time. -1 if not apply
   	private boolean orderEnforced = false;
   	
   	private HashMap currentIDs = new HashMap();
   	
		 boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG;
   	
   	public ObjectBuffer(int size) {
   		elementsBuffer = new EventInterface[size];
   	}
   	
   	/**
   	 * Sets a buffer which must be filled within some interval, or must receive events, one
   	 * after another, after some interval, that must have order enforced or not
   	 * @param size is the expected number of events to expect in this pattern
   	 * @param withinInterval is the total amount of time withing which all events must arrived
   	 * @param afterInterval is the minimal time period between each event
   	 */
   	public ObjectBuffer(int size, long withinInterval, long afterInterval, boolean enforceOrder) {
			
			if (print) {
				System.out.println("EventBuffer: creating event buffer with options:");
				System.out.println("size: "+size);
				System.out.println("Within interval: "+withinInterval);
				System.out.println("After interval: "+afterInterval);
				System.out.println("Enforced order: "+enforceOrder);
			}
			
			elementsBuffer = new Object[size];
   		withinTimeFrame = withinInterval;
   		afterTimeFrame = afterInterval;
   		orderEnforced = enforceOrder;
   	}
   	
   	public EventInterface[] getBufferContent() {
   		EventInterface[] responseList;
   		Vector eventsList = new Vector();
   		
   		/*
   		 * We planify all the events, making them all come together in a single
   		 * stream, thus, we eliminate the pattern arrays,
   		 * making all become a sequence of events
   		 */
   		for (int i = 0; i < elementsBuffer.length; i++) {
				if (elementsBuffer[i] instanceof EventInterface) {
				   eventsList.add(elementsBuffer[i]);
   			} else if (elementsBuffer[i] instanceof EventInterface[]) {
					EventInterface[] pattern = (EventInterface[]) elementsBuffer[i];
					for (int j = 0; j < pattern.length; j++) {
						eventsList.add(pattern[j]);
					}
				}
			}
			
			responseList = new EventInterface[eventsList.size()];
			eventsList.copyInto(responseList);
   		return responseList;
   	}
   	
   	/**
   	 * Indicates whether or not all expected events arrived
   	 * @return true if the buffer is full
   	 */
   	public boolean isFull() {
   		return elementsInBuffer >= elementsBuffer.length;
   	}
   	
   	/**
   	 * This method checks for the 'WITHIN' clause in the correlation constructs.
   	 * 
   	 * @Return true if expiration time applies and the buffer is expired, 
   	 * false is returned in all other cases 
   	 */
   	public boolean isExpired() {
   		boolean expired = false;
   		
   		if ( (withinTimeFrame > 0 && creationDate != null ) &&
   		     (currentTime() - creationDate.getTime()  > withinTimeFrame) ) {
   		
				if (print)
					System.out.println("Buffer expired "+(currentTime() - creationDate.getTime() - withinTimeFrame)+"ms ago.");
				
				expired = true;
   		} 
   		return expired;
   	}
   	
   	/**
   	 * Gets the current system clock
   	 * @return the time representing the current system clock snapshot
   	 */
   	private long currentTime() {
			return (new Date()).getTime();
   	}
   	
   	/**
   	 * Checks for the "after" time frame option. If it is enabled, it determines
   	 * if it is time for the new event to get accepted.
   	 * @return true if time enough had elapsed since the last event arrival, false if not,
   	 * and true if this restriction does not apply to the current buffer
   	 */
   	private boolean canReceiveTheNextElement() {
   		boolean answer = true;
   		if (lastEventArrivalTime != null ) {
   			if (afterTimeFrame > 0) {
   				if (currentTime()-lastEventArrivalTime.getTime() > afterTimeFrame)
   					answer = true;
   				} else { 
   					answer = false;
   				} 
   			}  			
   		
   		if (print) { 
   			if (! answer) {
   				System.out.println("ObjectBuffer: event came "+
   				                  (afterTimeFrame - (currentTime() - lastEventArrivalTime.getTime()))
   				                  +" ms earlier than expected");
   			}
   		}
   		 
         //	if the last arrival time is null, we can always receive the first event
   		return answer;
   	}
   	
   	/**
   	 * Receives a notification informing the arrival of an event from the
   	 * specified position in the pattern.
   	 * @param event is the event reeived
   	 * @param position is the position in the pattern, where it came from
   	 * @return ture if the event was accepted and false if not, idicating that
   	 * the position was taken or the order of arrival was invalid.
       */	  
   	public boolean objectArrivedForPosition(Object element, int position) {
   		
   		/*
   		 * If order is enforced, the events arrive one after another fillig
   		 * the buffer from 0 to its size-1;
   		 * 
   		 * If order is not enforced, they can arrive at any position if that
   		 * position is not taken.
   		 * 
   		 * For all cases, the event position must be null (empty)
   		 * 
   		 */
			 //   time matter       after clause                     id problem
   		 if (! isExpired() && canReceiveTheNextElement() && ! alreadyInBuffer(element)) {
   		 
	   		if ( (elementsBuffer[position] == null) &&
	   		     (  
	   		        (
	   		          orderEnforced && (elementsInBuffer == position)
	   		        ) || (!orderEnforced )
	   		      )
	   		       
	   		   ) {
					
					
					/*
					if (print) {
						
						System.out.println("Condition = "+(( orderEnforced && (elementsInBuffer == position)) || (!orderEnforced )));
						System.out.println("orderEnforced = "+orderEnforced);
						System.out.println("elementsInBuffer = "+elementsInBuffer);
						System.out.println("position = "+position);
						System.out.println("elementsInBuffer == position "+((elementsInBuffer - position) == 0));
					}
					*/
					
					if (print)
						System.out.println("ObjectBuffer: adding object to position: "+position);
					
					elementsBuffer[position] = element;
				   lastEventArrivalTime = new Date();
				   this.elementsInBuffer++;
				   
				   // first pattern or event arrived, defined that time as the creation time
				   
				   if (creationDate == null) {
				   	creationDate = new Date();
				   	//creationDate = getCreationDate(element);
				   }
					
					if (print)
						System.out.println("ObjectBuffer: elementsInBuffer: "+this.elementsInBuffer);
				   
				   // we record the ids in the current buffer, for the alreadyInBuffer() method evaluation
				   currentIDs.put(new Long( ((EventInterface) element).getId()), element);
				   
				   // valid conditions, successful insertion
				   return true;		
	   		}
	   	
   		 }
   		 
			if (print)
				System.out.println("ObjectBuffer: Event was not accepted to buffer!!");
				   
   		// could not accept, event was not inserted in buffer.
			return false;
   	}
   	
   	/**
   	 * Figures out the date where the pattern matching starts counting,
   	 * if it is an event, it considers the time it arrived in the server, 
   	 * if it is a pattern, it considers the time it was received in the buffer.
   	 * @param element
   	 * @return
   	 */
   	private Date getCreationDate(Object element) {
			Date date;
			//	if it is an event, the time is that of arrival in the server
			if (element instanceof EventInterface) {
				date = ((EventInterface) element).getDateReceivedInServer(); 
			// if it is a pattern, the time is that of the pattern detection
			} else {
		
				date = new Date();
			}
			
			return date;
   	}
   	
   	/**
   	 * Since in an expression in the form A op A is mapped to two different
   	 * filters for the same query A, a single event will be matched in both
   	 * filters. Hence, a duplication will happen that provides the same event
   	 * twice for the operator. We need to prevent that by checking if the event
   	 * already exists. This method does it in O(element.length)
   	 * 
   	 * @param element is the new element arrived for the buffer
   	 * @return ture if the element provided (which is assumed to be either of
   	 * the type EventInterface or EventInterface[] elements)
   	 * is alredy in the buffer.
   	 */
   	boolean alreadyInBuffer(Object element) {
   		if (element instanceof EventInterface) {
   			Long id = new Long(((EventInterface) element).getId());
   			if (currentIDs.containsKey(id)) {
   				return true;
   			}
   			// open the array and check each event individually
   		} else if (element instanceof EventInterface[]) {
   			EventInterface[] evtList = (EventInterface[]) element;
				Long id;
   			for (int i = 0; i < evtList.length; i++) {
					id = new Long(evtList[i].getId());
					if (currentIDs.containsKey(id)) {
						return true;
					}
				}
   		}
   		
   		return false;
   	}
   	
   	public boolean isEmpty() {
   		return elementsInBuffer == 0;
   	}
   	
   	/**
   	 * @return the absolute size of the buffer, the total number of events to
   	 * wait for
   	 */
   	public int getBufferSize() {
   		return elementsBuffer.length;
   	}
   	
   	/**
   	 * @return the number of events in the pattern, matched up to now
   	 */
   	public int getMatchSize() {
   		return elementsInBuffer;
   	}
   	
   }

