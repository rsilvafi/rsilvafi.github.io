/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package examples;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

// JAXP packages
import java.io.File;
import java.io.PrintStream;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import edu.uci.isr.yancees.dispatcher.DispatcherException;
import edu.uci.isr.yancees.dispatcher.EventDispatcher;
import edu.uci.isr.yancees.server.dispatcher.siena.AttValue;
import edu.uci.isr.yancees.server.dispatcher.siena.OldSienaEvent;
import edu.uci.isr.yancees.server.dispatcher.siena.SienaRemoteAdapter;

/**
 * Notes: DefaultHandler is a SAX helper class that implements the SAX
 * ContentHandler interface by providing no-op methods.  This class
 * overrides some of the methods by extending DefaultHandler.  This program
 * turns on namespace processing and uses SAX2 interfaces to process XML
 * documents which may or may not be using namespaces.
 *
 */
public class OldSienaEventSAXParser extends DefaultHandler {
	/** Constants used for JAXP 1.2 */
	static final String JAXP_SCHEMA_LANGUAGE =
		"http://java.sun.com/xml/jaxp/properties/schemaLanguage";
	static final String W3C_XML_SCHEMA = "http://www.w3.org/2001/XMLSchema";
	static final String JAXP_SCHEMA_SOURCE =
		"http://java.sun.com/xml/jaxp/properties/schemaSource";

	public static final String EVENT = "event";
	public static final String BODY = "body";
	public static final String HEADER = "header";
	public static final String ATTRIBUTE = "attribute";
	public static final String NAME = "name";
	public static final String VALUE = "value";

	private static OldSienaEventSAXParser parser;
	// reference to the parser instance

	// xml parsing flags. Since the xml file structure is simple, this approach
	// works fast.
	private boolean atHeader = false;
	private boolean atBody = false;
	private boolean atAttribute = false;
	private boolean atAttributeName = false;
	private boolean atAttValue = false;

	// The current event and its attribute being processed.
	private OldSienaEvent currentEvent;
	private AttValue currentAttribute;

	private String currentAttributeType;
	private String currentAttributeName;
	private String currentAttValue;

	private String currentValueString; // The string between tags.

	/**
	 * Convert from a filename to a file URL.
	 */
	private static String convertToFileURL(String filename) {
		// On JDK 1.2 and later, simplify this to:
		// "path = file.toURL().toString()".
		String path = new File(filename).getAbsolutePath();
		if (File.separatorChar != '/') {
			path = path.replace(File.separatorChar, '/');
		}
		if (!path.startsWith("/")) {
			path = "/" + path;
		}
		return "file:" + path;
	}

	/**
	 * Use message to the end-user.
	 */
	private static void usage() {
		System.err.println("Usage: OldSienaEventParser [-options] <file.xml>");
		System.err.println("       -dtd = DTD validation");
		System.err.println(
			"       -xsd | -xsdss <file.xsd> = W3C XML Schema validation using xsi: hints");
		System.err.println(
			"           in instance document or schema source <file.xsd>");
		System.err.println(
			"       -xsdss <file> = W3C XML Schema validation using schema source <file>");
		System.err.println("       -usage or -help = this message");
		System.exit(1);
	}

	/**
	 * Reads the keys and the files from the command line, starting the parsing
	 * process.
	 */
	static public void main(String[] args) throws Exception {
		String filename = null;
		boolean dtdValidate = false;
		boolean xsdValidate = false;
		String schemaSource = null;

		// Parse arguments
		for (int i = 0; i < args.length; i++) {
			if (args[i].equals("-dtd")) {
				dtdValidate = true;
			} else if (args[i].equals("-xsd")) {
				xsdValidate = true;
			} else if (args[i].equals("-xsdss")) {
				if (i == args.length - 1) {
					usage();
				}
				xsdValidate = true;
				schemaSource = args[++i];
			} else if (args[i].equals("-usage")) {
				usage();
			} else if (args[i].equals("-help")) {
				usage();
			} else {
				filename = args[i];

				// Must be last arg
				if (i != args.length - 1) {
					usage();
				}
			}
		}
		if (filename == null) {
			usage();
		}

		// There are several ways to parse a document using SAX and JAXP.
		// We show one approach here.  The first step is to bootstrap a
		// parser.  There are two ways: one is to use only the SAX API, the
		// other is to use the JAXP utility classes in the
		// javax.xml.parsers package.  We use the second approach here
		// because at the time of this writing it probably is the most
		// portable solution for a JAXP compatible parser.  After
		// bootstrapping a parser/XMLReader, there are several ways to
		// begin a parse.  In this example, we use the SAX API.

		// Create a JAXP SAXParserFactory and configure it
		SAXParserFactory spf = SAXParserFactory.newInstance();

		// Set namespaceAware to true to get a parser that corresponds to
		// the default SAX2 namespace feature setting.  This is necessary
		// because the default value from JAXP 1.0 was defined to be false.
		spf.setNamespaceAware(true);

		// Validation part 1: set whether validation is on
		spf.setValidating(dtdValidate || xsdValidate);

		// Create a JAXP SAXParser
		SAXParser saxParser = spf.newSAXParser();

		// Validation part 2a: set the schema language if necessary
		if (xsdValidate) {
			try {
				saxParser.setProperty(JAXP_SCHEMA_LANGUAGE, W3C_XML_SCHEMA);
			} catch (SAXNotRecognizedException x) {
				// This can happen if the parser does not support JAXP 1.2
				System.err.println(
					"Error: JAXP SAXParser property not recognized: "
						+ JAXP_SCHEMA_LANGUAGE);
				System.err.println(
					"Check to see if parser conforms to JAXP 1.2 spec.");
				System.exit(1);
			}
		}

		// Validation part 2b: Set the schema source, if any.  See the JAXP
		// 1.2 maintenance update specification for more complex usages of
		// this feature.
		if (schemaSource != null) {
			saxParser.setProperty(JAXP_SCHEMA_SOURCE, new File(schemaSource));
		}

		// Get the encapsulated SAX XMLReader
		XMLReader xmlReader = saxParser.getXMLReader();

		// Set the ContentHandler of the XMLReader
		parser = new OldSienaEventSAXParser();
		xmlReader.setContentHandler(parser);

		// Set an ErrorHandler before parsing
		xmlReader.setErrorHandler(new MyErrorHandler(System.err));

		// Tell the XMLReader to parse the XML document
		xmlReader.parse(convertToFileURL(filename));
		OldSienaEvent evt = parser.getEvent();
		//System.out.println("Processed event: ");
		//System.out.println("");
		//System.out.println(evt.toString());
		System.out.println(evt.toXML());

		String sienaHost = "localhost";
		String port = "1234";
		String sienaAddress = "tcp:" + sienaHost + ":" + port;

		System.out.print("Starting Yancees EventDispatcher...");
		SienaRemoteAdapter sienaAdapt = new SienaRemoteAdapter(sienaAddress);
		EventDispatcher dispatcher = EventDispatcher.getInstance();
		dispatcher.addAdapter(sienaAdapt);
		System.out.println(" [OK]");

		System.out.print("Publishing event...");
		try {
			dispatcher.publish(evt);
		} catch (DispatcherException ex) {
			System.out.println(" [ERROR]");
			System.out.println(ex);
		}
		System.out.println(" [OK]");

		System.exit(0);

	}

	// Parser calls this once at the beginning of a document
	public void startDocument() throws SAXException {
		currentEvent = new OldSienaEvent();

	}

	// Parser calls this for each element in a document
	public void startElement(
		String namespaceURI,
		String localName,
		String qName,
		Attributes atts)
		throws SAXException {

		if (localName.equalsIgnoreCase(ATTRIBUTE)) {
			atAttribute = true;
		} else if (localName.equalsIgnoreCase(NAME)) {
			atAttributeName = true;
		} else if (localName.equalsIgnoreCase(VALUE)) {
			atAttValue = true;
		} else if (localName.equalsIgnoreCase(BODY)) {
			atBody = true;
		} else if (localName.equalsIgnoreCase(HEADER)) {
			atHeader = true;

			// collect the type associated with the value tag...
		}
		if (atAttValue) {
			String attType = null;

			if (atts.getLength() > 0) {
				attType = atts.getValue("type");
				if (attType == null) { // try again...
					attType = atts.getValue("xsi:type");
				}
				if (attType == null) { // try again...
					attType = atts.getValue(0);
				}
			}

			if (attType != null) {
				currentAttributeType = attType;
			} else {
				currentAttributeType = AttValue.STRING_TYPE;
			}

			//System.out.println("attType="+attType);
			//atAttValue = false;
		}

		/*
		      System.out.println("namespaceURI: " + namespaceURI);
		      System.out.println("localName: " + localName);
		      System.out.println("qName: " + qName);
		      if (atts.getLength() > 0) {
		         System.out.println("attributes: ");
		         String att;
		         for (int i = 0; i < atts.getLength(); i++) {
		            System.out.println("   qName: " + atts.getQName(i));
		            System.out.println("   type: " + atts.getType(i));
		            System.out.println("   value: " + atts.getValue(i));
		         }
		      }
		      System.out.println("");
		 */
	}

	/**
	 * Parser calls this for each element in a document
	 **/
	public void endElement(String uri, String localName, String qName)
		throws SAXException {

		//System.out.println("END: "+localName);

		if (atAttributeName) {
			currentAttributeName = currentValueString;
		} else if (atAttValue) {
			currentAttValue = currentValueString;
			currentAttribute = new AttValue(currentAttValue, currentAttributeType);

			if (atHeader) {
				//System.out.println("Adding header attribute: "+currentAttributeName);
				currentEvent.putHeaderAttribute(
					currentAttributeName,
					currentAttribute);
			} else if (atBody) {
				//System.out.println("Adding body attribute: "+currentAttributeName);
				currentEvent.putBodyAttribute(
					currentAttributeName,
					currentAttribute);
			}
		}

		if (localName.equalsIgnoreCase(ATTRIBUTE)) {
			atAttribute = false;
		} else if (localName.equalsIgnoreCase(NAME)) {
			atAttributeName = false;
		} else if (localName.equalsIgnoreCase(VALUE)) {
			atAttValue = false;
		} else if (localName.equalsIgnoreCase(BODY)) {
			atBody = false;
		} else if (localName.equalsIgnoreCase(HEADER)) {
			atHeader = false;

		}
	}

	// Parser calls this once after parsing a document
	public void endDocument() throws SAXException {

	}

	public void characters(char buf[], int offset, int len)
		throws SAXException {
		String s = new String(buf, offset, len);
		if (!s.trim().equals("")) {

			currentValueString = s.trim();

			/*
			          System.out.print("CHARS: ");
			          System.out.println(s.trim());
			          System.out.println("");
			 */
		}
	}

	/**
	 * @return a reference to the event that was parsed.
	 */
	public OldSienaEvent getEvent() {
		return currentEvent;
	}

	// Error handler to report errors and warnings
	private static class MyErrorHandler implements ErrorHandler {
		/** Error handler output goes here */
		private PrintStream out;

		MyErrorHandler(PrintStream out) {
			this.out = out;
		}

		/**
		 * Returns a string describing parse exception details
		 */
		private String getParseExceptionInfo(SAXParseException spe) {
			String systemId = spe.getSystemId();
			if (systemId == null) {
				systemId = "null";
			}
			String info =
				"URI="
					+ systemId
					+ " Line="
					+ spe.getLineNumber()
					+ ": "
					+ spe.getMessage();
			return info;
		}

		// The following methods are standard SAX ErrorHandler methods.
		// See SAX documentation for more info.

		public void warning(SAXParseException spe) throws SAXException {
			out.println("Warning: " + getParseExceptionInfo(spe));
		}

		public void error(SAXParseException spe) throws SAXException {
			String message = "Error: " + getParseExceptionInfo(spe);
			throw new SAXException(message);
		}

		public void fatalError(SAXParseException spe) throws SAXException {
			String message = "Fatal Error: " + getParseExceptionInfo(spe);
			throw new SAXException(message);
		}
	}
}