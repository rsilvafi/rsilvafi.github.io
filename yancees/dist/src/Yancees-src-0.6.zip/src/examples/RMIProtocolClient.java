/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package examples;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.GenericMessage;
import edu.uci.isr.yancees.YanceesException;
import edu.uci.isr.yancees.core.ParsingException;
import edu.uci.isr.yancees.server.rmi.RemoteProtocolSessionInterface;
import edu.uci.isr.yancees.server.rmi.AbstractRemoteSubscriberImplementation;
import edu.uci.isr.yancees.server.rmi.RemoteSubscriberInterface;
import edu.uci.isr.yancees.server.rmi.RemoteYanceesInterface;
import edu.uci.isr.yancees.util.DOMParser;

/**
 * THis is an improved version of SienaSubscriptionParser that uses the ArchitectureManager
 * to build the necessary configuration for it before sending a subscription.
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */
public class RMIProtocolClient
      extends AbstractRemoteSubscriberImplementation {

   public RMIProtocolClient() throws RemoteException {
      super();
   }

   public static void main(String argv[]) {

      String startPollingMessage = "./messages/startPollingMessage.xml";
      String resumePollingMessage = "./messages/resumePollingMessage.xml";
      String pausePollingMessage = "./messages/pausePollingMessage.xml";
      String stopPollingMessage = "./messages/stopPollingMessage.xml";

      RemoteYanceesInterface yanceesRemote = null;
      String hostname;
      String fileName;

      if (argv.length != 2) {
         System.err.println(
               "Usage: java RMIProtocolClient hostname subscriptionMessage.xml");
         System.out.println(
               "Note that the subscription needs to use pull notification");
         System.exit(1);
      }

      hostname = argv[0];
      fileName = argv[1];

      GenericMessage msg = null;

      try {
         msg = new GenericMessage(new File(fileName));
      } catch (IOException ex) {
         System.out.println("Error when parsing message.");
         System.out.println(ex);
      }
      if (msg == null) {
         System.exit(1);
      }

      // This class will listen to the events coming from the subscription.
      RMIProtocolClient myInstance = null;

      try {
         myInstance = new RMIProtocolClient();
      } catch (RemoteException ex) {
         System.out.println(ex);
         System.exit(1);
      }

      try {
         System.out.println(
               "RMIProtocolClient: Binding to yancees remote implementation at host " +
               hostname + "...");
         yanceesRemote = (RemoteYanceesInterface) Naming.lookup("//" + hostname +
               "/"+RemoteYanceesInterface.LOOKUP_NAME);
      } catch (NotBoundException ex) {
         System.out.println(ex);
         System.out.println(
               "RMIProtocolClient: Make sure yancees server is running.");
         System.exit(1);
      } catch (MalformedURLException ex) {
         System.out.println(ex);
         System.out.println("RMIProtocolClient: Check hostname in command line.");
         System.exit(1);
      } catch (RemoteException ex) {
         System.out.println(ex);
         System.exit(1);
      }

      try {
         yanceesRemote.subscribe(msg, (RemoteSubscriberInterface) myInstance);
      } catch (YanceesException ex) {
         System.out.println(ex);
      } catch (RemoteException ex) {
         System.out.println(ex);
      }

      RemoteProtocolSessionInterface pollSession = null;
      GenericMessage pollMsg = null;
      DOMParser parser;

      // message that preforms a poll
      try {
         parser = new DOMParser(new File(startPollingMessage));
         pollMsg = new GenericMessage(parser.getDocument());
      } catch (ParsingException ex) {
         System.out.println("Error when parsing polling message");
         System.out.println(ex);
      }

      try {
         System.out.println(
               "RMIProtocolClient: creating new protocol session and setting polling interval!");
         pollSession = yanceesRemote.createNewSession(pollMsg, myInstance);
      } catch (YanceesException ex) {
         System.out.println(
               "RMIProtocolClient: Error when creating a new session!");
         System.out.println(ex);
         ex.printStackTrace();
      } catch (RemoteException ex) {
         System.out.println(ex);
      }

      if (pollSession != null) {
         System.out.println(
               "RMIProtocolClient: Poll session created, waiting for messages!");
      }

      try {
         System.out.println("RMIProtocolClient: Sleeping for some time...");
         Thread.sleep(20000);
      }catch (Exception ex) {
         System.out.println(ex);
      }

      // message that preforms a poll
      try {
         parser = new DOMParser(new File(stopPollingMessage));
         pollMsg = new GenericMessage(parser.getDocument());
      } catch (ParsingException ex) {
         System.out.println("RMIProtocolClient: Error when parsing polling message");
         System.out.println(ex);
      }

      try {
         System.out.println("RMIProtocolClient: Terminating session...");
         pollSession.sendMessage(pollMsg);
      } catch (RemoteException ex) {
         System.out.println(ex);
      } catch (YanceesException ex) {
         System.out.println(ex);
      }



   } // main

//------------------------- Subscription notification handlers -----------------

   /**
    * sends an <code>Event</code> to this <code>RMIProtocolClient</code>
    *
    * @param n Event passed to the RMIProtocolClient
    *
    **/
   public void notify(EventInterface evt) {
      System.out.println("RMIProtocolClient: got Event: \n\n" + evt.toString());
   }

   /**
    * sends a sequence of <code>Event</code> evt to this
    * <code>RMIProtocolClient</code>
    *
    * @param s sequence of Events passed to the RMIProtocolClient
    *
    **/
   public void notify(EventInterface[] evtList) {
      for (int i = 0; i < evtList.length; i++) {
         System.out.println("RMIProtocolClient: got Event: \n\n" +
                            evtList[i].toString());
      }

   }

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.server.rmi.RemoteSubscriberInterface#notifyBuffer(edu.uci.isr.yancees.EventInterface[])
	 */
	public void notifyBuffer(EventInterface[] evtList) throws RemoteException {
		for (int i = 0; i < evtList.length; i++) {
			notify(evtList[i]);
		}
		
	}

}