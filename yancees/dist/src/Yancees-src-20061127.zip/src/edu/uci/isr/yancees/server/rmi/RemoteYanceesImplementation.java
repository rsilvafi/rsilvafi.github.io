/*
 * Copyright (c) 2003, Regents of the University of California.
 * All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */

package edu.uci.isr.yancees.server.rmi;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.MessageInterface;
import edu.uci.isr.yancees.ProtocolFacade;
import edu.uci.isr.yancees.PublicationFacade;
import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.SubscriptionFacade;
import edu.uci.isr.yancees.YanceesException;
import edu.uci.isr.yancees.YanceesFacade;
import edu.uci.isr.yancees.core.MessageParsingException;
import edu.uci.isr.yancees.plugin.ProtocolPluginInterface;

/**
 * This class implements the RemoteYanceesInterface, which is a fa�ade,
 * a remote interface to all Yancees APIs:
 * Publisher, Subscriber and Protocol. It collects the calls and route them to the
 * appropriate API. It glues everything together.
 * 
 * This is a remote class since it is registered in the server side to handle 
 * yancess calls.
 */
public class RemoteYanceesImplementation
	extends UnicastRemoteObject
	implements RemoteYanceesInterface {

	// the publish performance is better when it is not multithreaded
	public static boolean MULTI_THREADED_PUBLISH = false;

	private YanceesFacade yancees;
	private SubscriptionFacade subscriberAPI;
	private PublicationFacade publisherAPI;
	private ProtocolFacade protocolAPI;

	private int numberOfThreads = 0;
	// counts the number of active threads at the moment
	private static int THREAD_LIMIT = 100; // Input buffer size for all methods
	private static int THREAD_SLEEP_TIME = 100; // wait until retry.
	// Limits the number of requisitions to be 100 at a time, for better performance.

	private boolean print = edu.uci.isr.yancees.YanceesProperties.getInstance().PRINT_DEBUG;

	// We assign one mediator (local SubscriberInterface) for each remote subscriber
	// the management of individual subscriptions is performed by the yancess.class
	//component. this is only a remote wrapper.
	private HashMap mediatorsTable = new HashMap();
	// maps remote interfaces (RemoteSubscriberInterface) to local interfaces (SubscriberInterface)

	/**
	 * Constructor that accepts an architecture configuration file, with which
	 * plug-ins, filters and services are installed in the basic infrastructure
	 */
	public RemoteYanceesImplementation(File configFile) throws RemoteException {
		super();
		yancees = YanceesFacade.getInstance();
		try {
			yancees.bootstrap(configFile);
		} catch (MessageParsingException ex) {
			System.out.println(ex);
		}

		subscriberAPI = yancees.getSubscriberAPI();
		publisherAPI = yancees.getPublisherAPI();
		protocolAPI = yancees.getProtocolAPI();
	}

	/**
	 * Prints the usage and quits with an error message
	 */
	private static void initError() {
		System.err.println(
			"Usage: java YancessRemoteImplementation configuration.xml [lookupName]");
		System.exit(1);
	}

	// main class
	// initializes the program with a configuration file
	public static void main(String[] args) {
		
		RemoteYanceesImplementation implementation;
		
		// file that configures yancees with its plug-ins
		File configFile;
		
		//the name under which this remote interface will be registered with the rmiregistry
		String lookupName = RMI_LOOKUP_NAME;

		//Allows the specification of who can connect to this server.
		// the security parameters are passed to this java virtual machine
		// as the variable: java.security.policy
		/*
		if (System.getSecurityManager() == null) {
			System.setSecurityManager(new RMISecurityManager());
		}
		*/
		
		if (args.length < 1) {
			initError();
		}

		configFile = new File(args[0]);
		if (!configFile.exists()) {
			initError();
		}
			
		// if there are two arguments, the second is the lookup name.
		if (args.length == 2) {
			lookupName = args[1];
		}

		// the hostname will always be the localhost, what changes in the lookup name
		String hostname ="localhost";
		try {
			hostname = InetAddress.getLocalHost().getHostAddress();
			// the following was not compatible with JDK1.3
			//hostname = InetAddress.getLocalHost().getCanonicalHostName();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		
		String name = "//"+hostname+"/" + lookupName;

		// starting RMI registry...
		RMIRegistryImpl registry = new RMIRegistryImpl();
		registry.start();
		
		// wait some time until the RMIRegistry starts...
		try {
			System.out.println("RemoteYanceesImplementation: Waiting 1/2 second for the RMI registry to start");
			Thread.sleep(500);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
			
		try {
			System.out.println(
				"RemoteYanceesImplementation: creating Yancees instance...");
			implementation = new RemoteYanceesImplementation(configFile);
			System.out.println("RemoteYanceesImplementation: registering remote interface with rmiregistry...");
			
			Naming.rebind(lookupName, implementation);
			
			System.out.println(
				"RemoteYanceesImplementation bound and registered as " + name);
		} catch (Exception e) {
			System.err.println(
				"RemoteYanceesImplementation exception: " + e.getMessage());
			e.printStackTrace();
		}

	}

	//------------------------- Remote Interface implementation --------------------

	 /* (non-Javadoc)
    * @see edu.uci.isr.yancees.server.rmi.RemoteYanceesInterface#connectToSharedProtocol(java.lang.String)
    */
   public RemoteProtocolPluginInterface connectToSharedProtocol(String protocolId, RemoteSubscriberInterface rsi)
         throws YanceesException, RemoteException {
      
      SubscriberMediator mediator;
		mediator = (SubscriberMediator) mediatorsTable.get(rsi);
		if (mediator == null) {
			mediator = new SubscriberMediator(rsi, this);
			mediatorsTable.put(rsi, mediator);
		} else {
			mediator.incReferenceCounter();
		}

		RemoteProtocolPluginInterface remotePlugin = null;
		try {
			remotePlugin =  (RemoteProtocolPluginInterface) protocolAPI.connectToSharedProtocol(protocolId, mediator);
		} catch (YanceesException e) {
			System.out.println(
				"RemoteYanceesImplementation: error when connecting to shared protocol... " + e);
			e.printStackTrace();
		}
      
		return remotePlugin;
   }
   
   /* (non-Javadoc)
    * @see edu.uci.isr.yancees.server.rmi.RemoteYanceesInterface#connectToNewProtocol(java.lang.String)
    */
   public RemoteProtocolPluginInterface connectToNewProtocol(String protocolId, RemoteSubscriberInterface rsi)
         throws YanceesException, RemoteException {
      
      SubscriberMediator mediator;
		mediator = new SubscriberMediator(rsi, this);
		
		RemoteProtocolPluginInterface remotePlugin = null;
		try {
			ProtocolPluginInterface protPlug = protocolAPI.connectToSharedProtocol(protocolId, mediator);
			System.out.println("returned protocol plugin reference: "+protPlug);
			
			remotePlugin = (RemoteProtocolPluginInterface) protPlug;
		} catch (YanceesException e) {
			System.out.println(
				"RemoteYanceesImplementation: error when creating new protocol... " + e);
			e.printStackTrace();
		}
		
      return remotePlugin;
   }

	
	/* (non-Javadoc)
    * @see edu.uci.isr.yancees.server.rmi.RemoteYanceesInterface#disconnectToProtocol(java.lang.String, edu.uci.isr.yancees.server.rmi.RemoteSubscriberInterface)
    */
   public void disconnectFromProtocol(String protocolId, RemoteSubscriberInterface rsi) throws YanceesException, RemoteException {
      // TODO Auto-generated method stub
      
   }


	/**
	 * Multithreaded implementation of the Publish command
	 * Note that the YanceesException will not be thrown here
	 * @param evt is the event to be published.
	 */
	public void publish(EventInterface evt)
		throws YanceesException, RemoteException {

		// Redefine the event, so it gets a new ID, preventing clashes.
		/*
		try {
			evt = new Event(evt.getDOM());
		} catch (ParsingException e1) {
			System.out.println("RemoteYanceesImplementation: Error when creating a new event instance");
			e1.printStackTrace();
		}
		*/
		// I removed for performance reasons...

		//	Make the attributes local and final to be used inside the thread
		final EventInterface event = evt;

		/**
		 * I opted for not using multi threaded publish because it actually decreased
		 * the performance of the system. It is better to feed through the events
		 * to siena or elvin that will handle the publication in a most efficient way
		 * 
		 * However, I am using buffered asynchronous publish() in the client-side API.
		 * 
		 */
		
		if (! MULTI_THREADED_PUBLISH) {
		try {
			publisherAPI.publish(event);
		} catch (YanceesException e) {
			System.out.println("RemoteYanceesImplementation: error when publishing " + e);
			e.printStackTrace();
		}
		} else {
		

		/* Multithreaded implementation of the publish command in this server. A thread
		 *	is started to handle each call of this method.
		 * This method was commented out because the use of threads in the publish
		 * method will remove the determinism of the publishing mechanism, making some
		 * events to be published in front of others, thus, loosing the event ordering.
		 * Of course, this can be overcame by the use of timestamps in the events.
		 * 
		 * In this last case, we need to move the timestamping from the PublishFacade
		 * to here.
		 */
		
		threadGuard();
		Thread t = new Thread(new Runnable() {
			public void run() {
				numberOfThreads++;
				try {
					publisherAPI.publish(event);
				} catch (YanceesException e) {
					System.out.println(
						"RemoteYanceesImplementation: error when publishing " + e);
					e.printStackTrace();
				}
				numberOfThreads--;
			}
		});
		t.start(); 
		
		}
		
	}
	
	/**
	 * @param evtList is a list of events to be published.
	 * 
	 */
	public void publish(EventInterface[] evtList)
		throws YanceesException, RemoteException {
		for (int i = 0; i < evtList.length; i++) {
			publish(evtList[i]);
		}
	}


	/**
	 * Multithreaded implementation fo the subscribe command.
	 * Sends a subscription. When the subscriptio is matched, events are routed
	 * back to the remote subscriber.
	 * @param msg is the message having the subscription/notification
	 * @param 
	 */
	public void subscribe(MessageInterface msg, RemoteSubscriberInterface rsi)
		throws YanceesException, RemoteException {

		//	Make the attributes local and final to be used inside the thread 
		final MessageInterface messageInt = msg;
		final RemoteSubscriberInterface remoteSubscriber = rsi;
		final RemoteYanceesImplementation myImp = this;

		threadGuard();
		Thread t = new Thread(new Runnable() {
			public void run() {

				numberOfThreads++;

				SubscriberMediator mediator;
				mediator =
					(SubscriberMediator) mediatorsTable.get(remoteSubscriber);
				if (mediator == null) {
					mediator = new SubscriberMediator(remoteSubscriber, myImp);
					mediatorsTable.put(remoteSubscriber, mediator);
				} else {
					mediator.incReferenceCounter();
				}

				try {
					subscriberAPI.subscribe(messageInt, mediator);
				} catch (YanceesException e) {
					System.out.println(
						"RemoteYanceesImplementation: error when subscribing " + e);
					e.printStackTrace();
				}

				numberOfThreads--;
			}
		});
		t.start();
	}

	/**
	 * Multithreaded implementaiton of ubsubscribe method
	 * @param rsi is the remote subscriber engaging in the operation.
	 */
	public void unsubscribe(RemoteSubscriberInterface rsi)
		throws YanceesException, RemoteException {

		// Make the attributes local and final to be used inside the thread
		final RemoteSubscriberInterface remoteSubscriber = rsi;
		
		threadGuard();

		Thread t = new Thread(new Runnable() {
			public void run() {
				
				numberOfThreads++;

				SubscriberMediator mediator;
				mediator =
					(SubscriberMediator) mediatorsTable.get(remoteSubscriber);
				if (mediator != null) {
					try {
						subscriberAPI.unsubscribe(mediator);
					} catch (YanceesException e) {
						System.out.println(
							"RemoteYanceesImplementation: error when unsubscribing "
								+ e);
						e.printStackTrace();
					}
				}
				mediatorsTable.remove(remoteSubscriber);
				System.gc();

				numberOfThreads--;
			}
		});
		t.start();

	}

	/**
	 * Multithreaded implementaiton of ubsubscribe method
	 * @param rsi is the remote subscriber engaging in the operation.
	 * @param msg is the Subscriptoin being discontinued
	 */
	public void unsubscribe(RemoteSubscriberInterface rsi, MessageInterface msg)
		throws YanceesException, RemoteException {

		//	Make the attributes local and final to be used inside the thread
		final RemoteSubscriberInterface remoteSubscriber = rsi;
		final MessageInterface message = msg;

		threadGuard();
		/*
		 * Creates a thread to each call of this method. The tread keeps active in
		 * memory until the run() command finishes.
		 */
		Thread t = new Thread(new Runnable() {
			public void run() {
				
				numberOfThreads++;

				SubscriberMediator mediator;
				mediator =
					(SubscriberMediator) mediatorsTable.get(remoteSubscriber);
				if (mediator != null) {
					try {
						subscriberAPI.unsubscribe(mediator, message);
					} catch (YanceesException e) {
						System.out.println(
							"RemoteYanceesImplementation: error when unsubscribing "
								+ e);
						e.printStackTrace();
					}
					int counter = mediator.decReferenceCounter();
					if (counter <= 0) {
						mediatorsTable.remove(remoteSubscriber);
					}
				}
				numberOfThreads--;
			}

		});
		t.start();

	}

	public void shutdownYancees() throws YanceesException, RemoteException {
		System.out.println("RemoteYanceesImplementation: shutting down yancees...");
	}

	public void suspendYancees() throws YanceesException, RemoteException {
		System.out.println("RemoteYanceesImplementation: suspending yancees...");
	}

	public void resumeYancees() throws YanceesException, RemoteException {
		System.out.println("RemoteYanceesImplementation: resuming yancees...");
	}

	// I tried to place these methods here and use them in the threads but they
	// are not visible...

	public void threadGuard() {
		while (numberOfThreads > THREAD_LIMIT) {
			try {
				Thread.sleep(THREAD_SLEEP_TIME);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * Performs the mapping between the remote interface and the local
	 * subscriber interface, working also as a record of the active
	 * subscriptions.
	 * 
	 * We have remote and local subscriberInterfaces to allow the implementation of
	 * different protocols, for example HTTP or SOAP, that may heve different ways
	 * of representing a remote SubscriberInterface, so we need someone to be a 
	 * mediator here for the sake of future extensions
	 * 
	 * Behind this fa�ade, yancees interacts only with SubscriberInterfaces
	 * whereas, to the outside world, RemoteSubscriberInterfaces are used. Hence,
	 * a translation between both is necessary here.
	 */
	public class SubscriberMediator implements SubscriberInterface {

		RemoteSubscriberInterface remoteInterface;
		int referenceCounter;
		NotificationBuffer notificationBuffer;
		RemoteYanceesImplementation yancees;

		/**
		 * constructor
		 * @param rsi is the remote interface, that came from the publish or subscribe
		 * commands, protocols as well.
		 * @param callback is 
		 */
		public SubscriberMediator(
			RemoteSubscriberInterface rsi,
			RemoteYanceesImplementation ryi) {
			
			yancees = ryi;
			remoteInterface = rsi;
			referenceCounter = 1; //one
			
			notificationBuffer = new NotificationBuffer(rsi, this);
			notificationBuffer.start();
			
		}

		/**
		 * Receives notifications from the local components of Yancees and 
		 * repasses them to the remote subscribers
		 */
		public void notify(EventInterface evt) {
			
			
			//System.out.println("Adding event to buffer...");
			notificationBuffer.addEventToBuffer(evt);
			
			/*
			try {
				remoteInterface.notify(evt);
			} catch (RemoteException ex) {
				if (print) {
					System.out.println(
						"SubscriberMediator: error connecting to remote interface");
					System.out.println(ex);
				} */
			
			
				/**
				 * This piece of code is here to perform the disposal of Remote Interfaces that
				 * are disconnected, for example, due to a network error or abrupt client disconnection.
				 * Once it happpens, it is necessary to terminate all the subscriptions performed by
				 * that subscriber as well as unregister this mediator.
				 */
				/*
				try {
					if (print)
						System.out.println(
							"SubscriberMediator: unsubscribing remote interface...");
					subscriberAPI.unsubscribe(this);
					mediatorsTable.remove(this);
					if (print)
						System.out.println(
							"SubscriberMediator: remote interface unsubscribed.");
				} catch (YanceesException e) {
					System.out.println(
						"SubscriberMediator: error when unregistering the remote interface as a garbage collection strategy");
					System.out.println(e);
				}
				*/
			//}
		}

		/**
		  * Receives notifications from the local components of Yancees and 
		  * repasses them to the remote subscribers
		 */
		public void notify(EventInterface[] evtList) {
			
			
			for (int i = 0; i < evtList.length; i++) {
				notificationBuffer.addEventToBuffer(evtList[i]);	
			}
			
			/*
			try {
				remoteInterface.notify(evtList);
			} catch (RemoteException ex) {
				if (print) {
					System.out.println(
						"SubscriberMediator: error connecting to remote interface");
					System.out.println(ex);
				} */
				 
				/*
				try {
					System.out.println(
						"SubscriberMediator: unsubscribing remote interface...");
					subscriberAPI.unsubscribe(this);
					mediatorsTable.remove(this);
					System.out.println(
						"SubscriberMediator: remote interface unsubscribed.");
				} catch (YanceesException e) {
					System.out.println(
						"SubscriberMediator: error when unregistering the remote interface as a garbage collection strategy");
					System.out.println(e);
				}
				*/

			//}
		}

		public int incReferenceCounter() {
			referenceCounter++;
			return referenceCounter;
		}

		public int decReferenceCounter() {
			referenceCounter--;
			return referenceCounter;
		}

	}
	
	
	/**
	 * This buffer schedules events to be notified. The aim is to cope with
	 * scalability and high throughput, in order to publish a bunch of events at
	 * once, instead of one at a time. This strategy better utilizes the RMI 
	 * serialization mechanisms and icreases the throughput of the server.
	 * 
	 * A big buffer will allow the server to handle more publish commands per
	 * second. However, it will reduce the latency (the time between production
	 * and delivery of an event). A low SLEEP_TIME will not permit the buffer to
	 * get full, and will reduce the throughput.
	 * 
	 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
	 *
	 */
	protected class NotificationBuffer extends Thread {
		
		private final int BUFFER_SIZE = edu.uci.isr.yancees.YanceesProperties.getInstance().PS_BUFFER_SIZE; // maximum number of events in the buffer
		private final int SLEEP_TIME = edu.uci.isr.yancees.YanceesProperties.getInstance().PS_BUFFER_FLUSH_PERIOD;  // period when the buffer, if full, is flushed.
		
		//private final int BUFFER_SIZE = 100; // maximum number of events in the buffer
		//private final int SLEEP_TIME = 50;  // period when the buffer, if full, is flushed.
		
		// cicular buffer
		EventInterface[] buffer = new EventInterface[BUFFER_SIZE];
		SubscriberMediator mediator;
		
		private int size = 0;
		private int bottom = 0;
		
		RemoteSubscriberInterface remoteInterface = null;
		
		long totalNotificationsSent = 0;
		
		public NotificationBuffer(RemoteSubscriberInterface remInt, SubscriberMediator med) {
			remoteInterface = remInt;
			mediator = med;
		}
		
		/**
		 * Main logic of this thread
		 */
		public void run() {
			while(true) {
				if (! bufferIsEmpty() ) {
					//System.out.println("NotificatonBuffer: notifying events...");
					//System.out.println("Elements in buffer: "+size);
					notifyEvents();
				} else {
					try {
						Thread.sleep(SLEEP_TIME);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}
		
		/**
		 * Method used internally at this class to publish the events in the buffer.
		 */
		private synchronized void notifyEvents() {
				
			//System.out.println("Publishing events...");
			//System.out.println(" bottom = "+bottom+" elements = "+size);		
			
			if (! bufferIsEmpty()) {
				
				int elementsToProcess = size;
				EventInterface[] evtList = new EventInterface[elementsToProcess];
				
				for (int i=0; i<elementsToProcess; i++) {	
					evtList[i] = getEventFromBuffer();					
				}
				
				try {
					remoteInterface.notify(evtList);
					//totalNotificationsSent += evtList.length;
					//System.out.println("Total Events Notified = "+totalNotificationsSent);
				} catch (RemoteException e) {
					System.out.println("NotificationBuffer: cound not send notification, unsubscribing...");
					//e.printStackTrace();
					
					try {
						mediator.yancees.unsubscribe(remoteInterface);
					} catch (RemoteException e1) {
						System.out.println("NotificationBuffer: Communication error when unsubscribing stale subscriber");
						e1.printStackTrace();
					} catch (YanceesException e1) {
						System.out.println("NotificationBuffer: Error when unsubscribing stale subscriber");
						e1.printStackTrace();
					}
					
				}
				 									
			} 
			
			//System.out.println("Published");
			//System.out.println(" bottom = "+bottom+" elements = "+size);
			//System.out.println();
		}

		/**
		 * Method used by the clients of this class to enqueue events in the buffer
		 * @param event
		 */
		public synchronized void addEventToBuffer(EventInterface event) {
				
			if (bufferIsFull()) {
				// flush buffer first if it is full...
				notifyEvents();
			}
				
			//System.out.println("Adding element to buffer");
			//System.out.println(" bottom = "+bottom+" elements = "+size);
						
			int index = (bottom + size) % BUFFER_SIZE;
			buffer[index] = event;
			incSize();
			
		}
		
		/**
		 * This method should be called when there is some event on the buffer,
		 * otherwise, it returns null
		 * @return null if buffer is empty, the element in FIFO order, in case
		 * there is at least one element on it.
		 */
		public  EventInterface getEventFromBuffer() {
			int index = bottom;
			
			if (size > 0) {
				incBottom();
				decSize();
				return buffer[index];
			} else {
				 return null;
			} 
		}
		
		private  void incBottom() {
			bottom = ( bottom + 1 ) % BUFFER_SIZE;
		}
    	
		private  void decSize() {
			if (size > 0)
				size--;
		}
		
		private  void incSize() {
			size++;
		}
		
		private  boolean bufferIsFull() {
			return size == BUFFER_SIZE;
		}
		
		private  boolean bufferIsEmpty() {
			// for some reason, the buffer size is becoming negative, even though
			// I have a guard at decsize() 
			return size <= 0;
		}

	}
	
}
