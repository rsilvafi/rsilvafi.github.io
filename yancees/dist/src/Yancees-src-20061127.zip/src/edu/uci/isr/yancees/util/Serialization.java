/*
 * Created on Aug 13, 2004 by rsilvafi
 */
package edu.uci.isr.yancees.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

/**
 * @author roberto
 *
 */
public class Serialization {

    public static byte[] serializeObject(Object object) {
        byte[] buf = new byte[0];
        ObjectOutput out;
        
        try {
            // Serialize to a byte array
            ByteArrayOutputStream bos = new ByteArrayOutputStream() ;
            out = new ObjectOutputStream(bos) ;
            out.writeObject(object);
            out.close();
            
            // Get the bytes of the serialized object
            buf = bos.toByteArray();
        } catch (IOException e) {
            System.out.println("SOServiceNSListenerMediator: Error when serializing object to byte[]..."); 
            e.printStackTrace();
        }
        
        return buf;
    }
    
    public static Object deserializeObject(byte[] bytes) {
        ObjectInputStream in;
        Object obj = null;

        try {
            // Deserialize from a byte array
            in = new ObjectInputStream(new ByteArrayInputStream(bytes));
            obj = (Object) in.readObject();
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return obj;
    }
}
