/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.server.dispatcher.siena;

/**
 * <p>Title: Yancees Event Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

/**
 *   Value of an attribute in an event.
 *
 *   An <code>AttValue</code> is a container for a typed vaule of
 *   an attribute in a Event.  An <code>AttValue</code> can
 *   be of type <code>String</code>, <code>byte[]</code>,
 *   <code>int</code>, <code>long</code>, <code>double</code>, and
 *   <code>boolean</code>.  <p>
 *
 **/
public class AttValue
      implements java.io.Serializable {

   // These types correspond to the ones in the event.xsd definition
   // the values used here are XML-Schema compatible simple types
   public final static String STRING_TYPE = "sienaString";
   public final static String INT_TYPE = "sienaInt";
   public final static String LONG_TYPE = "sienaLong";
   public final static String FLOAT_TYPE = "sienaFloat";
   public final static String DOUBLE_TYPE = "sienaDouble";
   public final static String BOOLEAN_TYPE = "sienaBoolean";
   public final static String BINARY_TYPE = "sienaHexBinary";

   /** <em>null</em> type, the default type of an attribute */
   public static final int NULL = 0;

   /** string of bytes */
   public static final int BYTEARRAY = 1;

   /** string of bytes
    *
    *  an alias to <code>BYTEARRAY</code>
    *	provided only for backward compatibility
    **/
   public static final int STRING = 1;

   /** integer type.
    *
    *  corresponds to the Java <code>long</code> type.
    **/
   public static final int LONG = 2;

   /** integer type.
    *
    *	corresponds to the Java <code>int</code> type.
    **/
   public static final int INT = 2;

   /** double type.
    *
    *	corresponds to the Java <code>double</code> type.
    **/
   public static final int DOUBLE = 3;

   /** float type.
    *
    *	corresponds to the Java <code>float</code> type.
    **/
   public static final int FLOAT = 4;

   /** boolean type.
    *
    *	corresponds to the Java <code>boolean</code> type.
    **/
   public static final int BOOL = 5;

   private int type;

   // Variables to hold the value associated to the attribute
   private byte[] sval;
   private long ival;
   private double dval;
   private float fval;
   private boolean bval;
   // other types here...

   private String attributeType; // A String representing the type of this value

   public AttValue() {
      type = NULL;
      attributeType = STRING_TYPE;
   }

   public AttValue(AttValue x) {
      if (x == null) {
         type = NULL;
         return;
      }
      type = x.type;
      switch (type) {
         case INT:
            ival = x.ival;
            break;
         case BOOL:
            bval = x.bval;
            break;
         case DOUBLE:
            dval = x.dval;
            break;
         case BYTEARRAY:
            sval = (byte[]) x.sval.clone();
            break;
      }
   }

   /**
    * Initializes the attribute/value object with its string value and its type
    * the string value is converted to the internal representation according to
    * the type provided.
    *
    * @param val the value of the attribute as a String
    * @param type the type of the attribute
    */
   public AttValue(String val, String type) {

      //System.out.println("value/type: "+val+" "+type);
      if (type.endsWith(STRING_TYPE)) {
         init(val);
      } else if (type.endsWith(INT_TYPE)) {
         init(Integer.parseInt(val));
      } else if (type.endsWith(LONG_TYPE)) {
         init(Long.parseLong(val));
      } else if (type.endsWith(DOUBLE_TYPE)) {
         init(Double.parseDouble(val));
      } else if (type.endsWith(FLOAT_TYPE)) {
         init(Float.parseFloat(val));
      } else if (type.endsWith(BOOLEAN_TYPE)) {
         init(Boolean.getBoolean(val));
      } else if (type.endsWith(BINARY_TYPE)) {
         init(val.getBytes());
      } else {
         init(val); // Unknown type makes String to be assumed as default
      }

   }

   public AttValue(String s) {
      init(s);
   }

   public AttValue(byte[] s) {
      init(s);
   }

   public AttValue(long i) {
      init(i);
   }

   public AttValue(int i) {
      init(i);
   }

   public AttValue(boolean b) {
      init(b);
   }

   public AttValue(double d) {
      init(d);
   }

   public AttValue(float f) {
      init(f);
   }

   public void init(String s) {
      attributeType = STRING_TYPE;
      if (s == null) {
         type = NULL;
         return;
      }
      type = BYTEARRAY;
      sval = s.getBytes();
      //System.out.println("string AttValue");
   }

   public void init(byte[] s) {
      attributeType = BINARY_TYPE;
      type = BYTEARRAY;
      sval = (byte[]) s.clone();
   }

   public void init(long i) {
      attributeType = LONG_TYPE;
      type = LONG;
      ival = i;
      sval = null;

   }

   public void init(int i) {
      attributeType = INT_TYPE;
      type = INT;
      ival = i;
      sval = null;

   }

   public void init(boolean b) {
      attributeType = BOOLEAN_TYPE;
      type = BOOL;
      bval = b;
      sval = null;

   }

   public void init(double d) {
      attributeType = DOUBLE_TYPE;
      type = DOUBLE;
      dval = d;
      sval = null;

   }

   public void init(float f) {
      attributeType = FLOAT_TYPE;
      type = FLOAT;
      fval = f;
      sval = null;

   }

   //
   // other types here ...work in progress...
   //

   public int getType() {
      return type;
   }

   public int intValue() {
      switch (type) {
         case LONG:
            return (int) ival;
         case BOOL:
            return bval ? 1 : 0;
         case DOUBLE:
            return (int) dval;
         case FLOAT:
            return (int) fval;

            //
            // perhaps I should use Integer.decode() instead of
            // Integer.valueOf().  Anybody knows the difference?
            //
         case BYTEARRAY:
            return Integer.valueOf(new String(sval)).intValue();
         default:
            return 0; // should throw an exception here
            // ...work in progress...
      }
   }

   public long longValue() {
      switch (type) {
         case LONG:
            return ival;
         case BOOL:
            return bval ? 1 : 0;
         case DOUBLE:
            return (long) dval;
         case FLOAT:
            return (long) fval;

            //
            // Same as above. What's the difference between
            // Long.valueOf() and Long.decode()?
            //
         case BYTEARRAY:
            return Long.valueOf(new String(sval)).longValue();
         default:
            return 0; // should throw an exception here
            // ...work in progress...
      }
   }

   public double doubleValue() {
      switch (type) {
         case LONG:
            return ival;
         case BOOL:
            return bval ? 1 : 0;
         case DOUBLE:
            return dval;
         case FLOAT:
            return fval;
         case BYTEARRAY:
            return Double.valueOf(new String(sval)).doubleValue();
         default:
            return 0; // should throw an exception here
            // ...work in progress...
      }
   }

   public float floatValue() {
      switch (type) {
         case LONG:
            return ival;
         case BOOL:
            return bval ? 1 : 0;
         case DOUBLE:
            return (float) dval;
         case FLOAT:
            return fval;
         case BYTEARRAY:
            return Float.valueOf(new String(sval)).floatValue();
         default:
            return 0; // should throw an exception here
            // ...work in progress...
      }
   }

   public boolean booleanValue() {
      switch (type) {
         case LONG:
            return ival != 0;
         case BOOL:
            return bval;
         case DOUBLE:
            return dval != 0;
         case FLOAT:
            return fval != 0;
         case BYTEARRAY:
            return Boolean.valueOf(new String(sval)).booleanValue();
         default:
            return false; // should throw an exception here
            // ...work in progress...
      }
   }

   public String stringValue() {
      switch (type) {
         case LONG:
            return String.valueOf(ival);
         case BOOL:
            return String.valueOf(bval);
         case DOUBLE:
            return String.valueOf(dval);
         case FLOAT:
            return String.valueOf(fval);
         case BYTEARRAY:
            return new String(sval);
         default:
            return ""; // should throw an exception here
            // ...work in progress...
      }
   }

   public byte[] byteArrayValue() {
      switch (type) {
         case LONG:
            return String.valueOf(ival).getBytes();
         case BOOL:
            return String.valueOf(bval).getBytes();
         case DOUBLE:
            return String.valueOf(dval).getBytes();
         case FLOAT:
            return String.valueOf(fval).getBytes();
         case BYTEARRAY:
            return sval;
         default:
            return null; // should throw an exception here
            // ...work in progress...
      }
   }

   public boolean isEqualTo(AttValue x) {
      if (x != null) {
         switch (type) {
            case BYTEARRAY:
               return sval.equals(x.sval);
            case LONG:
               return ival == x.longValue();
            case DOUBLE:
               return dval == x.doubleValue();
            case FLOAT:
               return fval == x.floatValue();
            case BOOL:
               return bval == x.booleanValue();
            default:
               return false;
         }
      } else {
         return false;
      }
   }

   /**
    * @return a string with the XML Schema type of the current attribute
    */
   public String getAttributeType() {
      return attributeType;
   }

   public String toString() {
      return stringValue();
   }

   public String toXML() {
      return null;
   }

   public int hashCode() {
      return this.toString().hashCode();
   }
}