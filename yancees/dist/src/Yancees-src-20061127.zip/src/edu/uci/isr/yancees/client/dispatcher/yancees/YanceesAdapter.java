/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.client.dispatcher.yancees;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.util.Hashtable;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.SubscriptionInterface;
import edu.uci.isr.yancees.YanceesException;
import edu.uci.isr.yancees.client.rmi.YanceesRMIClient;
import edu.uci.isr.yancees.dispatcher.DispatcherException;
import edu.uci.isr.yancees.dispatcher.EventDispatcherAdapterInterface;
import edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface;


public class YanceesAdapter
      implements EventDispatcherAdapterInterface {

	private YanceesRMIClient client;
	private Hashtable mediatorsMap = new Hashtable(); // associates the subscriber interface with the mediator 

	public final String ADAPTER_NAME = "YanceesAdapter";

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#connect(java.lang.String)
	 * the address here, for this adapter, should be the parameter for YanceesRMIClient,
	 * which is the hostname where the YanceesServer is executing only.
	 */
	public void connect(String address) throws DispatcherException {
		try {
			client = new YanceesRMIClient(address);
		} catch (YanceesException e) {
			e.printStackTrace();
			throw new DispatcherException (e.toString());
		}

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#resumeDispatcher(edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface)
	 */
	public void resumeDispatcher(EventDispatcherListenerInterface li)
		throws DispatcherException {
		try {
			client.resumeYancees();
		} catch (YanceesException e) {
			e.printStackTrace();
			throw new DispatcherException (e.toString());
		}

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#shutdownDispatcher()
	 */
	public void shutdownDispatcher() throws DispatcherException {
		try {
			client.shutdownYancees();
		} catch (YanceesException e) {
			e.printStackTrace();
			throw new DispatcherException (e.toString());
		}

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#subscribe(edu.uci.isr.yancees.SubscriptionInterface, edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface)
	 */
	public void subscribe(
		SubscriptionInterface sub,
		EventDispatcherListenerInterface li)
		throws DispatcherException {
		
		SubscriberMediator mediator = (SubscriberMediator) mediatorsMap.get(li);
		
		if (sub == null) {
		   mediator = new SubscriberMediator(li);
			mediatorsMap.put(li, mediator);
		} 
		try {
			client.subscribe(sub, mediator);
			mediator.incReferenceCounter();
		} catch (YanceesException e) {
			e.printStackTrace();
			throw new DispatcherException(e.toString());
		}

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#suspendDispatcher(edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface)
	 */
	public void suspendDispatcher(EventDispatcherListenerInterface li)
		throws DispatcherException {
		try {
			client.suspendYancees();
		} catch (YanceesException e) {
			e.printStackTrace();
			throw new DispatcherException(e.toString());
		}

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#unsubscribe(edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface)
	 */
	public void unsubscribe(EventDispatcherListenerInterface li)
		throws DispatcherException {
			
			SubscriberInterface mediator = (SubscriberInterface) mediatorsMap.get(li);
			if (mediator != null) {
				try {
					client.unsubscribe(mediator);
					mediatorsMap.remove(li);
				} catch (YanceesException e) {
					e.printStackTrace();
					throw new DispatcherException(e.toString());
				}
			}

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#unsubscribe(edu.uci.isr.yancees.SubscriptionInterface, edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface)
	 */
	public void unsubscribe(
		SubscriptionInterface sub,
		EventDispatcherListenerInterface li)
		throws DispatcherException {
		
			SubscriberMediator mediator = (SubscriberMediator) mediatorsMap.get(li);
		if (mediator != null) {
			try {
				client.unsubscribe(mediator, sub);
				mediator.decReferenceCounter();
				if (mediator.getReferenceCounter() <= 0) {
					mediatorsMap.remove(li);
				}
			} catch (YanceesException e) {
				e.printStackTrace();
				throw new DispatcherException(e.toString());
			}
		}

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#publish(edu.uci.isr.yancees.EventInterface)
	 */
	public void publish(EventInterface evnt) throws DispatcherException {
		try {
			client.publish(evnt);
		} catch (YanceesException e) {
			e.printStackTrace();
			throw new DispatcherException(e.toString());
		}

	}
	
	/**
	 * Performs the mapping between the SubscriberInterface and the 
    * DispatcherListenerInterface
	 * 
	 * Behind this fa�ade, we interact with a remote implementation of Yancees.
	 * We use YanceesRMIClient to do the bridge from remote to local. 
	 * However, we need to provide the basic AdapterInterface, which deals with
	 * EventDispatcherListenerInterfaces, instead of SubscriberInterfaces. Hence,
	 * a translation between both is necessary here.
	 */
	public class SubscriberMediator implements SubscriberInterface {

		private EventDispatcherListenerInterface edli; // the subscriber to be notified	
		private int referenceCounter = 0;
		
		/**
		 * Constructor
		 * @param s is the subscriber interface to be notified when the plug-in
		 * evaluation tree is completed.
		 */
		public SubscriberMediator(EventDispatcherListenerInterface li) {
			referenceCounter ++;
			edli = li;
		}

		/**
		 * Receives notification as SubscriberInterface and forwards 
		 * it to the client EventDispatcherListenerInterface
		 * @param evt is the event received from the remote notification service
		 */
		public void notify(EventInterface evt)  {
			edli.receiveDispatcherNotification(evt);
		}

		/**
		 * Receives notification list as SubscriberInterface and forwards 
		 * it to the client EventDispatcherListenerInterface
		 * @param evtList is the list of events received from the remote 
		 * notificaiton service 
		 */
		public void notify(EventInterface[] evtList) {
			edli.receiveDispatcherNotification(evtList);
		}
		
		public void incReferenceCounter() {
			referenceCounter++;
		}
		
		public void decReferenceCounter() {
			referenceCounter--;
		}
		
		public int getReferenceCounter() {
			return referenceCounter;
		}

	}
	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#getAdapterName()
	 */
	public String getAdapterName() {
		
		return ADAPTER_NAME;
	};

}