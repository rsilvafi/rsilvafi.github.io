/*
 * Copyright (c) 2003, Regents of the University of California.
 * All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */

/*
 * Created on Nov 18, 2003
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 * @version 1.0
 */
package edu.uci.isr.yancees;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import edu.uci.isr.yancees.core.MessageParsingException;
import edu.uci.isr.yancees.util.DOMNodeAdapter;
import edu.uci.isr.yancees.util.Serialization;

/**
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 * 
 * This class implements an event using the xml schema defined in
 * yanceesEvent.xsd. It extends the GenericEvent to include methods that allow
 * the programmer to add and remove attributes in a programmatic way, not having
 * to provide an XML file as an input. This class builds an XML document based
 * on the event description at yanceesEvent.xsd
 */
public class YanceesEvent extends GenericEvent {

	private boolean VALIDATING = edu.uci.isr.yancees.YanceesProperties.getInstance().PERFORM_XML_VALIDATION;

	// constants with the name of the attributes used to convey meta-information
	// using the underlying dispatcher component.
	public static final String YANCEES_DATE_RECEIVED = "yancees.date.received";

	public static final String YANCEES_DATE_CREATED = "yancees.date.created";

	public static final String YANCEES_ID = "yancees.id";

	public static final String YANCEES_VERSION_TAG = "yancees.version";

	public static final String YANCEES_VERSION = "1.0";

	/**
	 * Tags used from the event to express siena constraints. these tags are
	 * imported from the sienaEvent.xsd schema and used in the
	 * sienaSubscriptin.xsd
	 */
	public static final String EVENT = "event";

	public static final String NAME = "name";

	public static final String VALUE = "value";

	public static final String ATTRIBUTE = "attribute";

	public static final String TYPE_ATTRIBUTE = "type"; // XML elemnt attribute

	// All value types supprted by the current yanceesEvent.xsd type
	public static final String BINARY_TYPE = "yanceesHexBynary";

	public static final String BOOLEAN_TYPE = "yanceesBoolean";

	public static final String DOUBLE_TYPE = "yanceesDouble";

	public static final String FLOAT_TYPE = "yanceesFloat";

	public static final String LONG_TYPE = "yanceesLong";

	public static final String INT_TYPE = "yanceesInt";

	public static final String STRING_TYPE = "yanceesString";

	// constants used by the sax parser...
	static final String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";

	static final String W3C_XML_SCHEMA = "http://www.w3.org/2001/XMLSchema";

	static final String JAXP_SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";

	private boolean print = edu.uci.isr.yancees.YanceesProperties.getInstance().PRINT_DEBUG;

	// private boolean invalidateMemoryDOM = false;

	/**
	 * In this class, the primary representation of the event attributes is this
	 * hashmap, the other representation: text or DOM are built only when
	 * necessary. I believe this interface will be more useful than that two
	 * other representations of the event, so I will make this class optimized
	 * in terms of memory and processing to use this data structure.
	 */
	private Map eventAttributes = new HashMap();

	/**
	 * Initializes this event with a generic event. The event is then parsed
	 * into the internal hashtable format.
	 */

	public YanceesEvent(EventInterface evi) throws MessageParsingException {
		this(evi.getXMLTextContent());
	}

	/**
	 * @param n
	 *            is the representation of the event as a DOM tree in memory
	 * @throws ParsingException
	 *             is thrown in case the event is not according to the expected
	 *             format.
	 */

	/*
	 * public YanceesEvent(Node n) throws ParsingException { super(n); try {
	 * this.extractAttributesFromDOM(messageDOM); } catch (ParsingException e) {
	 * System.out.println("YanceesEvent: "+e.toString()); e.printStackTrace(); }
	 * //updateMetaInfo(); }
	 */

	/**
	 * @param file
	 *            is the File object with the XML representation of an event
	 *            according to the standard format, supported by the adapter and
	 *            the plug-ins. The event here can be desribed in many formats,
	 *            as well as the adapters and plug-ins in the server know how to
	 *            handle it.
	 * @throws IOException
	 */
	public YanceesEvent(File file) throws IOException {
		super(file);
		extractAttributesFromFileUsingSAX(file);

		// At this point we have the contents of the file at the local
		// textContent variable. We need to parse it to extract the attributes.
		// updateMetaInfo();

	}

	/**
	 * @param content
	 *            is the XML representation of the event in textual, string in
	 *            memory.
	 */
	public YanceesEvent(String content) {
		super(content);
		extractAttributesFromText(content);
		// updateMetaInfo();
	}

	/**
	 * This is the preferential constructor for this object. It creates an empty
	 * event that will be stuffed with attribute/value pairs with the
	 * setAttribute() methods.
	 * 
	 */
	public YanceesEvent() {
		super();
		// updateMetaInfo();

	}

	/**
	 * If the program is initialized with a text or a file, we need to extract
	 * the attributes in order to store the eventAttributes hashmap, which will
	 * have the actual value of the attributes and values of this event.
	 * 
	 * This method is also called whenever all the attributes of the file are
	 * erased.
	 */

	/*
	 * THE REASON I REMOVED IT WAS THAT: - IF IT IS LEFT THERE, THE METAINFO IS
	 * UPDATED EACH TIME AN EVENT IS CREATED, - WHICH WILL OVERWRITE THE
	 * PARAMETERS PROVIDED BY THE ADAPTER. - THESE PARAMETERS ALSO SHOULD NOT GO
	 * INTO THE REGULAR EVENT - SO THEY ARE ADDED AND REMOVED BY THE ADAPTERS
	 * ONLY.
	 * 
	 * private void updateMetaInfo() {
	 * 
	 * this.put(YANCEES_VERSION_TAG, YANCEES_VERSION); // Marks the event as
	 * belonging to yancees this.put(YANCEES_DATE_CREATED,
	 * this.getDateCreated().getTime()); if (this.getDateReceivedInServer() !=
	 * null) this.put(YANCEES_DATE_RECEIVED,
	 * this.getDateReceivedInServer().getTime()); this.put(YANCEES_ID,
	 * this.getId());
	 *  }
	 */

	/**
	 * Overwritten from superlcass. This method updates the event property if
	 * the date received in server is first set or changed.
	 */
	/*
	 * public void setDateReceivedInServer(java.util.Date date) {
	 * super.setDateReceivedInServer(date); this.put("yancees.published.date",
	 * this.getDateReceivedInServer().getTime());
	 *  }
	 */

	/**
	 * Once the time stamps are changed, or atributes are added or removed, this
	 * method must be called.
	 */
	private void invalidateCache() {
		messageDOM = null;
		textContent = null;
	}

	/**
	 * Changes the content of the event by providing a new XML representation
	 * for it. The representation is provided in the form of a DOM tree in the
	 * parameter n
	 */
	public void setDOM(Node n) throws MessageParsingException {
		messageDOM = n;
		textContent = null; // invalidate the text content
		// updateMetaInfo();
	}

	/**
	 * @return the DOM tree representing the current event. In other words,
	 *         builds a DOM tree with the attributes in this event, in an DOM
	 *         model format.
	 */
	public Node getDOM() {
		if (messageDOM == null) {
			messageDOM = buildEventDOMWithCurrentAttributes();
			textContent = null;
		}

		return messageDOM;
	}

	/**
	 * Builds a DOM tree, in the YanceesEvent.xsd format and populates it with
	 * the attributes of this event (if any)
	 * 
	 * @return the DOM tree generated
	 */
	private Node buildEventDOMWithCurrentAttributes() {
		Document document = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setValidating(VALIDATING);

		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			document = builder.newDocument(); // Create from whole cloth

			Element eventRoot = (Element) document.createElement(EVENT);
			document.appendChild(eventRoot);

			String key;
			Object value;

			Iterator iterator = eventAttributes.keySet().iterator();
			while (iterator.hasNext()) {
				key = (String) iterator.next();
				value = eventAttributes.get(key);

				/*
				 * System.out.println("Inserting attribute: ");
				 * System.out.println("name = "+key); System.out.println("value =
				 * "+value);
				 */
				insertAttributeInDOM(eventRoot, key, value);
			}
			// normalize text representation
			document.getDocumentElement().normalize();

		} catch (ParserConfigurationException pce) {
			// Parser with specified options can't be built
			System.out
					.println("YanceesEvent: Error when creating a new DOM document");
			System.out.println(pce);
		}

		return document;
	}

	/**
	 * Insert an <attribute> <name>...</name> <value>...</value> </attribute>
	 * construct under an <event> indicated by a Node object.
	 * 
	 * @param node
	 *            subtree reference which is an <event> tag
	 * @param name
	 *            the name of the attribute
	 * @param value
	 *            the attribute value (includding the type embedded
	 */
	private void insertAttributeInDOM(org.w3c.dom.Node node, String name,
			Object value) {

		Document doc;

		if (node != null) {
			doc = node.getOwnerDocument();
			Element attributeNode = doc.createElement(ATTRIBUTE);
			Element nameNode = doc.createElement(NAME);
			Element valueNode = doc.createElement(VALUE);

			Node textNode;
			textNode = doc.createTextNode(name);
			nameNode.appendChild(textNode);

			textNode = doc.createTextNode(value.toString());
			valueNode.appendChild(textNode);
			valueNode.setAttribute(TYPE_ATTRIBUTE, getAttributeType(value));

			node.appendChild(attributeNode);
			attributeNode.appendChild(nameNode);
			attributeNode.appendChild(valueNode);

			node.normalize();
		} else {
			System.out.println("cannot insert attribute: " + name + ": "
					+ value + " in null node");
		}
	}

	/**
	 * Builds an empty DOM tree, in the YanceesEvent.xsd format, to start
	 * receiving attributes.
	 * 
	 * @return
	 */
	private Node buildEmptyEventDOM() {
		Document document = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setValidating(VALIDATING);

		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			document = builder.newDocument(); // Create from whole cloth

			Element root = (Element) document.createElement(EVENT);
			document.appendChild(root);

			// normalize text representation
			document.getDocumentElement().normalize();

		} catch (ParserConfigurationException pce) {
			// Parser with specified options can't be built
			System.out
					.println("YanceesEvent: Error when creating a new DOM document");
			System.out.println(pce);
		}

		return document;
	}

	/**
	 * removes all the <attribute> elements from this <event> DOM tree
	 */
	private void clearAttributesSubtrees() {
		Node event = findSubtree(EVENT);
		NodeList list = event.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			event.removeChild(list.item(i));
		}
	}

	/**
	 * searches the current eventDOM for a subtree which ELEMENT_NODE name is
	 * the one provided. null is returned if the search is not successful.
	 * 
	 * @param element_name
	 *            is element to search for
	 * @return the ELEMENT_NODE with name element_name or null if it was not
	 *         found.
	 */
	private org.w3c.dom.Node findSubtree(String element_name) {
		// Node targetNode = null;
		Vector queue = new Vector();

		// System.out.println("findSubtree: looking for: "+element_name);
		// System.out.println("on eventDom "+eventDOM);
		if (messageDOM != null) {

			NodeList list;
			int nodeType;
			Node n = messageDOM;

			queue.add(n);
			while (queue.size() > 0) {
				list = ((Node) queue.get(0)).getChildNodes();
				queue.removeElementAt(0);

				// System.out.println("findSubtree: "+list.getLength()+" nodes
				// on branch");

				for (int i = 0; i < list.getLength(); i++) {
					n = list.item(i);
					nodeType = n.getNodeType();
					if (nodeType == Node.ELEMENT_NODE) {

						// System.out.println("findSubtree: found element:
						// "+n.getNodeName());

						if (n.getNodeName().startsWith(element_name)
								|| n.getNodeName().endsWith(":" + element_name)) {
							// System.out.println("findSubtree: returning
							// element: "+n.getNodeName());
							return n;
						} else {
							// System.out.println("findSubtree: queueing
							// element: "+n.getNodeName());
							queue.add(n);
						}
					}
				}

			}
		}

		return null;
	}

	/**
	 * 
	 * @return the <body> element node of the current eventDOM
	 */
	private org.w3c.dom.Node getEventSubtree() {
		Node bodyNode = findSubtree(EVENT);

		return bodyNode;
	}

	/**
	 * Extracts the attributes from the given DOM tree. It looks for the <event>
	 * tag and fires the parsing of the <attribute> tags in it. By the end of
	 * the operation the eventAttributes Map is populated with AttValue objects.
	 * 
	 * @param n
	 *            DOM tree to be processed, having its attributes extracted.
	 */
	private void extractAttributesFromDOM(org.w3c.dom.Node node)
			throws MessageParsingException {

		Node eventSubtree = null;

		if (node != null) {

			/**
			 * Makes sure the DOM corresponds to a valid event representation.
			 */
			if (node.getNodeName().endsWith(":" + EVENT)
					|| node.getNodeName().equals(EVENT)) {
				eventSubtree = node;
				parseEvent(eventSubtree);

				// It may happen that the node provided does not start with the
				// EVENT tag,
				// so we look at the children nodes
			} else {
				if (node.hasChildNodes()) {
					NodeList list = node.getChildNodes();
					// System.out.println("Tree has : "+list.getLength()+"
					// children");
					for (int i = 0; i < list.getLength(); i++) {
						Node myNode = list.item(i);
						// System.out.println("Checking for :
						// "+myNode.getNodeName());
						if (myNode.getNodeName().endsWith(":" + EVENT)
								|| myNode.getNodeName().equals(EVENT)) {
							eventSubtree = myNode;
							// System.out.println("Found :
							// "+myNode.getNodeName());
							break;
						}
					}
					if (eventSubtree == null) {
						throw new MessageParsingException(
								"Could not find a <event> node "
										+ "in tree headed by :"
										+ node.getNodeName());
					}
				}

				// After finding the first occurrence of EVENT we parse it.
				parseEvent(eventSubtree);
			}
		}
	}

	/**
	 * Parses a subtree headed by <event> tag. We assume that the XML DOM tree
	 * is gramatiacally correct.
	 * 
	 * @param node
	 *            is the reference to a DOM subtree head representing an event
	 */
	private void parseEvent(org.w3c.dom.Node node) {

		// System.out.println("parsing event");
		if (node != null && node.hasChildNodes()) {
			NodeList list = node.getChildNodes();
			// System.out.println("Tree has : "+list.getLength()+" children");

			for (int i = 0; i < list.getLength(); i++) {
				Node myNode = list.item(i);
				if (myNode.getNodeName().startsWith(ATTRIBUTE)
						|| myNode.getNodeName().endsWith(":" + ATTRIBUTE)) {
					parseAttribute(myNode, eventAttributes);
				}

			}
		}
	}

	/**
	 * 
	 * @param node
	 *            is a subtree reference headed by <attribute> tag
	 * @param destinationMap
	 *            is the destination structure to be poppulated with AttValue
	 *            objects represented in this tree.
	 */
	private void parseAttribute(org.w3c.dom.Node attributeDOM,
			Map destinationMap) {

		String attributeName = this.parseAttributeName(attributeDOM);
		Object value = this.parseAttValue(attributeDOM);
		destinationMap.put(attributeName, value);

	}

	/**
	 * Gets a construction like that:
	 * 
	 * <attribute> <name> someName </name> <value type="someType"> someValue
	 * </value> </attribute>
	 * 
	 * and returns the content "someValue", which is between <value> tags. It
	 * also returns the type "someType" in the construction. These are wrapped
	 * in an AttValue object.
	 * 
	 */
	private Object parseAttValue(org.w3c.dom.Node attributeDOM) {
		if (print) {
			System.out.println("parseAttValue");

		}
		Object attVal;
		String valueType;
		String stringValue;

		if (attributeDOM != null) {

			// selects the <value type="blabla"> 1234 <value> tag and
			// extracts its content and type
			NodeList list = attributeDOM.getChildNodes();
			int nodeType;
			Node n;
			for (int i = 0; i < list.getLength(); i++) {
				n = list.item(i);
				nodeType = n.getNodeType();
				if (nodeType == Node.ELEMENT_NODE) {
					if (n.getNodeName().startsWith(VALUE)
							|| n.getNodeName().endsWith(":" + VALUE)) {
						stringValue = parseNodeTextContent(n);
						valueType = parseNodeType(n);

						/*
						 * System.out.println("Found value: "+stringValue);
						 * System.out.println("Found type: "+valueType);
						 */
						return createObject(stringValue, valueType);
					}
				}
			}

		}

		return null;
	}

	/**
	 * Gets a construction like that:
	 * 
	 * <attribute> <name> someName </name> <value> someValue </value>
	 * </attribute>
	 * 
	 * and returns the content "someName", which is between <name> tags. null is
	 * returned in case the value is not found sienaOP is one of the valid
	 * OPERATORS supported by siena.
	 * 
	 */
	private String parseAttributeName(org.w3c.dom.Node attributeDOM) {
		if (print) {
			System.out.println("parseAttributeName");

		}
		if (attributeDOM != null) {

			NodeList list = attributeDOM.getChildNodes();
			int nodeType;
			Node n;
			for (int i = 0; i < list.getLength(); i++) {
				n = list.item(i);
				nodeType = n.getNodeType();
				if (nodeType == Node.ELEMENT_NODE) {
					if (n.getNodeName().startsWith(NAME)
							|| n.getNodeName().endsWith(":" + NAME)) {
						return parseNodeTextContent(n);
					}
				}
			}

		}

		return null;

	}

	/**
	 * @returns the value of the type attribute of a node if it exists, or null
	 *          if it was not found.
	 * 
	 * In other words, gets a constuction like:
	 * 
	 * <tag type="someType"> blablabla </tag>
	 * 
	 * and returns "someType", which is the content of the type attribute in the
	 * tag.
	 */
	private String parseNodeType(org.w3c.dom.Node node) {
		if (print) {
			System.out.println("parseNodeType");

		}
		Node tempNode;
		String name;
		if (node.hasAttributes()) {
			NamedNodeMap map = node.getAttributes();
			for (int i = 0; i < map.getLength(); i++) {
				tempNode = map.item(i);
				name = tempNode.getNodeName();
				if (name.equals(TYPE_ATTRIBUTE)
						|| name.endsWith(":" + TYPE_ATTRIBUTE)) {
					return tempNode.getNodeValue();
				}
			}
		}
		return null;
	}

	/**
	 * @return the text 'value' of a node like <element> value <element> or null
	 *         in case this value does not exist.
	 */
	private String parseNodeTextContent(org.w3c.dom.Node node) {
		if (print) {
			System.out.println("parseNodeTextContent");
		}
		NodeList list = node.getChildNodes();
		int nodeType;
		Node n;
		for (int i = 0; i < list.getLength(); i++) {
			n = list.item(i);
			nodeType = n.getNodeType();
			if (nodeType == Node.TEXT_NODE) {
				return n.getNodeValue().trim();
			}
		}

		return null;
	}

	/**
	 * Gets a string attribute
	 * 
	 * @param attName
	 *            is the name of the atribute to be retrieved
	 * @return the String type attribute or null if the attribute does not exist
	 *         or it cannot be converted to a string.
	 * @throws WrongAttributeTypeException
	 *             if the attribute exists but the type is wrong
	 */
	public String getString(String attName) throws WrongAttributeTypeException,
			AttributeNotFoundException {
		String value = null;
		Object obj = eventAttributes.get(attName);
		if (obj != null) {
			value = (String) obj.toString();
		} else {
			throw new AttributeNotFoundException("The attribute " + attName
					+ " is not part of the event");
		}

		return (String) value;
	}
	
	/**
	 * Gets a Byte array as an object
	 * @param attName
	 * @return an Object that was serialized as an attribute of the event
	 * @throws WrongAttributeTypeException
	 * @throws AttributeNotFoundException
	 */
	public Object getObject(String attName) throws WrongAttributeTypeException,
			AttributeNotFoundException {
		
		byte[] byteArray = getByteArray(attName);
		if (byteArray != null) {
			return Serialization.deserializeObject(byteArray); 
		} else {
			throw new AttributeNotFoundException("The attribute " + attName
					+ " is not part of the event");
		}
	}
	
	/**
	 * Gets a Byte array as an object array: Object[]
	 * @param attName
	 * @return an Object that was serialized as an attribute of the event
	 * @throws WrongAttributeTypeException
	 * @throws AttributeNotFoundException
	 */
	public Object[] getObjectArray(String attName) throws WrongAttributeTypeException,
			AttributeNotFoundException {
		
		byte[] byteArray = getByteArray(attName);
		if (byteArray != null) {
			return (Object[]) Serialization.deserializeObject(byteArray); 
		} else {
			throw new AttributeNotFoundException("The attribute " + attName
					+ " is not part of the event");
		}
	}

	/**
	 * Gets a double attribute
	 * 
	 * @param attName
	 *            is the name of the atribute to be retrieved
	 * @return the String type attribute or null if the attribute does not exist
	 *         or it cannot be converted to a string.
	 * @throws WrongAttributeTypeException
	 *             if the attribute exists but the type is wrong
	 */
	public double getDouble(String attName) throws WrongAttributeTypeException,
			AttributeNotFoundException {
		double value = 0.0;
		Object obj = eventAttributes.get(attName);
		if (obj != null) {
			if (obj instanceof Double) {
				value = ((Double) obj).doubleValue();
			} else if (obj instanceof Float) {
				value = ((Float) obj).doubleValue();
			} else if (obj instanceof Integer) {
				value = ((Integer) obj).doubleValue();
			} else if (obj instanceof Long) {
				value = ((Long) obj).doubleValue();
			} else {
				throw new WrongAttributeTypeException(
						"Attribute exists but cannot be converted to Double");
			}
		} else {
			throw new AttributeNotFoundException("The attribute " + attName
					+ " is not part of the event");
		}

		return value;
	}

	/**
	 * Gets a float attribute
	 * 
	 * @param attName
	 *            is the name of the atribute to be retrieved
	 * @return the String type attribute or null if the attribute does not exist
	 *         or it cannot be converted to a string.
	 * @throws WrongAttributeTypeException
	 *             if the attribute exists but the type is wrong
	 */
	public float getFloat(String attName) throws WrongAttributeTypeException,
			AttributeNotFoundException {
		float value = 0;
		Object obj = eventAttributes.get(attName);
		if (obj != null) {
			if (obj instanceof Double) {
				value = ((Double) obj).floatValue();
			} else if (obj instanceof Float) {
				value = ((Float) obj).floatValue();
			} else if (obj instanceof Integer) {
				value = ((Integer) obj).floatValue();
			} else if (obj instanceof Long) {
				value = ((Long) obj).floatValue();
			} else {
				throw new WrongAttributeTypeException(
						"Attribute exists but cannot be converted to Float");
			}
		} else {
			throw new AttributeNotFoundException("The attribute " + attName
					+ " is not part of the event");
		}

		return value;
	}

	/**
	 * Gets a int attribute
	 * 
	 * @param attName
	 *            is the name of the atribute to be retrieved
	 * @return the String type attribute or null if the attribute does not exist
	 *         or it cannot be converted to a string.
	 * @throws WrongAttributeTypeException
	 *             if the attribute exists but the type is wrong
	 */
	public int getInt(String attName) throws WrongAttributeTypeException,
			AttributeNotFoundException {
		int value = 0;
		Object obj = eventAttributes.get(attName);
		if (obj != null) {
			if (obj instanceof Double) {
				value = ((Double) obj).intValue();
			} else if (obj instanceof Float) {
				value = ((Float) obj).intValue();
			} else if (obj instanceof Integer) {
				value = ((Integer) obj).intValue();
			} else if (obj instanceof Long) {
				value = ((Long) obj).intValue();
			} else {
				throw new WrongAttributeTypeException(
						"Attribute exists but cannot be converted to Integer");
			}
		} else {
			throw new AttributeNotFoundException("The attribute " + attName
					+ " is not part of the event");
		}

		return value;
	}

	/**
	 * Gets a long attribute
	 * 
	 * @param attName
	 *            is the name of the atribute to be retrieved
	 * @return the String type attribute or null if the attribute does not exist
	 *         or it cannot be converted to a string.
	 * @throws WrongAttributeTypeException
	 *             if the attribute exists but the type is wrong
	 */
	public long getLong(String attName) throws WrongAttributeTypeException,
			AttributeNotFoundException {
		long value = 0;
		Object obj = eventAttributes.get(attName);
		if (obj != null) {
			if (obj instanceof Double) {
				value = ((Double) obj).longValue();
			} else if (obj instanceof Float) {
				value = ((Float) obj).longValue();
			} else if (obj instanceof Integer) {
				value = ((Integer) obj).longValue();
			} else if (obj instanceof Long) {
				value = ((Long) obj).longValue();
			} else {
				throw new WrongAttributeTypeException(
						"Attribute exists but cannot be converted to Long");
			}

		} else {
			throw new AttributeNotFoundException("The attribute " + attName
					+ " is not part of the event");
		}

		return value;
	}

	/**
	 * Gets a byte[] attribute
	 * 
	 * @param attName
	 *            is the name of the atribute to be retrieved
	 * @return the String type attribute or null if the attribute does not exist
	 *         or it cannot be converted to a string.
	 * @throws WrongAttributeTypeException
	 *             if the attribute exists but the type is wrong
	 */
	public byte[] getByteArray(String attName)
			throws WrongAttributeTypeException, AttributeNotFoundException {
		byte[] value = new byte[1];
		value[0] = 0;
		Object obj = eventAttributes.get(attName);
		if (obj != null) {
			if (obj instanceof byte[]) {
				value = (byte[]) obj;
			} else if (obj instanceof Double) {
				value[0] = ((Double) obj).byteValue();
			} else if (obj instanceof Float) {
				value[0] = ((Float) obj).byteValue();
			} else if (obj instanceof Integer) {
				value[0] = ((Integer) obj).byteValue();
			} else if (obj instanceof Long) {
				value[0] = ((Long) obj).byteValue();
			} else if (obj instanceof String) {
				value = ((String) obj).getBytes();
			} else {
				throw new WrongAttributeTypeException(
						"Attribute exists but cannot be converted to byte[]");
			}

		} else {
			throw new AttributeNotFoundException("The attribute " + attName
					+ " is not part of the event");
		}

		return value;
	}

	/**
	 * Gets a boolean attribute
	 * 
	 * @param attName
	 *            is the name of the atribute to be retrieved
	 * @return the String type attribute or null if the attribute does not exist
	 *         or it cannot be converted to a string.
	 * @throws WrongAttributeTypeException
	 *             if the attribute exists but the type is wrong
	 */
	public boolean getBoolean(String attName)
			throws WrongAttributeTypeException, AttributeNotFoundException {
		boolean value = false;
		Object obj = eventAttributes.get(attName);
		if (obj != null) {
			if (obj instanceof Boolean) {
				value = ((Boolean) obj).booleanValue();
			} else {
				throw new WrongAttributeTypeException(
						"Attribute exists but cannot be converted to boolean");
			}
		} else {
			throw new AttributeNotFoundException("The attribute " + attName
					+ " is not part of the event");
		}
		return value;
	}

	/**
	 * Removes every attribute from this YanceesEvent.
	 */
	public void clearAll() {
		eventAttributes.clear();
		this.messageDOM = null;
		this.textContent = null;
		invalidateCache();
		// updateMetaInfo();
	}

	public int numberOfAttributes() {
		return eventAttributes.size();
	}

	public Object get(String attName) {
		return eventAttributes.get(attName);
	}

	public void remove(String attName) {
		eventAttributes.remove(attName);
		invalidateCache();
	}

	public void put(String attName, String value) {

		eventAttributes.put(attName, value);
		if (messageDOM != null) {
			Node event = (new DOMNodeAdapter(messageDOM))
					.getFirstElementByName(EVENT);
			insertAttributeInDOM(event, attName, value);
		}
		invalidateCache();

	}

	public void put(String attName, double value) {

		Double localValue = new Double(value);
		eventAttributes.put(attName, localValue);
		if (messageDOM != null) {
			Node event = (new DOMNodeAdapter(messageDOM))
					.getFirstElementByName(EVENT);
			insertAttributeInDOM(event, attName, localValue);
		}
		invalidateCache();
	}

	public void put(String attName, float value) {

		Float localValue = new Float(value);
		eventAttributes.put(attName, localValue);
		if (messageDOM != null) {
			Node event = (new DOMNodeAdapter(messageDOM))
					.getFirstElementByName(EVENT);
			insertAttributeInDOM(event, attName, localValue);
		}
		invalidateCache();

	}

	public void put(String attName, boolean value) {

		Boolean localValue = new Boolean(value);
		eventAttributes.put(attName, localValue);
		if (messageDOM != null) {
			Node event = (new DOMNodeAdapter(messageDOM))
					.getFirstElementByName(EVENT);
			insertAttributeInDOM(event, attName, localValue);
		}
		invalidateCache();

	}

	public void put(String attName, byte[] value) {

		eventAttributes.put(attName, value);
		if (messageDOM != null) {
			Node event = (new DOMNodeAdapter(messageDOM))
					.getFirstElementByName(EVENT);
			insertAttributeInDOM(event, attName, value);
		}
		invalidateCache();

	}

	/**
	 * Puts an object that is serialized as a byte array. 
	 * @param attName
	 * @param value
	 */
	public void put(String attName, Object value) {
		put(attName, Serialization.serializeObject(value));
	}
	
	/**
	 * Puts an object array that is serialized as a byte array. 
	 * @param attName
	 * @param value
	 */
	public void put(String attName, Object[] arrayValue) {
		put(attName, Serialization.serializeObject(arrayValue));
	}

	public void put(String attName, int value) {

		Integer localValue = new Integer(value);
		eventAttributes.put(attName, localValue);
		if (messageDOM != null) {
			Node event = (new DOMNodeAdapter(messageDOM))
					.getFirstElementByName(EVENT);
			insertAttributeInDOM(event, attName, localValue);
		}
		invalidateCache();

	}

	public void put(String attName, long value) {

		Long localValue = new Long(value);
		eventAttributes.put(attName, localValue);
		if (messageDOM != null) {
			Node event = (new DOMNodeAdapter(messageDOM))
					.getFirstElementByName(EVENT);
			insertAttributeInDOM(event, attName, localValue);
		}
		invalidateCache();

	}

	/**
	 * Returns an iterator for the set of attribute names of this SienaEvent
	 * body.
	 */
	public Iterator getAttributeNamesIterator() {
		return eventAttributes.keySet().iterator();
	}

	public boolean containsAttribute(String name) {
		return eventAttributes.containsKey(name);
	}

	/**
	 * Prints the structure of the evetn using a free notation.
	 */
	public String toString() {
		StringBuffer sb = new StringBuffer();

		sb.append("\nEVENT:\n\n");

		for (Iterator i = eventAttributes.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			sb.append(key);
			sb.append(" = ");
			sb.append(eventAttributes.get(key));
			sb.append('\n');
		}
		return sb.toString();
	}

	/**
	 * Returns the XML type clause for this attribute, according to its Java
	 * type.
	 * 
	 * @param obj
	 * @return a string representing the type of the attribute.
	 */
	private String getAttributeType(Object obj) {
		String type = null;

		if (obj instanceof byte[]) {
			type = BINARY_TYPE;
		} else if (obj instanceof String) {
			type = STRING_TYPE;
		} else if (obj instanceof Boolean) {
			type = BOOLEAN_TYPE;
		} else if (obj instanceof Double) {
			type = DOUBLE_TYPE;
		} else if (obj instanceof Float) {
			type = FLOAT_TYPE;
		} else if (obj instanceof Long) {
			type = LONG_TYPE;
		} else if (obj instanceof Integer) {
			type = INT_TYPE;
		}

		return type;
	}

	/**
	 * Given a String value and a type, creates an object of that type with its
	 * corresponding value, according to its type.
	 * 
	 * @param attValue
	 * @param attType
	 * @return an object according to the type provided, with the value
	 *         specified.
	 */
	private Object createObject(String attValue, String attType) {
		Object unknownObject = null;

		if (attType.equals(BINARY_TYPE) || attType.endsWith(BINARY_TYPE)) {
			return attValue.getBytes();
		} else if (attType.equals(STRING_TYPE) || attType.endsWith(STRING_TYPE)) {
			return attValue;
		} else if (attType.equals(INT_TYPE) || attType.endsWith(INT_TYPE)) {
			return new Integer(attValue);
		} else if (attType.equals(BOOLEAN_TYPE)
				|| attType.endsWith(BOOLEAN_TYPE)) {
			return Boolean.valueOf(attValue);
		} else if (attType.equals(DOUBLE_TYPE) || attType.endsWith(DOUBLE_TYPE)) {
			return new Double(attValue);
		} else if (attType.equals(FLOAT_TYPE) || attType.endsWith(FLOAT_TYPE)) {
			return new Float(attValue);
		} else if (attType.equals(LONG_TYPE) || attType.endsWith(LONG_TYPE)) {
			return new Long(attValue);
		}

		return unknownObject;
	}

	/**
	 * Prints the XML hierarchy that represents the current event.
	 */
	/*
	 * public String toXML() { StringBuffer sb = new StringBuffer(); sb.append("<?xml
	 * version=\"1.0\" encoding=\"utf-8\" ?>\n"); sb.append( "<event " +
	 * "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" + "
	 * xsi:noNamespaceSchemaLocation=\"yanceesEvent.xsd\">\n");
	 * 
	 * for (Iterator i = eventAttributes.keySet().iterator(); i.hasNext();) {
	 * String key = (String) i.next(); String ident = " "; String step = " ";
	 * sb.append(ident + "<attribute>\n"); sb.append(ident + step + "<name>\n");
	 * sb.append(ident + step + step + key + '\n'); sb.append(ident + step + "</name>\n");
	 * sb.append(ident + step + "<value"); sb.append( " type = \"" +
	 * getAttributeType(eventAttributes.get(key)) + "\""); sb.append(">\n");
	 * sb.append( ident + step + step + eventAttributes.get(key) + '\n');
	 * sb.append(ident + step + "</value>\n"); sb.append(ident + "</attribute>\n");
	 * sb.append('\n'); }
	 * 
	 * sb.append("</event>\n");
	 * 
	 * return sb.toString();
	 *  }
	 */

	/**
	 * Changes the content of this message. Replaces it with the XML content
	 * provided in the String provided
	 * 
	 * @param content
	 *            is the new XML format contnet in the form of a String
	 */
	public void setXMLTextContent(String content) {
		extractAttributesFromText(content);
		invalidateCache();

	}

	/**
	 * @return the content of this message in the text form, as a string.
	 */
	public String getXMLTextContent() {
		DOMNodeAdapter adapt = new DOMNodeAdapter(this.getDOM());
		return adapt.toXML();

	}

	/**
	 * Parses the text content using SAX and replaces the current attributes by
	 * the attributes in the text. If the text is null, nothing is done.
	 * 
	 * @param text
	 *            is the XML text in memory to be parsed.
	 */
	protected void extractAttributesFromText(String text) {
		if (text != null) {

			String tempFilePath = writeTextToTempFile(text);
			// we need to open it again here because it is closed by the
			// writeFileContent method...
			File tempFile = new File(tempFilePath);

			extractAttributesFromFileUsingSAX(tempFile);

			tempFile.delete(); // do not let trash behind...
			// updateMetaInfo();
		}
	}

	/**
	 * Parses the content of the file into attributes of this event, using a
	 * fast SAX parser instead of a DOM parser. All the attributes of this event
	 * are lost and the new attributes parsed are added instead.
	 * 
	 * @param file
	 *            is the file having the XML representation of the event.
	 */
	private void extractAttributesFromFileUsingSAX(File file) {
		YanceesEventSAXParser.parseFile(file, this);

	}

	// ------------------------- Reconstruction methods
	// ----------------------------

	/**
	 * used to reconstruct the id when an event is re-created in the ohter side
	 * of the network
	 * 
	 * @param newDate
	 *            is the original creation date of the object.
	 */
	public void setDateCreated(Date newDate) {
		this.dateCreated = newDate;
	}

	/**
	 * used to reconstruct the id when an event is re-created in the ohter side
	 * of the network
	 * 
	 * @param originalId
	 *            is the original id of this event
	 */
	public void setID(long originalId) {
		this.myId = originalId;
	}

	// ----------------------------- garbage collection
	// ---------------------------
	protected void finalize() throws Throwable {

		// System.out.println("YanceesEvent: garbage collecting event:
		// "+this.getId());
		super.finalize();
	}

}
