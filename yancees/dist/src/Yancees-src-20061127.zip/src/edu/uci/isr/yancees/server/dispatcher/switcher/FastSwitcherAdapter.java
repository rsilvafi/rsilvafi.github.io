/*
 * Copyright (c) 2003, Regents of the University of California.
 * All rights reserved.
 *
 * ===================================================================
 * The Apache Software License, Version 1.1
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 *
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 *
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */

/*
 * Created on Mar 13, 2004
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 * @version 1.0
 */
package edu.uci.isr.yancees.server.dispatcher.switcher;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.SubscriptionInterface;
import edu.uci.isr.yancees.YanceesEvent;
import edu.uci.isr.yancees.core.MessageParsingException;
import edu.uci.isr.yancees.dispatcher.DispatcherException;
import edu.uci.isr.yancees.dispatcher.EventDispatcherAdapterInterface;
import edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface;

/**
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class FastSwitcherAdapter implements EventDispatcherAdapterInterface {

	public static final String ADAPTER_NAME = "FastSwitcherAdapter";
	public static final String ALL_TAG = "*";

	public boolean print = edu.uci.isr.yancees.YanceesProperties.getInstance().PRINT_DEBUG;

	Map fieldsToListenersListMap = new HashMap();
	Map subscriberToRecordListMap = new HashMap();

	/**
	 * constructor
	 */
	public FastSwitcherAdapter() {
		super();
		// no conections necessary, it is a local component
		System.out.println("FastSwitcher: Running local fast switcher.");
	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#publish(edu.uci.isr.yancees.EventInterface)
	 */
	public void publish(EventInterface evnt) throws DispatcherException {
		YanceesEvent localEvent = null;

		if (! fieldsToListenersListMap.isEmpty()) {

			// we force the parsing in case the event is a generic text file...
			if (! (evnt instanceof YanceesEvent)) {
				//try {
					localEvent = new YanceesEvent(evnt.getXMLTextContent());
				/*
			    } catch (ParsingException e) {
					System.out.println("FastSwitcherAdapter: error when parsing event DOM "+e);
					e.printStackTrace();
				}
				*/
			} else {
				localEvent = (YanceesEvent) evnt;
			}
			// at this point we have the event ready to be delivered to the interested parties

			if (localEvent != null) {

				Vector listenersList;
				EventDispatcherListenerInterface li;

				// This piece of code looks for subscriptions to ALL events and routes them first.
				listenersList = (Vector) fieldsToListenersListMap.get(ALL_TAG);
				if (listenersList != null) {
					for (Iterator iter = listenersList.iterator(); iter.hasNext();) {
						li = (EventDispatcherListenerInterface) iter.next();
						li.receiveDispatcherNotification(localEvent);
					}
				}

				// Looks for subscriptions to specific fields
				String element;
				for (Iterator iter = fieldsToListenersListMap.keySet().iterator(); iter.hasNext();) {
					element = (String) iter.next();

					/*
					 * even though the "*" will be matched here, it will not be published sice,
					 * we assume that attribute name will never be called "*";
					 */
					 if (! element.equals(ALL_TAG)) {
						if (localEvent.containsAttribute(element)) {
							listenersList = (Vector) fieldsToListenersListMap.get(element);
							for (int i = 0; i < listenersList.size(); i++) {
								li = (EventDispatcherListenerInterface) listenersList.get(i);
								li.receiveDispatcherNotification(localEvent);
							}

						}
					 }
				}

			}
		}

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#subscribe(edu.uci.isr.yancees.SubscriptionInterface, edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface)
	 */
	public void subscribe(
		SubscriptionInterface subscription,
		EventDispatcherListenerInterface listenerInterface)
		throws DispatcherException {

		boolean parsingSuccessfull = true;

		SubscriptionRecord record = null;
		try {
			record = new SubscriptionRecord(listenerInterface, subscription);
		} catch (MessageParsingException e) {
			parsingSuccessfull = false;
			System.out.println("FastSwitcher: parsing exceptions ");
			System.out.println(e);
		}

		if (parsingSuccessfull && record != null) {

			Vector recordList = (Vector) subscriberToRecordListMap.get(listenerInterface);
			if (recordList == null) {
				recordList = new Vector();
				subscriberToRecordListMap.put(listenerInterface, recordList);
			}

			String[] requireFields = record.getRequireFields();

			if (requireFields != null) {
				recordList.add(record);
				Vector listenersList;
				for (int i = 0; i < requireFields.length; i++) {
					listenersList = (Vector) fieldsToListenersListMap.get(requireFields[i]);
					if (listenersList == null) {
						listenersList = new Vector();
						fieldsToListenersListMap.put(requireFields[i], listenersList);
					}
					if (! listenersList.contains(listenerInterface)) {
						listenersList.add(listenerInterface);
					}
				}
			}
		} else {
			if (print)
				System.out.println("FastSwitcherAdapter: Wrong format, ignoring subscription.");
		}

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#unsubscribe(edu.uci.isr.yancees.SubscriptionInterface, edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface)
	 */
	public void unsubscribe(
		SubscriptionInterface sub,
		EventDispatcherListenerInterface li)
		throws DispatcherException {

		Vector recordList = (Vector) subscriberToRecordListMap.get(li);

		if (recordList != null) {
			String[] requireArray = new String[0];
			for (Iterator iter = recordList.iterator(); iter.hasNext();) {
				SubscriptionRecord element = (SubscriptionRecord) iter.next();
				if (element.getSubscription() == sub) {
					requireArray = element.getRequireFields();
					recordList.remove(element);
					break;
				}
			}
			// remote li from the listener lists of the require topics
			Vector listenersList;
			for (int i = 0; i < requireArray.length; i++) {
					listenersList = (Vector) fieldsToListenersListMap.get(requireArray[i]);
					if (listenersList != null) {
						listenersList.remove(li);
					}
			}

		}

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#unsubscribe(edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface)
	 */
	public void unsubscribe(EventDispatcherListenerInterface li)
		throws DispatcherException {
		Vector records = (Vector) this.subscriberToRecordListMap.get(li);
		if (records != null) {
			for (Iterator iter = records.iterator(); iter.hasNext();) {
				SubscriptionRecord element = (SubscriptionRecord) iter.next();
				String[] requireArray = element.getRequireFields();
				Vector listenersList;
				for (int i = 0; i < requireArray.length; i++) {
						listenersList = (Vector) fieldsToListenersListMap.get(requireArray[i]);
						if (listenersList != null) {
							listenersList.remove(li);
						}
				}
			}
			subscriberToRecordListMap.remove(li);
		}

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#suspendDispatcher(edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface)
	 */
	public void suspendDispatcher(EventDispatcherListenerInterface li)
		throws DispatcherException {
		// does not require this method

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#resumeDispatcher(edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface)
	 */
	public void resumeDispatcher(EventDispatcherListenerInterface li)
		throws DispatcherException {
		// does not require this method

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#shutdownDispatcher()
	 */
	public void shutdownDispatcher() throws DispatcherException {
		// does not require this method
	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#connect(java.lang.String)
	 */
	public void connect(String address) throws DispatcherException {
		// does nothing here since the implementation is local

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#getAdapterName()
	 */
	public String getAdapterName() {
		return ADAPTER_NAME;
	}


	/**
	 * Stores information about the subscription for further reference.
	 */
	private class SubscriptionRecord {
		private EventDispatcherListenerInterface dispatcherListener;
		private SubscriptionInterface subscription;
		String[] requireFields = null;

		public SubscriptionRecord(EventDispatcherListenerInterface listener,
		                          SubscriptionInterface sub) throws MessageParsingException {
			subscription = sub;
			dispatcherListener = listener;

			requireFields = (new SwitcherSubscription(sub.getXMLTextContent())).getRequireFields();

		}

		/**
		 *
		 * @return the require fields parsed in the XML subscription
		 */
		public String[] getRequireFields() {
			return requireFields;
		}

		/**
		 * We need the subscription here for processing unsubscribe(sub, li)
		 * @return
		 */
		public SubscriptionInterface getSubscription() {
			return subscription;
		}

	}

}
