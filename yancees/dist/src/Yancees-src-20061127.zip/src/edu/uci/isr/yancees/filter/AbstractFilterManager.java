/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 /*
 * Created on Aug 29, 2003
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */
package edu.uci.isr.yancees.filter;

import java.util.HashMap;
import java.util.Vector;

import edu.uci.isr.yancees.EventInterface;


/**
 * This class manages the current instances of services, special plug-ins
 * that can be shared by all other plugins.
 */
public abstract class AbstractFilterManager implements FilterManagerInterface {

	private boolean print = edu.uci.isr.yancees.YanceesProperties.getInstance().PRINT_DEBUG;
	private Vector filterList;
	private HashMap filterMap;
	private ResponseCollectorFilter responseCollector;

	/**
	 * Constructor
	 */
	public AbstractFilterManager() {
		filterList = new Vector();
		filterMap = new HashMap();
		responseCollector = new ResponseCollectorFilter();
	}

	/**
	 * @return the number of filters installed.
	 */
	public int getNumberOfFilters() {
		return filterList.size();
	}

	/**
	 * 
	 * @param name is the unique name of the filter
	 * @return the filter registered under the unique name
	 */
	public FilterInterface getFilterByName(String name) {
		return (FilterInterface) filterMap.get(name);
	}

	/**
	 * 
	 * @return the list of all the filters, in the order they are installed
	 */
	public FilterInterface[] getFilters() {
		FilterInterface[] list = new FilterInterface[filterList.size()];
		filterList.copyInto(list);
		return list;
	}

	/**
	 * Add a filter to the end of a list and register it under a name
	 * @param filter is the filter to be inserted after all current filters
	 * @param name is the name of the filter
	 */
	public void addFilter(FilterInterface filter) {
		FilterInterface lastFilter = null;
		if (filterList.size() > 0)
			lastFilter = (FilterInterface) filterList.lastElement();
		if (lastFilter != null)
			lastFilter.addSuccessor(filter);

		filterList.add(filter); // add at the end
		filterMap.put(filter.getName(), filter); // associate with a name
	}

	/**
	 * @param i is the position of the filter to be returned
	 * @return the filter at the provided position
	 */
	public FilterInterface getFilterAt(int i) {
		FilterInterface selectedFilter = null;
		if (i < filterList.size()) {
			selectedFilter = (FilterInterface) filterList.get(i);
		}
		return selectedFilter;
	}

	/**
	 * Insters a filter in the provided position in the filters stream
	 * @param filter is the filter to be inserted
	 * @param i is the position to insert the filter
	 */
	public void insertFilterAt(FilterInterface filter, int i) {
		if (i < filterList.size()) {
			FilterInterface previousFilter = (FilterInterface) filterList.get(i);
			FilterInterface successor = previousFilter.getSuccessor();
			filter.addSuccessor(successor);

			previousFilter.removeSuccessor();

			filterList.insertElementAt(filter, i);
			filterMap.put(filter.getName(), filter);
		}
	}

	/**
	 * Remove the element at provided position from filters streams
	 * @param i is the position of the filter to be removed
	 */
	public void removeFilterAt(int i) {
		FilterInterface toBeRemoved;
		FilterInterface previous;
		if (i < filterList.size()) {
			if (i > 0) {
				toBeRemoved = (FilterInterface) filterList.elementAt(i);
				previous = (FilterInterface) filterList.elementAt(i - 1);
				FilterInterface successor = toBeRemoved.getSuccessor();
				previous.addSuccessor(successor);
				previous.removeSuccessor();
			}
			filterMap.remove(
				((FilterInterface) filterList.elementAt(i)).getName());
			filterList.remove(i);

		}
	}

	/**
	 * Passes the even throught the chain of responsibility and returnes the event
	 * which is produced by the last filter of the chain. For such, it registers a
	 * temporary filter at the end of the stream to colelct this response.
	 * @see yancees.filter.FilterManagerInterface#filterEvent(yancees.core.EventInterface)
	 */
	public EventInterface[] filterEvent(EventInterface evt) {

		if (filterList.size() > 0) {
			FilterInterface firstFilter = (FilterInterface) filterList.get(0);
			FilterInterface lastFilter =
				(FilterInterface) filterList.lastElement();
			lastFilter.addSuccessor(responseCollector);
			firstFilter.handleMessage(evt);
			lastFilter.removeSuccessor();
		}
		EventInterface[] response = responseCollector.getCollectedEvents();
		return response;
	}

	/**
	 * Filters a set of events
	 * @see yancees.filter.FilterManagerInterface#filterEventList(yancees.core.EventInterface[])
	 */
	public EventInterface[] filterEventList(EventInterface[] evtList) {

		if (filterList.size() > 0) {
			FilterInterface firstFilter = (FilterInterface) filterList.get(0);
			FilterInterface lastFilter =
				(FilterInterface) filterList.lastElement();
			lastFilter.addSuccessor(responseCollector);
			firstFilter.handleMessage(evtList);
			lastFilter.removeSuccessor();
		}
		EventInterface[] responseList = responseCollector.getCollectedEvents();
		return responseList;
	}

	/**
	 * This "dummy" filter only collects the event posted to it by the chain of
	 * responsibilty of filters
	 * It is used to collect the resultant event generated by the multiple filtering
	 * performed in this class.
	 * @author rsilvafi
	 *
	 */
	public class ResponseCollectorFilter extends AbstractFilter {

		private EventInterface[] collectedEvents = new EventInterface[0];
		private final String FILTER_NAME = "response.collector";

		public ResponseCollectorFilter() {
			super();
			this.setName(FILTER_NAME);
		}

		public EventInterface[] getCollectedEvents() {
			return collectedEvents;
		}

		public EventInterface[] doFilterEvent(EventInterface evt) {
			collectedEvents = new EventInterface[1];
			collectedEvents[0] = evt;
			
			return null;
			
		}

		public EventInterface[] doFilterEventList(EventInterface[] evtList) {
			collectedEvents = evtList;
			
			return null;
		
		}
	}

}
