/*
 * Copyright (c) 2003, Regents of the University of California.
 * All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE INSTITUTE FOR SOFTWARE RESEARCH AT THE UNIVERSITY
 * OF CALIFORNIA, IRVINE, OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 
package edu.uci.isr.yancees.server.plugin.protocol.eventhistory;

import java.rmi.RemoteException;
import java.util.Date;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.server.rmi.RemoteProtocolPluginInterface;


/**
 * @author rsilvafi
 * class created at Jun 14, 2004
 * 
 * This is the RMI front end for the protocol that turns on and off the event
 * histroy logging, and that gets the history of events
 * 
 */

public interface RemoteEventHistoryProtocolPluginInterface extends RemoteProtocolPluginInterface {
	
	/**
	 * tells YANCEES to start recording the events
	 * @throws RemoteException
	 */
	public void startRecordingEvents() throws RemoteException;

	/**
	 * tells YANCEES to stop recording events
	 * @throws RemoteException
	 */
	public void stopRecordingEvents() throws RemoteException;
	
	/**
	 * 
	 * @param beginDate is the initial date
	 * @param endDate is the final date
	 * @return a list of events within the provided period of time
	 * @throws RemoteException
	 */
	public EventInterface[] getHistory(Date beginDate, Date endDate) throws RemoteException;
}
