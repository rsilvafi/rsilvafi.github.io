/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package examples;

// used to get attributes// used to get child nodes
// used to get attributes
// used to get child nodes
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.GenericMessage;
import edu.uci.isr.yancees.YanceesException;
import edu.uci.isr.yancees.server.rmi.RemoteSubscriberImplementation;
import edu.uci.isr.yancees.server.rmi.RemoteSubscriberInterface;
import edu.uci.isr.yancees.server.rmi.RemoteYanceesInterface;

public class RMISubscriber
      extends RemoteSubscriberImplementation {

   public RMISubscriber() throws RemoteException {
      super();
   }

   public static void main(String argv[]) {
      RemoteYanceesInterface yanceesRemote = null;
      String hostname;
      String fileName;

      if (argv.length != 2) {
         System.err.println("Usage: java RMISubscriber hosthame subscription.xml");
         System.exit(1);
      }

      hostname = argv[0];
      fileName = argv[1];

      GenericMessage msg = null;

      try {
         msg = new GenericMessage(new File(fileName));
      } catch (IOException ex) {
         System.out.println(ex);
      }
      if (msg == null) {
         System.exit(1);
      }

      // Create an instance of this class
      RMISubscriber myInstance;
      try {
         System.out.println("RMISubscriber: Binding to yancees remote implementation at host " +
                            hostname+"...");
         yanceesRemote = (RemoteYanceesInterface) Naming.lookup("//" + hostname +
               "/"+RemoteYanceesInterface.LOOKUP_NAME);
      } catch (NotBoundException ex) {
         System.out.println(ex);
         System.out.println("RMISubscriber: Make sure yancees server is running.");
         System.exit(1);
      } catch (MalformedURLException ex) {
         System.out.println(ex);
         System.out.println("RMISubscriber: Check hostname in command line.");
         System.exit(1);
      } catch (RemoteException ex) {
         System.out.println(ex);
         System.exit(1);
      }


      try {
         myInstance = new RMISubscriber();
         yanceesRemote.subscribe(msg, (RemoteSubscriberInterface) myInstance);
      } catch (YanceesException ex) {
         System.out.println(ex);
      } catch (RemoteException ex) {
         System.out.println(ex);
      }

      System.out.println("RMISubscriber: Waiting for notifications...");
      /*
      while (true) {
         try {
            Thread.sleep(500);
         } catch (InterruptedException ex) {
            System.out.println(ex);
         }
      }
      */

   } // main


   /**
    * sends an <code>Event</code> to this <code>Subscriber</code>
    *
    * @param n Event passed to the Subscriber
    *
    **/
   public void notify(EventInterface evt) throws RemoteException {
      System.out.println("RMISubscriber: got Event: \n\n" + evt.toString());
   }

   /**
    * sends a sequence of <code>Event</code> evt to this
    * <code>Subscriber</code>
    *
    * @param s sequence of Events passed to the Subscriber
    *
    **/
   public void notify(EventInterface[] evtList) throws RemoteException {
      for (int i = 0; i < evtList.length; i++) {
         System.out.println("RMISubscriber: got Event: \n\n" + evtList[i].toString());
      }

   }

}