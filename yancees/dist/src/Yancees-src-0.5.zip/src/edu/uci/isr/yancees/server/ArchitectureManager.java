/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.server;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.io.File;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Vector;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import edu.uci.isr.yancees.server.core.ActivePluginInstancesRegistry;
import edu.uci.isr.yancees.server.core.DispatcherException;
import edu.uci.isr.yancees.server.core.EventDispatcher;
import edu.uci.isr.yancees.server.core.EventDispatcherInterface;
import edu.uci.isr.yancees.server.core.NotificationManager;
import edu.uci.isr.yancees.server.core.ParsingException;
import edu.uci.isr.yancees.server.core.ProtocolManager;
import edu.uci.isr.yancees.server.core.SubscriptionManager;
import edu.uci.isr.yancees.server.filter.FilterInterface;
import edu.uci.isr.yancees.server.filter.FilterManagerInterface;
import edu.uci.isr.yancees.server.filter.InputFilterManager;
import edu.uci.isr.yancees.server.filter.OutputFilterManager;
import edu.uci.isr.yancees.server.plugin.PluginFactoryInterface;
import edu.uci.isr.yancees.server.plugin.PluginManager;
import edu.uci.isr.yancees.server.plugin.PluginManagerInterface;
import edu.uci.isr.yancees.server.service.ServiceInterface;
import edu.uci.isr.yancees.server.service.ServiceManager;
import edu.uci.isr.yancees.util.DOMNodeAdapter;
import edu.uci.isr.yancees.util.DOMParser;

/**
 * That's a parser that reads an architecture description and assembly the notification
 * server architecture. It is also a dynamic change manager of the components.
 */
public class ArchitectureManager {

	private static ArchitectureManager myInstance; // Unique instance reference

	private EventDispatcher dispatcher;
	private SubscriptionManager subscriptionManager;
	private NotificationManager notificationManager;
	private ProtocolManager protocolManager;

	private InputFilterManager inputFilterManager;
	private OutputFilterManager outputFilterManager;
	private ServiceManager serviceManager;

	private ActivePluginInstancesRegistry subscriptionDB;

	// One plug-in manager to each one of them to prevent name clashes.
	private PluginManagerInterface subscriptionPluginManager;
	private PluginManagerInterface notificationPluginManager;
	private PluginManagerInterface protocolPluginManager;

	private final String ARCHITECTURE_TAG = "architecture";
	private final String DISPATCHER_TAG = "dispatcher";
	private final String SUBSCRIPTION_TAG = "subscription";
	private final String NOTIFICATION_TAG = "notification";
	private final String PROTOCOL_TAG = "protocol";
	private final String INPUT_FILTERS_TAG = "inputFilters";
	private final String OUTPUT_FILTERS_TAG = "outputFilters";
	private final String FILTER_TAG = "filter";
	private final String SERVICES_TAG = "services";
	private final String SERVICE_TAG = "service";

	private final String PLUGIN_TAG = "plugin";
	private final String MAIN_CLASS_TAG = "mainClass";
	private final String FACTORY_CLASS_TAG = "factoryClass";

	final String NAME_TAG = "name";
	final String DESCRIPTION_TAG = "description";
	final String DEPENDS_TAG = "depends";
	final String AUX_CLASS_TAG = "auxClass";

	final String URI_TAG = "uri";
	// main subgroup tags
	final String SERVER_TAG = "server";
	final String ADAPTER_TAG = "adapter";

	private final String JAVA_CLASS_NAME = "javaClassName";

	private boolean print = edu.uci.isr.yancees.server.YanceesServer.PRINT_DEBUG;

	// the list of components already installed
	// it is used to check for components dependency.
	private Vector installedComponentNames = new Vector();

	// colelcts the individual dependencies of each plug-in
	private HashMap dependencyLists = new HashMap();

	/**
	       * @return the unique instance of PlugInManager. This method should be called
	 * as an alternative to the new command
	 */
	public static ArchitectureManager getInstance() {
		if (myInstance == null) {
			myInstance = new ArchitectureManager();
		}
		return myInstance;
	}

	/**
	 * Initializes the architecture using the default configuration
	 */
	public void initialize() {

		if (print)
			System.out.println(
				"ArchitectureManager: initializing with no configuration file");

		createComponents();
		configureArchitecture();

	}

	/**
	 * Initializes the architecture based on a configuratio file
	 * @param configFile is the XML file containing the configuration
	 */
	public void initialize(File configFile) throws ParsingException {
		if (print)
			System.out.println(
				"ArchitectureManager: initializing with config file " + configFile);
		createComponents();
		configureArchitecture(configFile);
	}

	/**
	 * Protected here prevents direct instantiation of this singleton but allows
	 * the extension of this class and the invocation of this construction by the
	 * specializatio class.
	 */
	protected ArchitectureManager() {
	}

	/**
	 * Creates the components of the architecture before configuring them.
	 */
	private void createComponents() {
		if (print)
			System.out.println("ArchitectureManager: creating components...");

		dispatcher = EventDispatcher.getInstance();
		subscriptionManager = SubscriptionManager.getInstance();
		notificationManager = NotificationManager.getInstance();
		protocolManager = ProtocolManager.getInstance();

		subscriptionPluginManager = new PluginManager();
		notificationPluginManager = new PluginManager();
		protocolPluginManager = new PluginManager();

		subscriptionManager.setPluginManager(subscriptionPluginManager);
		notificationManager.setPluginManager(notificationPluginManager);
		protocolManager.setPluginManager(protocolPluginManager);

		subscriptionDB = ActivePluginInstancesRegistry.getInstance();

		inputFilterManager = InputFilterManager.getInstance();
		outputFilterManager = OutputFilterManager.getInstance();
		serviceManager = ServiceManager.getInstance();

	}

	/**
	 * Configures the architecture based on a configuration file.
	 * We assume that the basic components of the system are already instantiated
	 * by the command createComponents();
	 *
	 * This method looks for the <architecture> tag and processes the <subscription>
	 * <notification>, <protocol> and <dispatcher> tags as they are found in this
	 * architecture declaration. If errors are found, an exception is rased.
	 *
	 * We assume that the file is gramatically correct, which is assured by the
	 * XML DOM parser.
	 *
	 * @param fileName is the configuration XML file with the plug-ins and dispatcher information.
	 * @throws parsingException in case of parsing errors.
	 */
	public void configureArchitecture(File fileName) throws ParsingException {
		DOMParser parser = new DOMParser(fileName);
		Document parsedDoc = parser.getDocument();

		if (print)
			System.out.println("ArchitectureManager: start parsing...");

		if (parsedDoc != null) {
			DOMNodeAdapter adapter = new DOMNodeAdapter(parsedDoc);
			Node archNode = adapter.getFirstElementByName(ARCHITECTURE_TAG);

			if (archNode == null) {
				throw new ParsingException(
					"ArchitectureManager: <"
						+ ARCHITECTURE_TAG
						+ "> not found in "
						+ fileName);
			}
			DOMNodeAdapter archAdapt = new DOMNodeAdapter(archNode);

			Node[] dispatcherNodes = archAdapt.getElementsByName(DISPATCHER_TAG);
			if (dispatcherNodes.length >0) {
				for (int i = 0; i < dispatcherNodes.length; i++) {
					parseDispatcher(dispatcherNodes[i]);	
				}
				
			} else {
				throw new ParsingException(
					"ArchitectureManager: <"
						+ DISPATCHER_TAG
						+ "> not found in "
						+ fileName);
			}

			Node subscriptionNode =
				archAdapt.getFirstElementByName(SUBSCRIPTION_TAG);
			if (subscriptionNode != null) {
				parseSubscription(subscriptionNode);
			} else {
				throw new ParsingException(
					"ArchitectureManager: <"
						+ SUBSCRIPTION_TAG
						+ "> not found in "
						+ fileName);
			}

			Node notificationNode =
				archAdapt.getFirstElementByName(NOTIFICATION_TAG);
			if (notificationNode != null) {
				parseNotification(notificationNode);
			} else {
				/*
				throw new ParsingException(
					"ArchitectureManager: <"
						+ NOTIFICATION_TAG
						+ "> not found in "
						+ fileName);
				*/
			}

			Node protocolNode = archAdapt.getFirstElementByName(PROTOCOL_TAG);
			if (protocolNode != null) {
				parseProtocol(protocolNode);
			} else {
				/*
				throw new ParsingException(
					"ArchitectureManager: <"
						+ PROTOCOL_TAG
						+ "> not found in "
						+ fileName);
				*/
			}

			Node inputFiltersNode =
				archAdapt.getFirstElementByName(INPUT_FILTERS_TAG);
			if (inputFiltersNode != null) {
				parseInputFilters(inputFiltersNode);
			} else {
				/*
				throw new ParsingException(
					"ArchitectureManager: <"
						+ INPUT_FILTERS_TAG
						+ "> not found in "
						+ fileName);
				*/
			}

			Node outputFiltersNode =
				archAdapt.getFirstElementByName(OUTPUT_FILTERS_TAG);
			if (outputFiltersNode != null) {
				parseOutputFilters(outputFiltersNode);
			} else {
				/*
				throw new ParsingException(
					"ArchitectureManager: <"
						+ OUTPUT_FILTERS_TAG
						+ "> not found in "
						+ fileName);
				*/
			}

			Node servicesNode = archAdapt.getFirstElementByName(SERVICES_TAG);
			if (servicesNode != null) {
				parseServices(servicesNode);
			} else {
				/*
				throw new ParsingException(
					"ArchitectureManager: <"
						+ SERVICES_TAG
						+ "> not found in "
						+ fileName);
				*/
			}

		} else {
			throw new ParsingException(
				"ArchitectureManager: error reading and parsing file: "
					+ fileName
					+ ". the document provided is null.");
		}

		registerDefaultPlugins();
		ckeckPluginDependencies();
	}

	/**
	 * Parses a <dispatcher> declaration such as:
	 *  <arch:dispatcher xsi:type="arch:DispatcherConfigurationType">
	 *
	 *  <arch:server xsi:type="arch:NotificationServerType">
	 *     <arch:name>
	 *        siena.server
	 *     </arch:name>
	 *     <arch:uri>
	 *        tcp:localhost:1234
	 *     </arch:uri>
	 *  </arch:server>
	 *
	 *  <arch:adapter xsi:type="arch:JavaClassFile">
	 *     <arch:javaClassName xsi:type="arch:JavaClassName">
	 *        yancees.core.siena.SienaAdapter
	 *     </arch:javaClassName>
	 *  </arch:adapter>
	 *
	 * </arch:dispatcher>
	 *
	 * @param node is a XML DOM node representing a <dispatcher> node
	 * @throws ParsingException is thrown whenever a semantic error is found
	 */
	private void parseDispatcher(Node node) throws ParsingException {

		if (print)
			System.out.println("ArchitectureManager: creating dispatcher...");

		DOMNodeAdapter dispatcherAdapt = new DOMNodeAdapter(node);
		Node serverNode = dispatcherAdapt.getFirstElementByName(SERVER_TAG);
		Node adapterNode = dispatcherAdapt.getFirstElementByName(ADAPTER_TAG);

		// We do not have plug-ins here anymore...
		//Node pluginNode = dispatcherAdapt.getFirstElementByName(PLUGIN_TAG);
		//parseAndRegisterPlugin(pluginNode, subscriptionPluginManager);

		// moves into the notification SERVER declaration
		// collects uri and name in this section.
		String serverNameValue = null;
		String uriValue = null;
		if (serverNode != null) {
			DOMNodeAdapter serverAdapter = new DOMNodeAdapter(serverNode);

			Node nameNode = serverAdapter.getFirstElementByName(NAME_TAG);
			Node uriNode = serverAdapter.getFirstElementByName(URI_TAG);

			if (nameNode != null)
				serverNameValue = (new DOMNodeAdapter(nameNode)).getNodeText();
			if (uriNode != null)
				uriValue = (new DOMNodeAdapter(uriNode)).getNodeText();

			if (print) {
				System.out.println("ArchitectureManager: Server declaration:");
				System.out.println("ArchitectureManager: name: " + serverNameValue);
				System.out.println("ArchitectureManager: uri: " + uriValue);
			}

		} else {
			throw new ParsingException(
				"No <" + SERVER_TAG + "> declaration found in file.");
		}

		// moves into the ADAPTER declaration, the one that speaks the notification server protocol
		// collects the class name of the adapter
		String adapterClassName = null;
		if (adapterNode != null) {
			DOMNodeAdapter adapterAdapter = new DOMNodeAdapter(adapterNode);
			Node adapterClassNode =
				adapterAdapter.getFirstElementByName(JAVA_CLASS_NAME);
			if (adapterClassNode != null)
				adapterClassName =
					(new DOMNodeAdapter(adapterClassNode)).getNodeText();
			if (print) {
				System.out.println("ArchitectureManager: Adapter declaration:");
				System.out.println(
					"ArchitectureManager: class name: " + adapterClassName);
			}

		} else {
			throw new ParsingException(
				"No <" + ADAPTER_TAG + "> delcaration found in file");
		}

		if (print) {
			System.out.println(
				"ArchitectureManager: Creating dispatcher adapter instance...");
		}

		// Initialize the components...
		EventDispatcherInterface myAdapter =
			createEventDispatcherAdapter(adapterClassName);
		try {
			myAdapter.connect(uriValue);
		} catch (DispatcherException e) {
			throw new ParsingException("ArchitectureManager: Error when connectint to the adapter "+
			e.toString());
		}
		this.dispatcher.addAdapter(myAdapter);

		// Register for further dependency lookup
		if (serverNameValue != null)
			this.installedComponentNames.add(serverNameValue);

	}

	/**
	 * @param node is the <subscription> node, which delcaration follows the
	 * format:
	 *
	 * <arch:subscription xsi:type="arch:SubscriptionConfigurationType">
	 *
	 *  <arch:plugin xsi:type="arch:PluginDescriptorType">
	 *     <arch:name>
	 *        sequence
	 *     </arch:name>
	 *     <arch:description>
	 *        This is a sequence detection plug-in
	 *     </arch:description>
	 *     <arch:mainClass xsi:type="arch:JavaClassFile">
	 *        <arch:javaClassName xsi:type="arch:JavaClassName">
	 *           yancees.plugin.subscription.sequence.SequencePlugin
	 *        </arch:javaClassName>
	 *     </arch:mainClass>
	 *     <arch:factoryClass xsi:type="arch:JavaClassFile">
	 *        <arch:javaClassName xsi:type="arch:JavaClassName">
	 *           yancees.plugin.subscription.sequence.SequencePluginFactory
	 *        </arch:javaClassName>
	 *     </arch:factoryClass>
	 *     <arch:depends>
	 *        siena
	 *     </arch:depends>
	 *  </arch:plugin>
	 *
	 *  <arch:plugin>
	 *      ...
	 *  </arch:plugin>
	 *  ...
	 *  </arch:subscription>
	 *
	 * @throws ParsingException in case of some semantic error
	 */
	private void parseSubscription(Node node) throws ParsingException {
		if (print) {
			System.out.println(
				"ArchitectureManager: creating subscription plugins...");
			System.out.println("Parsing node: " + node.getNodeName());
		}

		DOMNodeAdapter subscriptionAdapter = new DOMNodeAdapter(node);
		Node[] pluginList = subscriptionAdapter.getElementsByName(PLUGIN_TAG);
		if (print)
			System.out.println(
				"ArchitectureManager: parsing "
					+ pluginList.length
					+ " plug-ins...");
		for (int i = 0; i < pluginList.length; i++) {
			parseAndRegisterPlugin(pluginList[i], subscriptionPluginManager);
		}

	}

	/**
	 * parses the <notificatoin> tag. The format is the same as the subscription
	 * node, hence it is not described here.
	 * @param node is the subtree having a <notification> declaration
	 * @throws ParsingException in case of semantic errors
	 */
	private void parseNotification(Node node) throws ParsingException {
		if (print)
			System.out.println(
				"ArchitectureManager: creating notification plugins...");

		DOMNodeAdapter notificationAdapter = new DOMNodeAdapter(node);
		Node[] pluginList = notificationAdapter.getElementsByName(PLUGIN_TAG);
		if (print)
			System.out.println(
				"ArchitectureManager: parsing "
					+ pluginList.length
					+ " plug-ins...");
		for (int i = 0; i < pluginList.length; i++) {
			parseAndRegisterPlugin(pluginList[i], notificationPluginManager);
		}

	}

	/**
	 * parses the <protocol> tag. The format is the same as the subscription
	 * node, hence it is not described here.
	 * @param node is the subtree having a <protocol> declaration
	 * @throws ParsingException in case of semantic errors
	 */
	private void parseProtocol(Node node) throws ParsingException {
		if (print)
			System.out.println(
				"ArchitectureManager: creating protocol plugins...");

		DOMNodeAdapter protocolAdapter = new DOMNodeAdapter(node);
		Node[] pluginList = protocolAdapter.getElementsByName(PLUGIN_TAG);
		if (print)
			System.out.println(
				"ArchitectureManager: parsing "
					+ pluginList.length
					+ " plug-ins...");
		for (int i = 0; i < pluginList.length; i++) {
			parseAndRegisterPlugin(pluginList[i], protocolPluginManager);
		}

	}

	/**
	 * Creates an EventDispatcherInterface instance based on the name provided
	 * @param dispatcherClassName is the name of the class to be instantiated
	 * @return the instance generated
	 */
	private EventDispatcherInterface createEventDispatcherAdapter(String dispatcherClassName) {
		if (print)
			System.out.println(
				"ArchitectureManager: creating adapter instance from "
					+ dispatcherClassName);

		EventDispatcherInterface disp;
		disp = (EventDispatcherInterface) createObject(dispatcherClassName);
		return disp;
	}

	/**
	 * Parses a plug-in node, extracting its attributes, and registering it
	 * with the plug-in manager provided
	 * @param pluginNode is the node to be parsed
	 * @param pluginMan is the pluginManager to receive the plug-in isntance.
	 * @throws ParsingException in case of semantic errors
	 */
	private void parseAndRegisterPlugin(
		Node pluginNode,
		PluginManagerInterface pluginMan)
		throws ParsingException {

		DOMNodeAdapter pluginAdapter = new DOMNodeAdapter(pluginNode);

		String name = null;
		String description = null;
		String mainClassName = null;
		String factoryClassName = null;
		String[] auxClassNames = new String[0];
		String dependsList = null; // dependency list for this plug-in

		Node nameNode = pluginAdapter.getFirstElementByName(NAME_TAG);
		if (nameNode != null)
			name = (new DOMNodeAdapter(nameNode)).getNodeText();

		Node descriptionNode =
			pluginAdapter.getFirstElementByName(DESCRIPTION_TAG);
		if (descriptionNode != null)
			description = (new DOMNodeAdapter(descriptionNode)).getNodeText();

		Node mainClassNode = pluginAdapter.getFirstElementByName(MAIN_CLASS_TAG);
		if (mainClassNode != null) {
			DOMNodeAdapter tempAdapt = new DOMNodeAdapter(mainClassNode);
			Node javaClassNameNode =
				tempAdapt.getFirstElementByName(JAVA_CLASS_NAME);
			mainClassName = (new DOMNodeAdapter(javaClassNameNode)).getNodeText();
		}

		Node[] auxClassNodes = pluginAdapter.getElementsByName(AUX_CLASS_TAG);
		auxClassNames = new String[auxClassNodes.length];
		for (int i = 0; i < auxClassNodes.length; i++) {
			auxClassNames[i] =
				(new DOMNodeAdapter(auxClassNodes[i])).getNodeText();
		}

		Node factoryClassNode =
			pluginAdapter.getFirstElementByName(FACTORY_CLASS_TAG);
		if (factoryClassNode != null) {
			DOMNodeAdapter tempAdapt = new DOMNodeAdapter(factoryClassNode);
			Node javaClassNameNode =
				tempAdapt.getFirstElementByName(JAVA_CLASS_NAME);
			factoryClassName =
				(new DOMNodeAdapter(javaClassNameNode)).getNodeText();
			if (print) {
				System.out.println("ArchitectureManager: read factory declaration: "+factoryClassName);
			}
		} else {
			if (print)
				System.out.println("ArchitectureManager: "+ FACTORY_CLASS_TAG + " tag not found!");
		}

		Node dependsNode = pluginAdapter.getFirstElementByName(DEPENDS_TAG);
		if (dependsNode != null)
			dependsList = (new DOMNodeAdapter(dependsNode)).getNodeText();

		/**
		 Since the factory is the component that creates the plug-in with all
		 necessary initialization and aux classes, these data is provided here
		 for the future implementation of the dynamic plug-in installation, not
		 being necessary for the actual creation of the plug-ins at runtime.
		 */

		if (print)
			System.out.println(
				"ArchitectureManager: Creating and registering plugin factory: " + factoryClassName);
		PluginFactoryInterface plugFactory =
			createPluginFactory(factoryClassName);
		if (plugFactory != null) {
			pluginMan.addFactory(plugFactory);
			//this.installedComponentNames.add(name);
		} else {
			throw new ParsingException(
				factoryClassName + " was not found our could not be created");
		}

		// Adds component name for further dependency check
		this.installedComponentNames.add(name);
		this.dependencyLists.put(name, dependsList);

	}

	/**
	 * Creates a plug-in factory instance based on the classname provided
	 * @param pluginFactoryClassName is the class name, the implementation, to be used to create this object
	 * @return an object, and instance of PluginFactoryInterface with implementaition was provided as parameter
	 */
	private PluginFactoryInterface createPluginFactory(String pluginFactoryClassName) {
		PluginFactoryInterface pluginFact;
		pluginFact =
			(PluginFactoryInterface) createObject(pluginFactoryClassName);
		return pluginFact;
	}

	/**
		 * Creates a filter instance based on the provided class name
		 * @param mainClassname is the class name, the implementation, to be used to create this object
		 * @return an object, and instance of FilterInterface with implementaition was provided as parameter
		 */
	private FilterInterface createFilter(String mainClassName) {
		FilterInterface filterObj;
		filterObj = (FilterInterface) createObject(mainClassName);
		return filterObj;
	}

	/**
			 * Creates a filter instance based on the provided class name
			 * @param mainClassname is the class name, the implementation, to be used to create this object
			 * @return an object, and instance of ServiceInterface with implementaition was provided as parameter
			 */
	private ServiceInterface createService(String mainClassName) {
		ServiceInterface filterObj;
		filterObj = (ServiceInterface) createObject(mainClassName);
		return filterObj;
	}

	/**
	 * Creates anobject which is an instance of the class name provided as
	 * parameter. Uses reflexion for that.
	 * @param className is the name of the class which object instance is returned
	 * @return the instance of an object which classname is provided.
	 */
	private Object createObject(String className) {
		Object object = null;
		try {
			
			if (print)
				System.out.println("ArchitectureManager: creating object: "+className);
			
			Class classDefinition = Class.forName(className);
			object = classDefinition.newInstance();
		} catch (InstantiationException e) {
			System.out.println("ArchitectureManager: could not instantiate class: "+className);
			System.out.println(e);
		} catch (IllegalAccessException e) {
			System.out.println("ArchitectureManager: could not access class file: "+className);
			System.out.println(e);
		} catch (ClassNotFoundException e) {
			System.out.println("ArchitectureManager: could not find class: "+className);
			System.out.println(e);
		}
		return object;
	}

	/**
	 * registers the default plugins: <subscription>, <notification> and generic
	 * handlers, in the subscriptionManager and notificationManager. They are
	 * necessary for the proper parsing of the experssions in these managers.
	 */
	private void registerDefaultPlugins() {
		if (print)
			System.out.println(
				"ArchitectureManager: registering default plug-ins...");

		// Configure the plugin manager instance used by the SubscriptionManager...
		subscriptionPluginManager.addFactory(
			new edu.uci.isr.yancees.server.plugin.subscription.SubscriptionPluginFactory());
		subscriptionPluginManager.addFactory(
			new edu.uci.isr.yancees.server.plugin.generic.GenericPluginFactory());

		// Configure the plugin manager instance used by the NotificationManager...
		notificationPluginManager.addFactory(
			new edu.uci.isr.yancees.server.plugin.notification.NotificationPluginFactory());
		notificationPluginManager.addFactory(
			new edu.uci.isr.yancees.server.plugin.generic.GenericPluginFactory());

	}

	/**
	 * parses all the filters in the node starting with <inputFilter> registering
	 * them in the inputFilterManager
	 * @param node is the node to be parsed
	 * @throws ParsingException is thrown in case of semantic error
	 */
	private void parseInputFilters(Node node) throws ParsingException {
		parseFilters(node, inputFilterManager);
	}

	/**
	 * parses all the filters in the node starting with <outputFilter> registering
	 * them in the outputFilterManager
	 * @param node is the node to be parsed
	 * @throws ParsingException is thrown in case of semantic error
	 */
	private void parseOutputFilters(Node node) throws ParsingException {
		parseFilters(node, outputFilterManager);

	}

	/**
	 * Parses all the filters of an input or output filters section, registering
	 * the filters, in order, in the filter manager provided
	 * @param node is the node starting with the <inputFilter> or <outputFilter> tag
	 * @param filterman is the filter manager where the filter will be installed
	 * @throws ParsingException is thrown in case of a semantic error
	 */
	private void parseFilters(Node node, FilterManagerInterface filterman)
		throws ParsingException {
		if (print) {
			System.out.println("ArchitectureManager: creating filters...");
			System.out.println("Parsing node: " + node.getNodeName());
		}

		DOMNodeAdapter filterAdapter = new DOMNodeAdapter(node);
		Node[] filtersList = filterAdapter.getElementsByName(FILTER_TAG);
		if (print)
			System.out.println(
				"ArchitectureManager: parsing "
					+ filtersList.length
					+ " filters...");
		for (int i = 0; i < filtersList.length; i++) {
			parseAndRegisterFilter(filtersList[i], filterman);
		}

	}

	/**
	 * Parses a filter of an input or output filters section, registering
	 * it in the filter manager provided
	 * @param node is the node starting with the <filter> tag
	 * @param filterman is the filter manager where the filter will be installed
	 * @throws ParsingException is thrown in case of a semantic error
	 */
	private void parseAndRegisterFilter(
		Node filterNode,
		FilterManagerInterface filterMan)
		throws ParsingException {

		DOMNodeAdapter filterAdapter = new DOMNodeAdapter(filterNode);

		String name = null;
		String description = null;
		String mainClassName = null;
		String[] auxClassNames = new String[0];
		String dependsList = null; // dependency list for this plug-in

		Node nameNode = filterAdapter.getFirstElementByName(NAME_TAG);
		if (nameNode != null)
			name = (new DOMNodeAdapter(nameNode)).getNodeText();

		Node descriptionNode =
			filterAdapter.getFirstElementByName(DESCRIPTION_TAG);
		if (descriptionNode != null)
			description = (new DOMNodeAdapter(descriptionNode)).getNodeText();

		Node mainClassNode = filterAdapter.getFirstElementByName(MAIN_CLASS_TAG);
		if (mainClassNode != null) {
			DOMNodeAdapter tempAdapt = new DOMNodeAdapter(mainClassNode);
			Node javaClassNameNode =
				tempAdapt.getFirstElementByName(JAVA_CLASS_NAME);
			mainClassName = (new DOMNodeAdapter(javaClassNameNode)).getNodeText();
		}

		Node[] auxClassNodes = filterAdapter.getElementsByName(AUX_CLASS_TAG);
		auxClassNames = new String[auxClassNodes.length];
		for (int i = 0; i < auxClassNodes.length; i++) {
			auxClassNames[i] =
				(new DOMNodeAdapter(auxClassNodes[i])).getNodeText();
		}

		Node dependsNode = filterAdapter.getFirstElementByName(DEPENDS_TAG);
		if (dependsNode != null)
			dependsList = (new DOMNodeAdapter(dependsNode)).getNodeText();

		if (print)
			System.out.println(
				"Creating and registering filter : " + mainClassName);
		FilterInterface filterObject = createFilter(mainClassName);
		if (filterObject != null) {
			filterObject.setName(name);
			filterMan.addFilter(filterObject);
		} else {
			throw new ParsingException(
				mainClassName + " was not found our could not be created");
		}

		// Adds component name for further dependency check
		this.installedComponentNames.add(name);
		this.dependencyLists.put(name, dependsList);

	}

	/**
	 * Parses and registers the services
	 * @param serviceNode
	 * @throws ParsingException
	 */
	private void parseServices(Node serviceNode) throws ParsingException {

		DOMNodeAdapter serviceAdapter = new DOMNodeAdapter(serviceNode);

		String name = null;
		String description = null;
		String mainClassName = null;
		String[] auxClassNames = new String[0];

		Node nameNode = serviceAdapter.getFirstElementByName(NAME_TAG);
		if (nameNode != null)
			name = (new DOMNodeAdapter(nameNode)).getNodeText();

		Node descriptionNode =
			serviceAdapter.getFirstElementByName(DESCRIPTION_TAG);
		if (descriptionNode != null)
			description = (new DOMNodeAdapter(descriptionNode)).getNodeText();

		Node mainClassNode = serviceAdapter.getFirstElementByName(MAIN_CLASS_TAG);
		if (mainClassNode != null) {
			DOMNodeAdapter tempAdapt = new DOMNodeAdapter(mainClassNode);
			Node javaClassNameNode =
				tempAdapt.getFirstElementByName(JAVA_CLASS_NAME);
			mainClassName = (new DOMNodeAdapter(javaClassNameNode)).getNodeText();
		}

		Node[] auxClassNodes = serviceAdapter.getElementsByName(AUX_CLASS_TAG);
		auxClassNames = new String[auxClassNodes.length];
		for (int i = 0; i < auxClassNodes.length; i++) {
			auxClassNames[i] =
				(new DOMNodeAdapter(auxClassNodes[i])).getNodeText();
		}

		if (print)
			System.out.println(
				"Creating and registering service : " + mainClassName);
		ServiceInterface serviceObject = createService(mainClassName);
		if (serviceObject != null) {
			serviceObject.setName(name);
			serviceManager.registerService(serviceObject);
		} else {
			throw new ParsingException(
				mainClassName + " was not found our could not be created");
		}

		// Adds component name for further dependency check
		this.installedComponentNames.add(name);

	}

	/**
	 * This is a hard-wired version of the configuration of the architecture used
	 * to load the default components and conect them accordingly.
	 * It uses siena by default. 
	 */
	private void configureArchitecture() {

		//TODO: remove this method in the future.

		// Configure Siena as the dispatcher...
		String sienaHost = "localhost";
		String port = "1234";
		String sienaAddress = "tcp:" + sienaHost + ":" + port;
		try {
			dispatcher.addAdapter(new edu.uci.isr.yancees.server.dispatcher.siena.SienaAdapter(sienaAddress));
		} catch (DispatcherException e) {
			System.out.println("ArchitectureManager: error when initializing SienaAdapter");
			System.out.println(e.toString());
			e.printStackTrace();
		}

		registerDefaultPlugins();

		// Now proceed to the custom plug-ins.
		subscriptionPluginManager.addFactory(
			new edu.uci.isr.yancees.server.dispatcher.siena.SienaPluginFactory());

		subscriptionPluginManager.addFactory(
			new edu.uci.isr.yancees.server.plugin.subscription.sequence.SequencePluginFactory());
		subscriptionPluginManager.addFactory(
			new edu.uci.isr.yancees.server.plugin.subscription.rule.RulePluginFactory());

		// Configure subscription manager...
		//subscriptionManager.setPluginManager(subscriptionPluginManager);

		notificationPluginManager.addFactory(
			new edu.uci.isr.yancees.server.plugin.notification.push.PushPluginFactory());
		notificationPluginManager.addFactory(
			new edu.uci.isr.yancees.server.plugin.notification.pull.PullPluginFactory());

		// Configure notification manager...
		//notificationManager.setPluginManager(notificationPluginManager);

		protocolPluginManager.addFactory(
			new edu.uci.isr.yancees.server.plugin.protocol.polling.PollProtocolPluginFactory());
		protocolPluginManager.addFactory(
			new edu.uci.isr.yancees.server.plugin.protocol.mobility.MobilityProtocolPluginFactory());

		// Configure notification manager...
		//protocolManager.setPluginManager(protocolPluginManager);

	}

	/**
	 * checks for the plug-in dependencies as defined in the xml file.
	 * If the dependency is not matched, the exception is thrown
	 * @throws ParsingException is thrown in case the required plug-in was not
	 * installed.
	 */
	private void ckeckPluginDependencies() throws ParsingException {
		String currentName;
		String dep;
		String depList;
		StringTokenizer st;
		StringBuffer sb = new StringBuffer();
		boolean error = false;

		if (print)
			System.out.println(
				"ArchitectureManager: cheking plug-in dependencies...");

		for (int i = 0; i < this.installedComponentNames.size(); i++) {
			currentName = (String) installedComponentNames.get(i);
			depList = (String) dependencyLists.get(currentName);
			if (depList != null) {
				st = new StringTokenizer(depList);
				while (st.hasMoreElements()) {
					dep = (String) st.nextElement();
					dep.trim();
					if (!inList(dep, installedComponentNames)) {
						sb.append(
							"ArchitectureManager: "
								+ dep
								+ " is required by "
								+ currentName
								+ "\n");
						error = true;
					}
				}
			}
		}

		if (!error) {
			if (print)
				System.out.println("ArchitectureManager: dependencies Ok!");
		} else {
			throw new ParsingException(sb.toString());
		}
	}

	/**
	 *
	 * @param element is the string to be searched in the list
	 * @param list is the list containing strings
	 * @return true if the element is in the list, false if not
	 */
	private boolean inList(String element, Vector list) {
		for (int i = 0; i < list.size(); i++) {
			if (element.equals((String) list.get(i))) {
				return true;
			}
		}
		return false;
	}

	public EventDispatcherInterface getEventDispatcher() {
		return dispatcher;
	}

	public SubscriptionManager getSubscriptionManager() {
		return subscriptionManager;
	}

	public NotificationManager getNotificationManager() {
		return notificationManager;
	}

	public PluginManagerInterface getSubscriptionPluginManager() {
		return subscriptionPluginManager;
	}

	public PluginManagerInterface getNotificationPluginManager() {
		return notificationPluginManager;
	}

	public ProtocolManager getProtocolManager() {
		return protocolManager;
	}

	public PluginManagerInterface getProtocolPluginManager() {
		return protocolPluginManager;
	}

	public ActivePluginInstancesRegistry getActiveSubscriptionTreesDB() {
		return subscriptionDB;
	}

	public ServiceManager getServiceManager() {
		return serviceManager;
	}

	public InputFilterManager getInputFilterManager() {
		return inputFilterManager;
	}

	public OutputFilterManager getOutputFilterManager() {
		return outputFilterManager;
	}

	/**
	 * Finalizes the architecture, making sure all the connections are closed
	 *
	 */
	protected void finalize() throws Throwable {
		if (dispatcher != null) {

			try {
				dispatcher.shutdownDispatcher();
			} catch (DispatcherException ex) {
				System.out.println(ex);
			}
		}
		super.finalize();
	}

}