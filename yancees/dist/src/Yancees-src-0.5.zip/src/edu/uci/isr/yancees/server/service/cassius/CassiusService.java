/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 /*
 * Created on Sep 1, 2003
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */
package edu.uci.isr.yancees.server.service.cassius;

import java.util.HashMap;

import org.w3c.dom.Node;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.server.service.AbstractService;
import edu.uci.isr.yancees.util.DOMNodeAdapter;

/**
 * That's a generic service, with void implementation.
 */
public class CassiusService extends AbstractService {

	private final String ACCOUNT_NAME     = "accountName";
	private final String DESCRIPTION      = "description";
	private final String NEW_ACCOUNT_NAME = "newAccountName";
	private final String NEW_DESCRIPTION  = "newDescription";
	private final String TYPE_NAME        = "typeName";
	private final String OBJECT_NAME      = "objectName";
	private final String OBJECT_ID        = "objectId";
	private final String OBJECT_TYPE      = "objectType";
	private final String PARENT_ID        = "parentId";
	private final String NEW_OBJECT_NAME  = "objectName";
	private final String NEW_OBJECT_ID    = "objectId";
	private final String NEW_OBJECT_TYPE  = "objectType";
	private final String NEW_PARENT_ID    = "parentId";
	private final String ASSOCIATED_EVENT = "associatedEvent";
	private final String POLL_INTERVAL    = "pollInterval";
	private final String SINCE            = "since";
	private final String COMMAND          = "command";
		


	private HashMap accountMap = new HashMap();
	private HashMap objectMap = new HashMap();
	private HashMap typeMap = new HashMap();
	
	
	/**
	 * constructor
	 */
	public CassiusService() {
		super();
	}
	
	/**
	 * <xsd:complexType name="RegisterAccountCommandType">
	 *		<xsd:sequence>
    *    	<xsd:element name="accountName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    *    	<xsd:element name="description" type="xsd:string" minOccurs="0" maxOccurs="1"/>
    * 	</xsd:sequence>
    * </xsd:complexType>
	 * 
	 * @param command
	 */
	public void registerAccount(Node command) throws CassServiceException {
		CassAccount account = parseAccount(command);
		accountMap.put(account.getName(), account);
	}
	
	/**
	 * <xsd:complexType name="UnegisterAccountCommandType">
	 * 	<xsd:sequence>
    *    	<xsd:element name="accountName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    * 	</xsd:sequence>
  	 * </xsd:complexType>
  	 * 
	 * @param command
	 */
	public void unregisterAccount(Node command) throws CassServiceException {
		String accountName = null;
		accountMap.remove(accountName);
	}
	
	/**
	 * <xsd:complexType name="ChangeAccountCommandType">
	 * 	<xsd:sequence>
    *    	<xsd:element name="accountName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    *    	<xsd:element name="newAccountName" type="xsd:string" minOccurs="0" maxOccurs="1"/>
    *    	<xsd:element name="newDescription" type="xsd:string" minOccurs="0" maxOccurs="1"/>
    * 	</xsd:sequence>
  	 * </xsd:complexType>
	 * 
	 * @param command
	 */
	public void changeAccount(Node command) throws CassServiceException{
		String accountName = null;
		//TODO: search and replace...
	}
	
	/**
	 * <xsd:complexType name="ListAccountsCommandType">
	 * 	<xsd:sequence>
    *    	<xsd:element name="accountName" type="xsd:string" minOccurs="0" maxOccurs="unbounded"/>
    *    </xsd:sequence>
  	 * </xsd:complexType>
	 * 
	 * @param command
	 * @return
	 */
	public Node listAccounts(Node command) throws CassServiceException{
		return null;
	}
	
	/**
	 * <xsd:complexType name="NewObjectCommandType">
	 * 	<xsd:sequence>
    *    	<xsd:element name="objectName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    *    	<xsd:element name="objectId" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    *   		<xsd:element name="accountName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    *    	<xsd:element name="objectType" type="xsd:string" minOccurs="0" maxOccurs="1"/>
    *    	<xsd:element name="parentId" type="xsd:string" minOccurs="0" maxOccurs="1"/>
    *    	<xsd:element name="description" type="xsd:string" minOccurs="0" maxOccurs="1"/>
    * 	</xsd:sequence>
  	 * </xsd:complexType>
	 * 
	 * @param command
	 */
	public void newObject(Node command) throws CassServiceException{
		CassObject object = parseObject(command);
		CassAccount account = (CassAccount) accountMap.get(object.getAccountName());
		if (account != null) {
			account.addObject(object);
		}
		objectMap.put(object.getId(), object);
	}
	
	/**
	 * <xsd:complexType name="RemoveObjectCommandType">
	 *   <xsd:sequence>
    *    	<xsd:element name="objectId" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    *    	<xsd:element name="accountName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    *		</xsd:sequence>
  	 * </xsd:complexType>
	 * 
	 * @param command
	 */
	public void removeObject(Node command) throws CassServiceException{
		DOMNodeAdapter objectAdapt = new DOMNodeAdapter(command);
		String objectId = null;
		String accountName = null;
		
		Node objectIdNode = objectAdapt.getFirstElementByName(OBJECT_ID);
		Node accountNameNode = objectAdapt.getFirstElementByName(ACCOUNT_NAME);
		
		objectId = new DOMNodeAdapter(objectIdNode).getNodeText();
		accountName = new DOMNodeAdapter(accountNameNode).getNodeText();
		
		CassObject obj = (CassObject) objectMap.get(objectId);
		CassAccount acc = (CassAccount) accountMap.get(accountName);
		
		if (obj != null && acc != null) {
			acc.removeObject(obj);
			objectMap.remove(objectId);
		}
		
	}
	
	/**
	 * <xsd:complexType name="ModifyObjectCommandType">
	 * 	<xsd:sequence>
    *    	<xsd:element name="objectName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    *    	<xsd:element name="objectId" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    *    	<xsd:element name="newObjectName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    *    	<xsd:element name="newObjectId" type="xsd:string" minOccurs="0" maxOccurs="1"/>
    *    	<xsd:element name="newParentId" type="xsd:string" minOccurs="0" maxOccurs="1"/>
    *    	<xsd:element name="newDescription" type="xsd:string" minOccurs="0" maxOccurs="1"/>
    * 	</xsd:sequence>
  	 * </xsd:complexType>
	 * 
	 * @param command
	 */
	public void modifyObject(Node command) throws CassServiceException{
		
	}
	
	/**
	 * <xsd:complexType name="ListObjectsCommandType">
	 * 	<xsd:sequence>
    *    	<xsd:element name="accountName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    *    	<xsd:element name="objectId" type="xsd:string" minOccurs="0" maxOccurs="1"/>
    * 	</xsd:sequence>
    * </xsd:complexType>
	 * 
	 * @param command
	 * @return
	 */
	public Node listObjects(Node command) throws CassServiceException{
		CassObject[] objectList;
		
		DOMNodeAdapter objectAdapt = new DOMNodeAdapter(command);
		String objectId = null;
		String accountName = null;
	
		Node objectIdNode = objectAdapt.getFirstElementByName(OBJECT_ID);
		Node accountNameNode = objectAdapt.getFirstElementByName(ACCOUNT_NAME);
	
		objectId = new DOMNodeAdapter(objectIdNode).getNodeText();
		accountName = new DOMNodeAdapter(accountNameNode).getNodeText();
	
		CassObject obj = (CassObject) objectMap.get(objectId);
		CassAccount acc = (CassAccount) accountMap.get(accountName);
	
		// no object was sent in this message, get all the objects of the account
		if (obj == null) {
			objectList = acc.getObjectList();
		} else {
			objectList = new CassObject[1];
			objectList[0] = obj;
		}
		
		return objectListXML(objectList);
	}
	
	
	/**
	 * 
	 * <xsd:complexType name="DefineTypeCommandType">
	 * 	<xsd:sequence>
    *    	<xsd:element name="typeName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    *    	<xsd:element name="description" type="xsd:string" minOccurs="0" maxOccurs="1"/>
    *    	<xsd:element name="associatedEvent" type="xsd:string" minOccurs="0" maxOccurs="unbounded"/>
    * 	</xsd:sequence>
  	 * </xsd:complexType>
	 * 
	 * @param command
	 */
	public void defineType(Node command) throws CassServiceException{
		
	}
	
	/**
	 * <xsd:complexType name="RemoveTypeCommandType">
	 * 	<xsd:sequence>
    *    	<xsd:element name="accountName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    *    	<xsd:element name="typeName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    * 	</xsd:sequence>
  	 *	</xsd:complexType>
	 * 
	 * @param command
	 */
	public void removeType(Node command) throws CassServiceException{
		
	}
	
	/**
	 * 
	 * <xsd:complexType name="ListTypesCommandType">
	 * 	<xsd:sequence>
    *    	<xsd:element name="accountName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
    *    	<xsd:element name="typeName" type="xsd:string" minOccurs="0" maxOccurs="unbounded"/>
    * 	</xsd:sequence>
  	 * </xsd:complexType>
	 * 
	 * @param command
	 * @return
	 */
	public Node listTypes(Node command) throws CassServiceException{
		return null;
	}
	
	/**
	 * Interprets the following XML protocol description.
	 * 
	 * <xsd:complexType name="PollCommandType">
	 * 	<xsd:sequence>
	 *    	<xsd:element name="pollInterval" type="xsd:int" minOccurs="0" maxOccurs="1"/>
	 *	   	<xsd:element name="since" type="xsd:Time" minOccurs="0" maxOccurs="1"/>
	 * 	   <xsd:element name="command" type="CommandType" minOccurs="1" maxOccurs="1"/>
	 * 	</xsd:sequence>
    * </xsd:complexType>
    * 
    * <xsd:simpleType name="CommandType">
    *		<xsd:restriction base="xsd:string">
    *			<xsd:enumeration value="start"/>
    *			<xsd:enumeration value="stop"/>
    *			<xsd:enumeration value="pause"/>
    *			<xsd:enumeration value="resume"/>
  	 *		</xsd:restriction>
  	 *	</xsd:simpleType>
  	 *
	 * @param command
	 * @return
	 */
	public EventInterface[] poll(Node command) throws CassServiceException{
		return null;
	}
	
	//---------------------------- Auxiliary methods ---------------------------
	
	private CassAccount parseAccount(Node dom) {
		CassAccount parsedAccount = null;
		DOMNodeAdapter accountAdapt = new DOMNodeAdapter(dom);
		String accountName = null;
		String description = null;
		
		/*
		 * <xsd:complexType name="RegisterAccountCommandType">
		 *		<xsd:sequence>
		 *    	<xsd:element name="accountName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
		 *    	<xsd:element name="description" type="xsd:string" minOccurs="0" maxOccurs="1"/>
		 * 	</xsd:sequence>
		 * </xsd:complexType>
		 */
		Node accountNameNode = accountAdapt.getFirstElementByName(ACCOUNT_NAME);
		Node descriptionNode = accountAdapt.getFirstElementByName(DESCRIPTION);
		
		accountName = new DOMNodeAdapter(accountNameNode).getNodeText();
		description = new DOMNodeAdapter(descriptionNode).getNodeText();
		
		parsedAccount = new CassAccount(accountName, description);
		
		return parsedAccount;
	}
	
	private CassEvent parseEvent(Node dom) {
		return null;
	}
	
	private CassObject parseObject(Node dom) {
		CassObject parsedObject;
		DOMNodeAdapter objectAdapt = new DOMNodeAdapter(dom);
		
		String objectName = null;
		String objectId = null;
		String accountName = null;
		
		String objectType = null;
		String parentId = null;
		String description = null;
		
		/* <xsd:complexType name="NewObjectCommandType">
		 * 	<xsd:sequence>
		 *    	<xsd:element name="objectName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
		 *    	<xsd:element name="objectId" type="xsd:string" minOccurs="1" maxOccurs="1"/>
		 *   		<xsd:element name="accountName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
		 *    	<xsd:element name="objectType" type="xsd:string" minOccurs="0" maxOccurs="1"/>
		 *    	<xsd:element name="parentId" type="xsd:string" minOccurs="0" maxOccurs="1"/>
		 *    	<xsd:element name="description" type="xsd:string" minOccurs="0" maxOccurs="1"/>
		 * 	</xsd:sequence>
		 * </xsd:complexType>
		 */
		 
		Node objectNameNode  = objectAdapt.getFirstElementByName(OBJECT_NAME);
		Node objectIdNode    = objectAdapt.getFirstElementByName(OBJECT_ID);
		Node accountNameNode = objectAdapt.getFirstElementByName(ACCOUNT_NAME);
		Node objectTypeNode  = objectAdapt.getFirstElementByName(OBJECT_TYPE);
		Node parentIdNode    = objectAdapt.getFirstElementByName(PARENT_ID);
		Node descriptionNode = objectAdapt.getFirstElementByName(DESCRIPTION);
		
		
		objectName  = new DOMNodeAdapter(objectNameNode).getNodeText();
		objectId    = new DOMNodeAdapter(objectIdNode).getNodeText();
		accountName = new DOMNodeAdapter(accountNameNode).getNodeText();
		objectType  = new DOMNodeAdapter(objectTypeNode).getNodeText();
		parentId    = new DOMNodeAdapter(parentIdNode).getNodeText();
		description = new DOMNodeAdapter(descriptionNode).getNodeText();
		
		CassType objectTypeReference = (CassType) typeMap.get(objectType); 
		CassAccount objectAccountReference = (CassAccount) accountMap.get(accountName);
		CassObject parentReference =  (CassObject) objectMap.get(parentId);
		
		parsedObject = new CassObject(objectName,
		objectId,
		objectAccountReference,
		objectTypeReference,
		parentReference,
		description);
		 
		return parsedObject;
	}
	
	private CassType parseType (Node dom) {
		CassType parsedType = null;
		
		DOMNodeAdapter typeAdapt = new DOMNodeAdapter(dom);
		String typeName = null;
		String description = null;
		String[] eventNames = null;
	
		
		/*
		 *  <xsd:complexType name="DefineTypeCommandType">
		 * 	<xsd:sequence>
		 *    	<xsd:element name="typeName" type="xsd:string" minOccurs="1" maxOccurs="1"/>
		 *    	<xsd:element name="description" type="xsd:string" minOccurs="0" maxOccurs="1"/>
		 *    	<xsd:element name="associatedEvent" type="xsd:string" minOccurs="0" maxOccurs="unbounded"/>
		 * 	</xsd:sequence>
		 * </xsd:complexType>
		 */
		 
		Node typeNameNode = typeAdapt.getFirstElementByName(TYPE_NAME);
		Node descriptionNode = typeAdapt.getFirstElementByName(DESCRIPTION);
		Node[] associatedEventNodes = typeAdapt.getElementsByName(ASSOCIATED_EVENT);
		
		typeName = new DOMNodeAdapter(typeNameNode).getNodeText();
		description = new DOMNodeAdapter(descriptionNode).getNodeText();
		eventNames = new String[associatedEventNodes.length];
		for (int i = 0; i < associatedEventNodes.length; i++) {
			eventNames[i] = new DOMNodeAdapter(associatedEventNodes[i]).getNodeText();
		}
		
		parsedType = new CassType(typeName, description, eventNames);
		
		return parsedType;
	}
	
	/**
	 * generates an answer with the object list following the grammar:
	 * 
	 * @param list
	 * @return
	 */
	private Node objectListXML(CassObject[] list) {
		return null;
	}

}
