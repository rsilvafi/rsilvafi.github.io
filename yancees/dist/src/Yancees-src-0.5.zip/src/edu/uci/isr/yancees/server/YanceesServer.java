/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.server;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.io.File;

import org.w3c.dom.Document;

import edu.uci.isr.yancees.GenericEvent;
import edu.uci.isr.yancees.GenericMessage;
import edu.uci.isr.yancees.server.core.ParsingException;
import edu.uci.isr.yancees.util.DOMNodeAdapter;
import edu.uci.isr.yancees.util.DOMParser;


/**
 * This class centralized all aspects of yancees:
 * 1) The unique connection to the dispatcher (siena, elvin or other)
 * 2) The access to the specific Facades (publication, subscription, administration),
 *    configuring them as necessary
 * 3) The parsing of files in Notification, Subscription and Message wrappers
 * 
 * Local users should use this class as the front-end to Yancees notification server
 * Remote users should use the RemoteYanceesInterface. This last interface is most 
 * likely to be the preferred one.
 *
 */
public class YanceesServer {

	// Globally enables or disables the printing of debugging information
	public static final boolean PRINT_DEBUG = false;
	
   final static String MESSAGE_TAG="message";
   final static String EVENT_TAG="event";


   // Unique instance of this singleton.
   private static YanceesServer myInstance;

   private ArchitectureManager archMan = null;
   private ProtocolFacade messagerAPI = null;
   private SubscriptionFacade subscriberAPI = null;
   private PublicationFacade publisherAPI = null;

   /**
    * This constructor, as protected, prevents the direct instantiation of this
    * object, and  guarantees the singleton characteristic of this class. The
    * protected modifyer allows this class to be subclassed, permiting the over-
    * load of the constructor.
    */
   protected YanceesServer() {
   }

   /**
    * The only way to access the unique instance of Yancees is by
    * using this access method.
    * @return the instance of Yancess using the default configuration.
    */
   public static YanceesServer getInstance() {
      if (myInstance == null) {
         myInstance = new YanceesServer();
      }
      return myInstance;
   }

   /**
    * Initializes the system using the default configuration.
    */
   public void initialize() {
      buildArchitectureConfiguration();
    }

    /**
     * Initialize the client API using the provided configuration file
     * @param configFile
     */
    public void initialize(File configFile) throws ParsingException {
       buildArchitectureConfiguration(configFile);
    }

    protected void finalize() throws Throwable {
       archMan.finalize();
       super.finalize();
    }


   /**
    * builds the client-side configuration using the default configuration.
    * @param configFile
    */
   private void buildArchitectureConfiguration() {
      archMan = ArchitectureManager.getInstance();
      archMan.initialize();
   }


   /**
    * builds the client-side configuration using a configuration file
    * @param configFile is a XML document descirbing the plug-ins and services
    * available to this Yancees instance.
    */
   private void buildArchitectureConfiguration(File configFile) throws ParsingException {
      archMan = ArchitectureManager.getInstance();
      archMan.initialize(configFile);
   }

	/**
	 * Get access to the internal protocolAPI
	 * @return
	 */
   public ProtocolFacade getProtocolAPI() {
      if (messagerAPI == null) {
         messagerAPI = ProtocolFacade.getInstance();
         messagerAPI.setProtocolManager(archMan.getProtocolManager());
      }

      return messagerAPI;
   }

	/**
	 * Get access to the internal publisher API
	 * @return
	 */
   public PublicationFacade getPublisherAPI() {
      if (publisherAPI == null) {
         publisherAPI = PublicationFacade.getInstance();
         publisherAPI.setEventDispatcher(archMan.getEventDispatcher());
         if (archMan.getInputFilterManager().getNumberOfFilters() > 0)
         	publisherAPI.installInputFilters(archMan.getInputFilterManager());
      }

      return publisherAPI;
   }

	/**
	 * Gets access to the internal subscriber API
	 * @return
	 */
   public SubscriptionFacade getSubscriberAPI() {
      if (subscriberAPI == null) {
         subscriberAPI = SubscriptionFacade.getInstance();
         subscriberAPI.setSubscriptionManager(archMan.getSubscriptionManager());
         subscriberAPI.setNotificationManger(archMan.getNotificationManager());
			if (archMan.getOutputFilterManager().getNumberOfFilters() > 0)
         	subscriberAPI.installOutputFilters(archMan.getOutputFilterManager());
      }

      return subscriberAPI;
   }

   //--------------------- BEGIN static utility methods -------------------------

   /**
    * Allows users to easity parse their XML messages before sending to the APIs
    * @param messageFile is the file to be parsed
    * @return a Message object with the parsed document or null in case of some error
    * @throws ParsingException in case the <message> tag is not present in the document
    */
   public static GenericMessage parseMessage(File messageFile) throws ParsingException {

      Document doc = parseDocument(messageFile);
      if (doc != null) {
         DOMNodeAdapter adapt = new DOMNodeAdapter(doc);
         if (!adapt.hasChildElement(MESSAGE_TAG)) {
               throw new ParsingException("Tag <"+MESSAGE_TAG+"> was not found!");
         } else {
            return new GenericMessage(doc);
         }
      }
      return null;
   }

   /**
    * Allows users to easity parse their XML events before sending to the APIs
    * @param eventFile is the file to be parsed
    * @return an Event object with the parsed document or null in case of some error
    * @throws ParsingException in case the <event> tag is not present in the document
    */
   public static GenericEvent parseEvent(File eventFile) throws ParsingException{

      Document doc = parseDocument(eventFile);
      if (doc != null) {
         DOMNodeAdapter adapt = new DOMNodeAdapter(doc);
         if (!adapt.hasChildElement(EVENT_TAG)) {
               throw new ParsingException("Tag <"+EVENT_TAG+"> was not found!");
         } else {
            return new GenericEvent(doc);
         }
      }
      return null;
   }


  /**
  * Parsers a XML document from a file into a XML DOM Document object.
  * This parser performs syntatic checking according to the xmlsechema types
  * defined in the document. In other words, it is a validating and name-aware
  * parser
  *
  * @param documentFile is the file which will be parsed into a Document object
  * @return a Document object with the parsed document.
  */
   private static Document parseDocument(File documentFile) {

    DOMParser parser = new DOMParser(documentFile);
    Document document = parser.getDocument();

    return document;
 }

 //--------------------- END static utility methods -------------------------


}