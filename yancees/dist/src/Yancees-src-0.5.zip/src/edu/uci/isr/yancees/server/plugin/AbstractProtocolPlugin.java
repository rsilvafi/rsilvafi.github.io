/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.server.plugin;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.util.Vector;

import org.w3c.dom.Node;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.MessageInterface;
import edu.uci.isr.yancees.SubscriberInterface;

/**
 * This abstract class defines the basic functionality of the plug-in as well
 * as its main attributes.
 *
 * A protocol plug-in handles all the messages of a session. It is created and
 * terminated by special messages, as opposed to the subscription plug-ins which only
 * perform queries and provide events when the query is matched. A protocol plug-in
 * on the onther hand, can perform many functionalities and can have access to many
 * sub-components and plug-in instances of the system.
 */
public abstract class AbstractProtocolPlugin
      extends AbstractPlugin
      implements ProtocolPluginInterface {

   private boolean print = edu.uci.isr.yancees.server.YanceesServer.PRINT_DEBUG;
   private Vector myProtocolListeners = new Vector();

   /**
    * @param subTree is the DOM tree this plugin is responsible for executing
    */
   public AbstractProtocolPlugin(Node subTree) {
      super(subTree);

   }

//------------------ AbstractPlugin methods are re-declared here ---------------

   /**
    * Receives a notification from another plug-in this plug-in depends on
    * @param evt is the event received
    * @param source is the plug-in sending the notification.
    */
   public abstract void receivePluginNotification(EventInterface evt,
                                                  PluginInterface source);

   /**
    * Receives a list of events as notifications from another plug-in
    * this plug-in depends on.
    * @param evtList is the list of events received
    * @param source is the plug-in sending the notification.
    **/
   public abstract void receivePluginNotification(EventInterface[] evtList,
                                                  PluginInterface source);

//------------------------------------------------------------------------------

   /**
    * Gracefully terminates the current plugin as a result of the end of the
    * communicatoin session.
    */
   public abstract void terminateSession();

   /**
    * Receive messages from this protocol
          * @param msg is a message according to the protocol that the plug-in implements.
    */
   public abstract void receiveProtocolMessage(MessageInterface msg, SubscriberInterface si)
         throws ProtocolPluginException;


}