/*
 * Copyright (c) 2003, Regents of the University of California.
 * All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 
/*
 * Created on Nov 18, 2003
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 * @version 1.0
 */
package edu.uci.isr.yancees;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import edu.uci.isr.yancees.server.core.ParsingException;

/**
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 *
 * This class implements an event using the xml schema defined in 
 * yanceesEvent.xsd
 */
public class YanceesEvent extends GenericEvent {
	
	/** Tags used from the event to express siena constraints.
	 * these tags are imported from the sienaEvent.xsd schema and used in the
	 * sienaSubscriptin.xsd
	 */
	public static final String EVENT          = "event";
	public static final String NAME           = "name";
	public static final String VALUE          = "value";
	public static final String ATTRIBUTE      = "attribute";
	public static final String TYPE_ATTRIBUTE = "type"; // XML elemnt attribute

	// All value types supprted by the current yanceesEvent.xsd type
	public static final String BINARY_TYPE  = "sienaHexBynary";
	public static final String BOOLEAN_TYPE = "sienaBoolean";
	public static final String DOUBLE_TYPE  = "sienaDouble";
	public static final String FLOAT_TYPE   = "sienaFloat";
	public static final String LONG_TYPE    = "sienaLong";
	public static final String INT_TYPE     = "sienaInt";
	public static final String STRING_TYPE  = "sienaString";

	private final boolean print = edu.uci.isr.yancees.server.YanceesServer.PRINT_DEBUG;
	
  // Associate attribute names with their Java Objects
	private HashMap eventAttributes = new HashMap();


	/**
	 * @param n is the representation of the event as a DOM tree in memory
	 * @throws ParsingException is thrown in case the event is not according to
	 * the expected format.
	 */
	public YanceesEvent(Node n) throws ParsingException {
		super(n);
		this.put("yancees.type", "Yancees 1.0"); // Marks the event as belonging to yancees
	}

	/**
	 * @param file is the File object with the XML representation of an event
	 * according to the standard format, supported by the adapter and the plug-ins.
	 * The event here can be desribed in many formats, as well as the adapters and
	 * plug-ins in the server know how to handle it.
	 * @throws IOException
	 */
	public YanceesEvent(File file) throws IOException {
		super(file);
		this.put("yancees.type", "Yancees 1.0"); // Marks the event as belonging to yancees
		
	}

	/**
	 * @param content is the XML representation of the event in textual, string
	 * in memory.
	 */
	public YanceesEvent(String content) {
		super(content);
		this.put("yancees.type", "Yancees 1.0"); // Marks the event as belonging to yancees
	}
	
	/**
	 * This is the preferential constructor for this object. It creates an empty
	 * event that will be stuffed with attribute/value pairs with the setAttribute()
	 * methods.
	 *
	 */
	public YanceesEvent() {
		super(""); // creates with empty content.
		Node newDOM = buildEmptyEventDOM();
		try {
         // I prefer to use the method since it	takes care of the message and content consistency
			this.setDOM(newDOM);
		} catch (ParsingException e) {
         System.out.println("YanceesEvent: error when parsing empty event DOM"); 		
			e.printStackTrace();
		}
		 
	}
	
	public void setDOM(Node n) throws ParsingException {
		  message = n;
		  textContent = null; // invalidate the text content
		  extractAttributesFromDOM(n);
		  this.put("yancees.type", "Yancees 1.0"); // Marks the event as belonging to yancees 
	  }

	/**
	 * @return the DOM tree representing the current event. In other words, builds
	 * a DOM tree with the attributes in this event, in an DOM model format.
	 */
	public Node getDOM() {
		if (message == null && textContent != null) {
			// we need to update the message DOM tree with the new file, which text
			// content is in memory right now.

			this.convertTextToMessageDOM();
			try {
				this.extractAttributesFromDOM(message);
			} catch (ParsingException e) {
				System.out.println("YanceesMessage: "+e.toString());
				e.printStackTrace();
			}
			
		} else {
			message = buildEventDOM();
			textContent = null;

		}

		return message;
	}

	/**
	  * Builds a DOM tree, in the YanceesEvent.xsd format and populates it
	  * with the attributes of this event (if any) 
	  * @return
	  */
	private Node buildEventDOM() {
		Document document = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			document = builder.newDocument(); // Create from whole cloth

			Element eventRoot = (Element) document.createElement(EVENT);
			document.appendChild(eventRoot);
			
			String key;
			Object value;
			
			Iterator iterator = eventAttributes.keySet().iterator();
			while (iterator.hasNext()) {
	  			key = (String)iterator.next();
	  			value = eventAttributes.get(key);
	  			
	  			/*
	  			System.out.println("Inserting attribute: ");
	  			System.out.println("name = "+key);
				System.out.println("value = "+value);
				*/
	  			insertAttribute(eventRoot, key, value);	
			}
			// normalize text representation
			document.getDocumentElement().normalize();

		} catch (ParserConfigurationException pce) {
			// Parser with specified options can't be built
			System.out.println("YanceesEvent: Error when creating a new DOM document");
			System.out.println(pce);
		}

		return document;
	}
	

	/**
	 * Insert an <attribute>
	 *             <name>...</name>
	 *             <value>...</value>
	 *           </attribute> construct
	 * under an <event> indicated by a Node object.
	 *
	 * @param node subtree reference which is an <event> tag
	 * @param name the name of the attribute
	 * @param value the attribute value (includding the type embedded
	 */
	private void insertAttribute(
		org.w3c.dom.Node node,
		String name,
		Object value) {
	
		Document doc;

		if (node != null) {
			doc = node.getOwnerDocument();
			Element attributeNode = doc.createElement(ATTRIBUTE);
			Element nameNode      = doc.createElement(NAME);
			Element valueNode     = doc.createElement(VALUE);

			Node textNode;
			textNode = doc.createTextNode(name);
			nameNode.appendChild(textNode);

			textNode = doc.createTextNode(value.toString());
			valueNode.appendChild(textNode);
			valueNode.setAttribute(TYPE_ATTRIBUTE, getAttributeType(value));

			node.appendChild(attributeNode);
			attributeNode.appendChild(nameNode);
			attributeNode.appendChild(valueNode);

			node.normalize();
		} else {
			System.out.println(
				"cannot insert attribute: " + name + ": " + value + " in null node");
		}
	}

	
		/**
		 * Builds an empty DOM tree, in the YanceesEvent.xsd format, to start receiving
		 * attributes. 
		 * @return
		 */
		private Node buildEmptyEventDOM() {
			Document document = null;
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

			try {
				DocumentBuilder builder = factory.newDocumentBuilder();
				document = builder.newDocument(); // Create from whole cloth

				Element root = (Element) document.createElement(EVENT);
				document.appendChild(root);

				// normalize text representation
				document.getDocumentElement().normalize();

			} catch (ParserConfigurationException pce) {
				// Parser with specified options can't be built
				System.out.println(
					"YanceesEvent: Error when creating a new DOM document");
				System.out.println(pce);
			}

			return document;
		}

	
	/**
	 * removes all the <attribute> elements from this <event> DOM tree
	 */
	private void clearAttributesSubtrees() {
		Node event = findSubtree(EVENT);
		NodeList list = event.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			event.removeChild(list.item(i));
		}
	}

	/**
	 * searches the current eventDOM for a subtree which ELEMENT_NODE name is
	 * the one provided. null is returned if the search is not successful.
	 * @param element_name is element to search for
	 * @return the ELEMENT_NODE with name element_name or null if it was not found.
	 */
	private org.w3c.dom.Node findSubtree(String element_name) {
		//Node targetNode = null;
		Vector queue = new Vector();

		//System.out.println("findSubtree: looking for: "+element_name);
		//System.out.println("on eventDom "+eventDOM);
		if (message != null) {

			NodeList list;
			int nodeType;
			Node n = message;

			queue.add(n);
			while (queue.size() > 0) {
				list = ((Node) queue.get(0)).getChildNodes();
				queue.removeElementAt(0);

				//System.out.println("findSubtree: "+list.getLength()+"  nodes on branch");

				for (int i = 0; i < list.getLength(); i++) {
					n = list.item(i);
					nodeType = n.getNodeType();
					if (nodeType == Node.ELEMENT_NODE) {

						//System.out.println("findSubtree: found element: "+n.getNodeName());

						if (n.getNodeName().startsWith(element_name)
							|| n.getNodeName().endsWith(":" + element_name)) {
							//System.out.println("findSubtree: returning element: "+n.getNodeName());
							return n;
						} else {
							//System.out.println("findSubtree: queueing element: "+n.getNodeName());
							queue.add(n);
						}
					}
				}

			}
		}

		return null;
	}
	
	/**
	 *
	 * @return the <body> element node of the current eventDOM
	 */
	private org.w3c.dom.Node getEventSubtree() {
		Node bodyNode = findSubtree(EVENT);

		return bodyNode;
	}

	/**
	 * Extracts the attributes from the given DOM tree. It looks for the <event>
	 * tag and fires the parsing of the <attribute> tags in it.
	 * By the end of the operation the eventAttributes Map is populated with
	 * AttValue objects.
	 * @param n DOM tree to be processed, having its attributes extracted.
	 */
	private void extractAttributesFromDOM(org.w3c.dom.Node node)
		throws ParsingException {

		Node eventSubtree = null;

		/**
		 * Makes sure the DOM corresponds to a valid event representation.
		 */
		if (node.getNodeName().endsWith(":" + EVENT)
			|| node.getNodeName().equals(EVENT)) {
			eventSubtree = node;
			parseEvent(eventSubtree);

			// It may happen that the node provided does not start with the EVENT tag,
			// so we look at the children nodes
		} else {
			if (node.hasChildNodes()) {
				NodeList list = node.getChildNodes();
				//System.out.println("Tree has : "+list.getLength()+" children");
				for (int i = 0; i < list.getLength(); i++) {
					Node myNode = list.item(i);
					//System.out.println("Checking for : "+myNode.getNodeName());
					if (myNode.getNodeName().endsWith(":" + EVENT)
						|| myNode.getNodeName().equals(EVENT)) {
						eventSubtree = myNode;
						//System.out.println("Found : "+myNode.getNodeName());
						break;
					}
				}
				if (eventSubtree == null) {
					throw new ParsingException(
						"Could not find a <event> node "
							+ "in tree headed by :"
							+ node.getNodeName());
				}
			}

			// After finding the first occurrence of EVENT we parse it.
			parseEvent(eventSubtree);
		}
	}

	/**
	 * Parses a subtree headed by <event> tag.
	 * We assume that the XML DOM tree is gramatiacally correct.
	 *
	 * @param node is the reference to a DOM subtree head representing an event
	 */
	private void parseEvent(org.w3c.dom.Node node) {

		//System.out.println("parsing event");
		if (node.hasChildNodes()) {
			NodeList list = node.getChildNodes();
			//System.out.println("Tree has : "+list.getLength()+" children");

			for (int i = 0; i < list.getLength(); i++) {
				Node myNode = list.item(i);
				if (myNode.getNodeName().startsWith(ATTRIBUTE)
					|| myNode.getNodeName().endsWith(":" + ATTRIBUTE)) {
					parseAttribute(myNode, eventAttributes);
				}

			}
		}
	}

	/**
	 *
	 * @param node is a subtree reference headed by <attribute> tag
	 * @param destinationMap is the destination structure to be poppulated with
	 * AttValue objects represented in this tree.
	 */
	private void parseAttribute(
		org.w3c.dom.Node attributeDOM,
		Map destinationMap) {

		String attributeName = this.parseAttributeName(attributeDOM);
		Object value = this.parseAttValue(attributeDOM);
		destinationMap.put(attributeName, value);

	}
	

	/**
	 * Gets a construction like that:
	 *
	 * <attribute>
	 *   <name> someName </name>
	 *   <value type="someType"> someValue </value>
	 * </attribute>
	 *
	 * and returns the content "someValue", which is between <value> tags.
	 * It also returns the type "someType" in the construction. These are wrapped
	 * in an AttValue object.
	 *
	 */
	private Object parseAttValue(org.w3c.dom.Node attributeDOM) {
		if (print) {
			System.out.println("parseAttValue");

		}
		Object attVal;
		String valueType;
		String stringValue;

		if (attributeDOM != null) {

			// selects the <value type="blabla"> 1234 <value> tag and
			// extracts its content and type
			NodeList list = attributeDOM.getChildNodes();
			int nodeType;
			Node n;
			for (int i = 0; i < list.getLength(); i++) {
				n = list.item(i);
				nodeType = n.getNodeType();
				if (nodeType == Node.ELEMENT_NODE) {
					if (n.getNodeName().startsWith(VALUE)
						|| n.getNodeName().endsWith(":" + VALUE)) {
						stringValue = parseNodeTextContent(n);
						valueType = parseNodeType(n);
						
						/*
						System.out.println("Found value: "+stringValue);
						System.out.println("Found type: "+valueType);
						*/				
						return createObject(stringValue, valueType);
					}
				}
			}

		}

		return null;
	}
	

	/**
	 * Gets a construction like that:
	 *
	 * <attribute>
	 *   <name> someName </name>
	 *   <value> someValue </value>
	 * </attribute>
	 *
	 * and returns the content "someName", which is between <name> tags.
	 * null is returned in case the value is not found
	 * sienaOP is one of the valid OPERATORS supported by siena.
	 *
	 */
	private String parseAttributeName(org.w3c.dom.Node attributeDOM) {
		if (print) {
			System.out.println("parseAttributeName");

		}
		if (attributeDOM != null) {

			NodeList list = attributeDOM.getChildNodes();
			int nodeType;
			Node n;
			for (int i = 0; i < list.getLength(); i++) {
				n = list.item(i);
				nodeType = n.getNodeType();
				if (nodeType == Node.ELEMENT_NODE) {
					if (n.getNodeName().startsWith(NAME)
						|| n.getNodeName().endsWith(":" + NAME)) {
						return parseNodeTextContent(n);
					}
				}
			}

		}

		return null;

	}

	/**
	 * @returns the value of the type attribute of a node if it exists, or
	 * null if it was not found.
	 *
	 * In other words, gets a constuction like:
	 *
	 * <tag type="someType"> blablabla </tag>
	 *
	 * and returns "someType", which is the content of the type attribute in the
	 * tag.
	 */
	private String parseNodeType(org.w3c.dom.Node node) {
		if (print) {
			System.out.println("parseNodeType");

		}
		Node tempNode;
		String name;
		if (node.hasAttributes()) {
			NamedNodeMap map = node.getAttributes();
			for (int i = 0; i < map.getLength(); i++) {
				tempNode = map.item(i);
				name = tempNode.getNodeName();
				if (name.equals(TYPE_ATTRIBUTE)
					|| name.endsWith(":" + TYPE_ATTRIBUTE)) {
					return tempNode.getNodeValue();
				}
			}

		}

		return null;
	}

	/**
	 * @return the text 'value' of a node like <element> value <element>
	 * or null in case this value does not exist.
	 */
	private String parseNodeTextContent(org.w3c.dom.Node node) {
		if (print) {
			System.out.println("parseNodeTextContent");
		}
		NodeList list = node.getChildNodes();
		int nodeType;
		Node n;
		for (int i = 0; i < list.getLength(); i++) {
			n = list.item(i);
			nodeType = n.getNodeType();
			if (nodeType == Node.TEXT_NODE) {
				return n.getNodeValue().trim();
			}
		}

		return null;
	}

		
	/**
	 * Gets a string attribute
	 * @param attName is the name of the atribute to be retrieved
	 * @return the String type attribute or null if the attribute does not exist
	 * or it cannot be converted to a string.
	 * @throws WrongAttributeTypeException if the attribute exists but the type is wrong
	 */
	public String getString(String attName) throws WrongAttributeTypeException {
		String value = null;
		Object obj = eventAttributes.get(attName);
		if (obj != null) {
			value = (String) obj.toString();
		}
		
		return (String) value;
	}
	
	/**
		 * Gets a double attribute
		 * @param attName is the name of the atribute to be retrieved
		 * @return the String type attribute or null if the attribute does not exist
		 * or it cannot be converted to a string.
		 * @throws WrongAttributeTypeException if the attribute exists but the type is wrong
		 */
	public double getDouble(String attName) throws WrongAttributeTypeException {
		double value = 0.0;
		Object obj = eventAttributes.get(attName);
		if (obj != null) {
			if (obj instanceof Double) {
				value = ((Double) obj).doubleValue();
		   } else if (obj instanceof Float) {
				value = ((Float) obj).doubleValue();
			} else if (obj instanceof Integer) {
				value = ((Integer) obj).doubleValue();
			} else if (obj instanceof Long) {
				value = ((Long) obj).doubleValue();
			} else {
				throw new WrongAttributeTypeException("Attribute exists but cannot be converted to Double");
			}
		}
		
		return value;
	}

	/**
		 * Gets a float attribute
		 * @param attName is the name of the atribute to be retrieved
		 * @return the String type attribute or null if the attribute does not exist
		 * or it cannot be converted to a string.
		 * @throws WrongAttributeTypeException if the attribute exists but the type is wrong
		 */	
	public float getFloat(String attName) throws WrongAttributeTypeException {
		float value = 0;
		Object obj = eventAttributes.get(attName);
		if (obj != null) {
			if (obj instanceof Double) {
				value = ((Double) obj).floatValue();
			} else if (obj instanceof Float) {
				value = ((Float) obj).floatValue();
			} else if (obj instanceof Integer) {
				value = ((Integer) obj).floatValue();
			} else if (obj instanceof Long) {
				value = ((Long) obj).floatValue();
			} else {
				throw new WrongAttributeTypeException("Attribute exists but cannot be converted to Float");
			} 
		}
		
		return value;
	}

	/**
		 * Gets a int attribute
		 * @param attName is the name of the atribute to be retrieved
		 * @return the String type attribute or null if the attribute does not exist
		 * or it cannot be converted to a string.
		 * @throws WrongAttributeTypeException if the attribute exists but the type is wrong
		 */	
	public int getInt(String attName) throws WrongAttributeTypeException {
		int value = 0;
		Object obj = eventAttributes.get(attName);
		if (obj != null) {
			if (obj instanceof Double) {
				value = ((Double) obj).intValue();
			} else if (obj instanceof Float) {
				value = ((Float) obj).intValue();
			} else if (obj instanceof Integer) {
				value = ((Integer) obj).intValue();
			} else if (obj instanceof Long) {
				value = ((Long) obj).intValue();
			} else {
				throw new WrongAttributeTypeException("Attribute exists but cannot be converted to Integer");
			} 
		}
		
		return value;
	}

	/**
		 * Gets a long attribute
		 * @param attName is the name of the atribute to be retrieved
		 * @return the String type attribute or null if the attribute does not exist
		 * or it cannot be converted to a string.
		 * @throws WrongAttributeTypeException if the attribute exists but the type is wrong
		 */		
	public long getLong(String attName) throws WrongAttributeTypeException {
		long value = 0;
		Object obj = eventAttributes.get(attName);
		if (obj != null) {
			if (obj instanceof Double) {
				value = ((Double) obj).longValue();
			} else if (obj instanceof Float) {
				value = ((Float) obj).longValue();
			} else if (obj instanceof Integer) {
				value = ((Integer) obj).longValue();
			} else if (obj instanceof Long) {
				value = ((Long) obj).longValue();
			} else {
				throw new WrongAttributeTypeException("Attribute exists but cannot be converted to Long");
			} 

		}
		
		return value;
	}

	/**
		 * Gets a byte[] attribute
		 * @param attName is the name of the atribute to be retrieved
		 * @return the String type attribute or null if the attribute does not exist
		 * or it cannot be converted to a string.
		 * @throws WrongAttributeTypeException if the attribute exists but the type is wrong
		 */
	public byte[] getByteArray(String attName) throws WrongAttributeTypeException {
		byte[] value = new byte[1];
		value[0] = 0;
		Object obj = eventAttributes.get(attName);
		if (obj != null) {
			if (obj instanceof byte[]) {
				value = (byte[]) obj;
			} else if (obj instanceof Double) {
				value[0] = ((Double) obj).byteValue();
			} else if (obj instanceof Float) {
				value[0] = ((Float) obj).byteValue();
			} else if (obj instanceof Integer) {
				value[0] = ((Integer) obj).byteValue();
			} else if (obj instanceof Long) {
				value[0] = ((Long) obj).byteValue();
			} else if (obj instanceof String) {
				value = ((String) obj).getBytes();
			} else {
				throw new WrongAttributeTypeException("Attribute exists but cannot be converted to byte[]");
			} 

		}
		
		return value;
	}

	/**
		 * Gets a boolean attribute
		 * @param attName is the name of the atribute to be retrieved
		 * @return the String type attribute or null if the attribute does not exist
		 * or it cannot be converted to a string.
		 * @throws WrongAttributeTypeException if the attribute exists but the type is wrong
		 */	
	public boolean getBoolean(String attName) throws WrongAttributeTypeException {
		boolean value = false;
		Object obj = eventAttributes.get(attName);
		if (obj != null) {
			if (obj instanceof Boolean) {
				value = ((Boolean) obj).booleanValue();
			} else {
				throw new WrongAttributeTypeException("Attribute exists but cannot be converted to boolean");
			} 
		}
		return value;
	}
	
	/**
	 *  Removes every attribute from this YanceesEvent.
	 **/
	public void clearAll() {
		eventAttributes.clear();
		this.message = null;
	}

	
	public int numberOfAttributes() {
		return eventAttributes.size();
	}
   
	
	public Object get(String attName) {
		return eventAttributes.get(attName);
	}
	
   public void remove(String attName) {
   	eventAttributes.remove(attName);
   }
   
	
	public void put (String attName, String value) {
		eventAttributes.put(attName, value);
		
	}
	
	public void put (String attName, double value) {
		eventAttributes.put(attName, new Double(value));
	}
	
	public void put (String attName, float value) {
		eventAttributes.put(attName, new Float(value));
	}
	
	public void put (String attName, boolean value) {
		eventAttributes.put(attName, new Boolean(value));
	}
	
	public void put (String attName, byte[] value) {
		eventAttributes.put(attName, value);
	}
	
	public void put (String attName, int value) {
		eventAttributes.put(attName, new Integer(value));
	}
	
	public void put (String attName, long value) {
		eventAttributes.put(attName, new Long(value));
	}
		
	/**
	 * Returns an iterator for the set of attribute names of this
	 *	SienaEvent body.
	 **/
	public Iterator getAttributeNamesIterator() {
		return eventAttributes.keySet().iterator();
	}
	
	/**
	 * Prints the structure of the evetn using a free notation.
	 */
	public String toString() {
		StringBuffer sb = new StringBuffer();

		sb.append("\nEVENT:\n\n");

		for (Iterator i = eventAttributes.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			sb.append(key);
			sb.append(" = ");
			sb.append(eventAttributes.get(key));
			sb.append('\n');
		}
		return sb.toString();
	}

	/**
	 * Returns the XML type clause for this attribute, according to its
	 * Java type.
	 * 
	 * @param obj
	 * @return a string representing the type of the attribute. 
	 */
	private String getAttributeType (Object obj) {
		String type = null;
		
		if (obj instanceof byte[]) {
			type = BINARY_TYPE;
		} else if (obj instanceof String) {
			type = STRING_TYPE;
		} else if (obj instanceof Boolean) {
			type = BOOLEAN_TYPE;
		} else if (obj instanceof Double) {
			type = DOUBLE_TYPE;
		} else if (obj instanceof Float) {
			type = FLOAT_TYPE;
		} else if (obj instanceof Long) {
			type = LONG_TYPE;
		} else if (obj instanceof Integer) {
			type = INT_TYPE;
		} 

		return type;
	}
	
	/**
	 * Given a String value and a type, creates an object of that type with
	 * its corresponding value, according to its type.
	 * @param attValue
	 * @param attType
	 * @return an object according to the type provided, with the value specified.
	 */
	private Object createObject(String attValue, String attType) {
		Object unknownObject = null;
		
		if (attType.equals(BINARY_TYPE) || attType.endsWith(BINARY_TYPE)) {
			return attValue.getBytes();
		} else if (attType.equals(STRING_TYPE) || attType.endsWith(STRING_TYPE)) {
			return attValue;	
		} else if (attType.equals(INT_TYPE) || attType.endsWith(INT_TYPE)) {
			return new Integer(attValue);
		} else if (attType.equals(BOOLEAN_TYPE) || attType.endsWith(BOOLEAN_TYPE)) {
			return Boolean.valueOf(attValue);	
		} else if (attType.equals(DOUBLE_TYPE) || attType.endsWith(DOUBLE_TYPE)) {
			return new Double(attValue);
		} else if (attType.equals(FLOAT_TYPE) || attType.endsWith(FLOAT_TYPE)) {
			return new Float(attValue);
		} else if (attType.equals(LONG_TYPE) || attType.endsWith(LONG_TYPE)) {
			return new Long(attValue); 
		}
		
		return unknownObject;
	}

	/**
	 * Prints the XML hierarchy that represents the current event.
	 */
	public String toXML() {
		StringBuffer sb = new StringBuffer();
		sb.append("<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n");
		sb.append(
			"<event "
				+ "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n"
				+ "       xsi:noNamespaceSchemaLocation=\"sienaEvent.xsd\">\n");

		for (Iterator i = eventAttributes.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			String ident = "      ";
			String step = "   ";
			sb.append(ident + "<attribute>\n");
			sb.append(ident + step + "<name>\n");
			sb.append(ident + step + step + key + '\n');
			sb.append(ident + step + "</name>\n");
			sb.append(ident + step + "<value");
			sb.append(
				" type = \""
					+ getAttributeType(eventAttributes.get(key))
					+ "\"");
			sb.append(">\n");
			sb.append(
				ident + step + step + eventAttributes.get(key) + '\n');
			sb.append(ident + step + "</value>\n");
			sb.append(ident + "</attribute>\n");
			sb.append('\n');
		}

		sb.append("</event>\n");

		return sb.toString();

	}

	/**
	* Changes the content of this message. Replaces it with the XML content
	* provided in the String provided
	* @param content is the new XML format contnet in the form of a String
	*/
	public void setXMLTextContent(String content) {
		/**@todo Implement this method*/
		throw new java.lang.UnsupportedOperationException(
			"Method setXMLTextContent() not yet implemented.");
	}

	/**
	 * @return the content of this message in the text form, as a string.
	 */
	public String getXMLTextContent() {
		return toXML();
	}

	

}
