/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package test.performance;

// used to get attributes// used to get child nodes
// used to get attributes
// used to get child nodes
import java.io.File;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.Date;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.GenericEvent;
import edu.uci.isr.yancees.GenericMessage;
import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.YanceesException;
import edu.uci.isr.yancees.client.rmi.YanceesRMIClient;

public class YanceesNotificationTest implements SubscriberInterface {

	static int repetitions = 1000;
	
	public YanceesNotificationTest() throws RemoteException {
		super();
	}

	Date[] beginSubscribe = new Date[repetitions];
	Date[] endSubscribe = new Date[repetitions];
	Date[] beginPublish = new Date[repetitions];
	Date[] endPublish = new Date[repetitions];
	Date eventSent;
	Date[] notificationReceived = new Date[repetitions];
	Date[] averageCycles = new Date[repetitions];
	
	int notifCounter = 0; // number of notifications received

	public static void main(String argv[]) {
		//RemoteYanceesInterface yanceesRemote = null;
		String hostname;
		String subscriptionFileName;
		String eventFileName;
		
		YanceesRMIClient yancees = null;

		if (argv.length != 3) {
			System.err.println(
				"Usage: java YanceesPerformanceTest hosthame subscription.xml event.xml");
			System.exit(1);
		}

		hostname = argv[0];
		subscriptionFileName = argv[1];
		eventFileName = argv[2];

		GenericMessage subscriptionMsg = null;
		EventInterface event = null;

		// create the subscription message
		try {
			subscriptionMsg = new GenericMessage(new File(subscriptionFileName));
		} catch (IOException ex) {
			System.out.println(ex);
		}
		if (subscriptionMsg == null) {
			System.out.println("Problem when reading and creating subscription!");
			System.exit(1);
		}

		// create the event
		try {
			event = new GenericEvent(new File(eventFileName));
		} catch (IOException ex) {
			System.out.println(ex);
		}
		if (event == null) {
			System.out.println("Problem when reading and creating event!");
			System.exit(1);
		}

		// Create an instance of this class
		YanceesNotificationTest myInstance = null;
		
		try {
			yancees = new YanceesRMIClient(hostname);
		} catch (YanceesException e) {
		   System.out.println("Error when creating YANCEES client");
			System.out.println(e);
			e.printStackTrace();
		}
		
		System.out.println("YanceesNotificationTest: Subscribing...");
		try {
			myInstance = new YanceesNotificationTest();	
			

			System.out.println("YanceesNotificationTest: Posting 1 subscription...");
			
			for (int i=0; i<1; i++) {
				myInstance.beginSubscribe[i] = new Date();
				yancees.subscribe(
					subscriptionMsg,
					(SubscriberInterface) myInstance);
				myInstance.endSubscribe[i] = new Date();
			}
			
			// Waits some time for the subscription to be established.
			try {
				Thread.sleep(2000);

			} catch (InterruptedException ex) {
				System.out.println(ex);
			}		
			
			System.out.println("YanceesNotificationTest: Waiting for notifications...");
			
			// Start flooding the system with events...
			System.out.println("YanceesNotificationTest: Publishing "+repetitions+" events...");
			for (int i=0; i<repetitions; i++) {
				myInstance.beginPublish[i] = new Date();
				yancees.publish(event);
				myInstance.endPublish[i] = new Date();
			}
			System.out.println("YanceesNotificationTest: Waiting for "+repetitions+" notificatios...");
			
			
			//	We need to wait some time in order to re ceive all the remaining notifications
			// before we close the connection.
			while (myInstance.notifCounter < repetitions-1) {
				try {
					Thread.sleep(1000);
					System.out.println("Total events received up to now = "+myInstance.notifCounter);
				} catch (InterruptedException ex) {
					System.out.println(ex);
				}
			}
			
			
			System.out.println("Unsubscribing...");
			yancees.unsubscribe(myInstance);
			
		} catch (YanceesException ex) {
			System.out.println(ex);
		} catch (RemoteException ex) {
			System.out.println(ex);
		}

		myInstance.printStatistics();
		
		/*
		while (true) {
		   try {
		      Thread.sleep(500);
		   } catch (InterruptedException ex) {
		      System.out.println(ex);
		   }
		}
		*/

	} // main

	public void printStatistics() {
		long period;
		long sum;
		System.out.println("\n Performance data: \n");
		
		System.out.println("\nSubscription delays:");
		sum = 0;
		for (int i=0; i<1; i++) {
			period = endSubscribe[i].getTime() - beginSubscribe[i].getTime();
			System.out.println("Period: "+period+" ms");
			sum = sum + period;
		}
		System.out.println("Average = "+(sum / repetitions)+" ms");
		
		System.out.println("\nPublication delays:");
		sum = 0;		for (int i=0; i<repetitions; i++) {
			period = endPublish[i].getTime() - beginPublish[i].getTime();
			System.out.println("Period: "+period+" ms");
			sum = sum + period;
		}
		System.out.println("Average = "+(sum / repetitions)+" ms");
		
		System.out.println("\nNotification delays:");
		sum = 0;
		for (int i=0; i<repetitions; i++) {
				period = notificationReceived[i].getTime() - beginPublish[i].getTime();
				System.out.println("Period: "+period+" ms");
				sum = sum + period;
		}
		System.out.println("Average = "+(sum / repetitions)+" ms");
	}



	/**
	 * sends an <code>Event</code> to this <code>Subscriber</code>
	 *
	 * @param n Event passed to the Subscriber
	 *
	 **/
	public void notify(EventInterface evt) {
		notificationReceived[notifCounter] = new Date();
		notifCounter++;
		/*
		 
		 System.out.println(
			"YanceesNotificationTest: got Event: \n\n" + evt.toString());
			
		*/
		//System.out.println("Total events received up to now = "+notifCounter);
	}

	/**
	 * sends a sequence of <code>Event</code> evt to this
	 * <code>Subscriber</code>
	 *
	 * @param s sequence of Events passed to the Subscriber
	 *
	 **/
	public void notify(EventInterface[] evtList)  {
		for (int i=0; i<evtList.length; i++) {
			notificationReceived[notifCounter] = new Date();
			notifCounter++;
		}
		
	}

}