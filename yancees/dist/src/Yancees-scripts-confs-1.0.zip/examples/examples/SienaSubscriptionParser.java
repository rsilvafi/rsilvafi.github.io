/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 *
 * ===================================================================
 * The Apache Software License, Version 1.1
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 *
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 *
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package examples;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import siena.Filter;
import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.dispatcher.DispatcherException;
import edu.uci.isr.yancees.dispatcher.EventDispatcher;
import edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface;
import edu.uci.isr.yancees.server.dispatcher.siena.SienaRemoteAdapter;
import edu.uci.isr.yancees.server.dispatcher.siena.SienaSubscription;


/**
 * This program does:
 * 1) Parses the input file
 * 2) Build the components of Yancees necessary to interpret the XML
 * 3) Subscribes
 * 4) Echos matched events to the screen
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */
public class SienaSubscriptionParser {

   static final int ELEMENT_TYPE = Node.ELEMENT_NODE;
   static final int ATTR_TYPE = Node.ATTRIBUTE_NODE;
   static final int TEXT_TYPE = Node.TEXT_NODE;
   static final int CDATA_TYPE = Node.CDATA_SECTION_NODE;
   static final int ENTITYREF_TYPE = Node.ENTITY_REFERENCE_NODE;
   static final int ENTITY_TYPE = Node.ENTITY_NODE;
   static final int PROCINSTR_TYPE = Node.PROCESSING_INSTRUCTION_NODE;
   static final int COMMENT_TYPE = Node.COMMENT_NODE;
   static final int DOCUMENT_TYPE = Node.DOCUMENT_NODE;
   static final int DOCTYPE_TYPE = Node.DOCUMENT_TYPE_NODE;
   static final int DOCFRAG_TYPE = Node.DOCUMENT_FRAGMENT_NODE;
   static final int NOTATION_TYPE = Node.NOTATION_NODE;

   // Used by the validator parser to use the XML schema grammar.
   final String JAXP_SCHEMA_LANGUAGE =
         "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
   final String W3C_XML_SCHEMA = "http://www.w3.org/2001/XMLSchema";

   // callback interface to receive the notifications.
   MySubscriber callBackInterface;

   public static void main(String argv[]) {

      boolean createDocument = false;

      if (argv.length != 1) {
         System.err.println("Usage: java SienaSubscriptionParser filename");
         System.err.println("Creating my own document.");
         createDocument = true;
         //System.exit(1);
      }

      Document document;
      SienaSubscriptionParser parser = new SienaSubscriptionParser();
      if (createDocument) {
         document = parser.createFilter(SienaSubscription.OPERATORS[1],
                                        "some_name", "some_value");
      } else {
         document = parser.parseDocument(argv);
      }
      SienaSubscriptionParser.printDocument(document);
      SienaSubscription sub = null;
      try {
         System.out.print("Parsing the document... ");
         sub = new SienaSubscription(document);
         System.out.println("[OK]");
      } catch (Exception ex) {
         System.out.println("[ERROR]");
         System.out.println(ex);
      }
      if (sub != null) {
         Filter[] filters = sub.getFilters();
         for (int i = 0; i < filters.length; i++) {
            System.out.println(filters[i]);
         }

      }

      parser.subscribe(document);

   } // main

   public Document createFilter(String op, String attName, String attValue) {
      Document document = null;
      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

      try {
         DocumentBuilder builder = factory.newDocumentBuilder();

         String attType = "sienaString";

         document = builder.newDocument();
         Element root = (Element) document.createElement(SienaSubscription.
               SUBSCRIPTION);
         document.appendChild(root);
         Element filter = (Element) document.createElement(SienaSubscription.
               FILTER);
         root.appendChild(filter);
         Element operation = (Element) document.createElement(op);
         filter.appendChild(operation);
         Element name = (Element) document.createElement(SienaSubscription.NAME);
         operation.appendChild(name);
         name.appendChild(document.createTextNode(attName));
         Element value = (Element) document.createElement(SienaSubscription.
               VALUE);
         operation.appendChild(value);
         value.setAttribute(SienaSubscription.TYPE_ATTRIBUTE, attType);
         value.appendChild(document.createTextNode(attValue));

         document.getDocumentElement().normalize();

      } catch (ParserConfigurationException pce) {
         // Parser with specified options can't be built
         System.out.println(pce);
      }

      return document;

   }

   /**
    * Parsers a document from a file.
    */
   public Document parseDocument(String argv[]) {

      Document document = null;

      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      factory.setValidating(true);
      factory.setNamespaceAware(true);

      // Other factory options
      factory.setIgnoringComments(true);
      factory.setIgnoringElementContentWhitespace(true);
      factory.setCoalescing(true);
      factory.setExpandEntityReferences(false);

      // Instructs the factory to validate using xml schema.
      try {
         factory.setAttribute(JAXP_SCHEMA_LANGUAGE, W3C_XML_SCHEMA);
      } catch (IllegalArgumentException x) {
         System.out.println("This parser does not support JAXP 1.2");
         System.out.println(x);
      }

      try {
         DocumentBuilder builder = factory.newDocumentBuilder();
         // set error handler before parsing
         //builder.setErrorHandler(new MyErrorHandler(System.err));

         document = builder.parse(new File(argv[0]));

      } catch (SAXParseException spe) {
         // Error generated by the parser
         System.out.println("\n** Parsing error"
                            + ", line " + spe.getLineNumber()
                            + ", uri " + spe.getSystemId());
         System.out.println("   " + spe.getMessage());

         // Use the contained exception, if any
         Exception x = spe;
         if (spe.getException() != null) {
            x = spe.getException();
         }
         x.printStackTrace();

      } catch (SAXException sxe) {
         // Error generated during parsing)
         Exception x = sxe;
         if (sxe.getException() != null) {
            x = sxe.getException();
         }
         x.printStackTrace();

      } catch (ParserConfigurationException pce) {
         // Parser with specified options can't be built
         pce.printStackTrace();

      } catch (IOException ioe) {
         // I/O error
         ioe.printStackTrace();
      }

      return document;
   }

   /**
    * starts the server
    * and sends the parsed subscription to the server.
    */
   public void subscribe(Document document) {

      String sienaHost = "localhost";
      String port = "1234";
      String sienaAddress = "tcp:" + sienaHost + ":" + port;

      System.out.print("Starting Yancees Siena adapter...");
      SienaRemoteAdapter sienaAdapt = null;
		try {
			sienaAdapt = new SienaRemoteAdapter(sienaAddress);
		} catch (DispatcherException e) {
			e.printStackTrace();
		}
      EventDispatcher dispatcher = EventDispatcher.getInstance();
      dispatcher.addAdapter(sienaAdapt);
      System.out.println(" [OK]");

      System.out.print("Subscribing...");
      callBackInterface = new MySubscriber();
      SienaSubscription sub = null;
      try {
         sub = new SienaSubscription(document);
      } catch (Exception ex) {
         System.out.println(ex);
      }

      try {
         if (sub != null) {
            dispatcher.subscribe(sub, callBackInterface);
         }
      } catch (DispatcherException ex) {
         System.out.println(" [ERROR]");
         System.out.println(ex);
      }
      System.out.println(" [OK]");

      // We cannot shutdown siena like that...
      //sienaAdapt.shutdownDispatcher();

   }

   /**
    * Recursively parsers the dom model, using the facilities of the
    * AdapterNode class, and prints it to the standard output.
    */
   private static void printDocument(org.w3c.dom.Node n) {
      System.out.println("");
      printDocumentAux("", n);
      System.out.println("");

   }

   /**
    * Recursively prints the document with the proper identation.
    */
   private static void printDocumentAux(String ident, org.w3c.dom.Node n) {
      String identStep = "   ";
      if (n != null) {
         int type = n.getNodeType();

         switch (type) {
            case ELEMENT_TYPE:
               System.out.print(ident + "<" + n.getNodeName());
               if (n.hasAttributes()) {
                  System.out.print(" ");
                  NamedNodeMap map = n.getAttributes();
                  for (int i = 0; i < map.getLength(); i++) {
                     printDocumentAux(ident, map.item(i));
                  }
               }
               System.out.println(">");

               if (n.hasChildNodes()) {
                  NodeList list = n.getChildNodes();
                  for (int i = 0; i < list.getLength(); i++) {
                     printDocumentAux(ident + identStep, list.item(i));
                  }
               }
               System.out.println(ident + "</" + n.getNodeName() + ">");
               break;
            case ATTR_TYPE:
               System.out.print(n.getNodeName() + " = \"" + n.getNodeValue() +
                                "\" ");
               break;
            case TEXT_TYPE:
               System.out.println(ident + n.getNodeValue().trim());
               break;

            default:

               // Recursively call the child.
               if (n.hasChildNodes()) {
                  NodeList list = n.getChildNodes();
                  for (int i = 0; i < list.getLength(); i++) {
                     printDocumentAux(ident, list.item(i));
                  }
               }
         }

      } else {
         System.out.println("ERROR: document was not parsed properly...");
      }

   }

   /**
    * Error handler to report errors and warnings.
    * Allows the customization of the parsing error messages.
    */
   private static class MyErrorHandler
         implements ErrorHandler {
      /** Error handler output goes here */
      private PrintStream out;

      MyErrorHandler(PrintStream out) {
         this.out = out;
      }

      /**
       * Returns a string describing parse exception details
       */
      private String getParseExceptionInfo(SAXParseException spe) {
         String systemId = spe.getSystemId();
         if (systemId == null) {
            systemId = "null";
         }
         String info = "URI=" + systemId +
               " Line=" + spe.getLineNumber() +
               ": " + spe.getMessage();
         return info;
      }

      // The following methods are standard SAX ErrorHandler methods.
      // See SAX documentation for more info.

      public void warning(SAXParseException spe) throws SAXException {
         out.println("Warning: " + getParseExceptionInfo(spe));
      }

      public void error(SAXParseException spe) throws SAXException {
         String message = "Error: " + getParseExceptionInfo(spe);
         throw new SAXException(message);
      }

      public void fatalError(SAXParseException spe) throws SAXException {
         String message = "Fatal Error: " + getParseExceptionInfo(spe);
         throw new SAXException(message);
      }
   }

   /**
    * Receives notifications from the Yancees server and displays on the screen
    */
   public class MySubscriber
         implements EventDispatcherListenerInterface {

      /**
       * sends an <code>Event</code> to this <code>Subscriber</code>
       *
       * @param n Event passed to the Subscriber
       *
       **/
      public void receiveDispatcherNotification(EventInterface evt) {
         System.out.println("SienaSubscriptionParser: got Event: \n\n" + evt.toString());
      }

      /**
       * sends a sequence of <code>Event</code> evt to this
       * <code>Subscriber</code>
       *
       * @param s sequence of Events passed to the Subscriber
       *
       **/
      public void receiveDispatcherNotification(EventInterface[] evtList) {
         for (int i = 0; i < evtList.length; i++) {
            System.out.println("SienaSubscriptionParser: got Event: \n\n" + evtList[i].toString());
         }

      }
   }

}