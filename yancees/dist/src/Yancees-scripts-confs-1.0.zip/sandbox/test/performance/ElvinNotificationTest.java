/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package test.performance;

// used to get attributes// used to get child nodes
// used to get attributes
// used to get child nodes
import java.io.IOException;

import org.elvin.je4.Consumer;
import org.elvin.je4.ElvinURL;
import org.elvin.je4.Notification;
import org.elvin.je4.NotificationListener;
import org.elvin.je4.Producer;
import org.elvin.je4.Subscription;

public class ElvinNotificationTest {

	static int repetitions = 100;
	
	static long[] beginSubscribe = new long[repetitions];
	static long[] endSubscribe = new long[repetitions];
	static long[] beginPublish = new long[repetitions];
	static long[] endPublish = new long[repetitions];
	static long eventSent;
	static long[] notificationReceived = new long[repetitions];
	static long[] averageCycles = new long[repetitions];
	
	static int notifCounter = 0; // number of notifications received

	public static void main(String argv[]) {
		
		String hostname;
	
		if (argv.length != 1) {
			System.err.println(
				"Usage: java ElvinNotificationTest hostname ");
			System.exit(1);
		}

		hostname = argv[0];
		ElvinSubscriber subscriber = new ElvinSubscriber(hostname);
		ElvinPublisher publisher = new ElvinPublisher(hostname);
		subscriber.start();
		publisher.start();
		
		
		//printStatistics();
		

	} // main

	
	public static void printStatistics() {
		long period;
		long sum;
		System.out.println("\n Performance data: \n");
		
		System.out.println("\nNotifications Received: "+notifCounter);
		System.out.println("\nSubscription delays:");
		sum = 0;
		for (int i=0; i<1; i++) {
			period = endSubscribe[i] - beginSubscribe[i];
			//System.out.println("Period: "+period+" ms");
			sum = sum + period;
		}
		System.out.println("Average = "+(sum / repetitions)+" ms");
		
		System.out.println("\nPublication delays:");
		sum = 0;		for (int i=0; i<repetitions; i++) {
			period = endPublish[i] - beginPublish[i];
			//System.out.println("Period: "+period+" ms");
			sum = sum + period;
		}
		System.out.println("Average = "+(sum / repetitions)+" ms");
		
		System.out.println("\nNotification delays:");
		sum = 0;
		for (int i=0; i<repetitions; i++) {
				period = notificationReceived[i] - beginPublish[i];
				//System.out.println("Period: "+period+" ms");
				sum = sum + period;
		}
		System.out.println("Event Throughput Average = "+(sum / repetitions)+" ms");
		
	}

}

 class ElvinPublisher extends Thread {
	ElvinURL url;
	Producer elvinProducer = null;
		
	public ElvinPublisher(String hostname) {
		super();
		
		url = new ElvinURL(hostname);
		try {
			elvinProducer = new Producer(url);
		} catch (java.io.IOException ex) {
			System.out.println("Error when reading producer and consumer objects!");
			System.out.println(ex);
		}
	}
	
	public void run() {
		Notification event;
		System.out.println("ElvinPerformanceTest: Publishing "+ElvinNotificationTest.repetitions+" events...");
		for (int i=0; i<ElvinNotificationTest.repetitions; i++) {
			
			event = newEvent(i);
						
			try {
				ElvinNotificationTest.beginPublish[i] = System.currentTimeMillis();
				elvinProducer.notify(event);
				ElvinNotificationTest.endPublish[i] = System.currentTimeMillis();
				
				try {
					sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
		System.out.println("Finalizing ElvinPublisher...");
		elvinProducer.close();
	}
	
	public Notification newEvent(int counter) {
		Notification event = new Notification();
		event.put("name", "Roberto");
		event.put("age", 29);
		event.put("counter", counter);
		return event;
	}

	
}

 class ElvinSubscriber extends Thread implements NotificationListener {
	ElvinURL url;
	Consumer elvinConsumer = null;
			
	public ElvinSubscriber(String hostname) {
		super();
		url = new ElvinURL(hostname);
		try {
			elvinConsumer = new Consumer(url);
		} catch (java.io.IOException ex) {
			System.out.println("Error when reading producer and consumer objects!");
			System.out.println(ex);
		}
		
	}

	public void notificationAction(Notification arg0) {
		ElvinNotificationTest.notificationReceived[ElvinNotificationTest.notifCounter] = System.currentTimeMillis();
		ElvinNotificationTest.notifCounter++;
		System.out.println("Got noification "+ElvinNotificationTest.notifCounter);
		
	}
	
	
	public void run() {
		System.out.println("ElvinSubscriber: subscribing...");
		//Subscription mySubscription = new Subscription("(name == 'Roberto') && (age >18)");
		Subscription mySubscription = new Subscription("(name == 'Roberto')");
		mySubscription.addNotificationListener(this);
		
		try {
			ElvinNotificationTest.beginSubscribe[0] = System.currentTimeMillis();
			elvinConsumer.addSubscription(mySubscription);
			ElvinNotificationTest.endSubscribe[0] = System.currentTimeMillis();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		System.out.println("ElvinSubscriber: waiting for events...");
		
		while (ElvinNotificationTest.notifCounter < ElvinNotificationTest.repetitions) {
			try {
				sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Finalizing ElvinSubscriber...");
		elvinConsumer.close();
		ElvinNotificationTest.printStatistics();
		
	}
}