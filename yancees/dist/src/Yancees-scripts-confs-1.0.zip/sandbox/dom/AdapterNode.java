/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package dom;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */



import org.w3c.dom.Node;


 // This class wraps a DOM node and returns the text we want to
 // display in the tree. It also returns children, index values,
 // and child counts.
 public class AdapterNode {

   // An array of names for DOM node-types
    // (Array indexes = nodeType() values.)
   final String[] typeName = {
          "none",
          "Element",
          "Attr",
          "Text",
          "CDATA",
          "EntityRef",
          "Entity",
          "ProcInstr",
          "Comment",
          "Document",
          "DocType",
          "DocFragment",
          "Notation",
    };
    static final int ELEMENT_TYPE = Node.ELEMENT_NODE;
    static final int ATTR_TYPE = Node.ATTRIBUTE_NODE;
    static final int TEXT_TYPE = Node.TEXT_NODE;
    static final int CDATA_TYPE = Node.CDATA_SECTION_NODE;
    static final int ENTITYREF_TYPE = Node.ENTITY_REFERENCE_NODE;
    static final int ENTITY_TYPE = Node.ENTITY_NODE;
    static final int PROCINSTR_TYPE = Node.PROCESSING_INSTRUCTION_NODE;
    static final int COMMENT_TYPE = Node.COMMENT_NODE;
    static final int DOCUMENT_TYPE = Node.DOCUMENT_NODE;
    static final int DOCTYPE_TYPE = Node.DOCUMENT_TYPE_NODE;
    static final int DOCFRAG_TYPE = Node.DOCUMENT_FRAGMENT_NODE;
    static final int NOTATION_TYPE = Node.NOTATION_NODE;

    boolean compress = true;

    // The list of elements to display in the tree
    // Could set this with a command-line argument, but
    // not much point -- the list of tree elements still
    // has to be defined internally.
    // Extra credit: Read the list from a file
    // Super-extra credit: Process a DTD and build the list.

    String[] treeElementNames = {
          "evt:event",
          "evt:header",
          "evt:body",
          "sevt:attribute",
          "sevt:name",
          "sevt:value",
    };

    org.w3c.dom.Node domNode;

    // Construct an Adapter node from a DOM node
    public AdapterNode(org.w3c.dom.Node node) {
       domNode = node;
    }

    // Return a string that identifies this node in the tree
    public String toString() {
       String s = typeName[domNode.getNodeType()];
       String nodeName = domNode.getNodeName();
       if (!nodeName.startsWith("#")) {
          s += ": " + nodeName;
       }
       if (compress) {
          String t = getHTMLContent().trim();
          int x = t.indexOf("\n");
          if (x >= 0)
             t = t.substring(0, x);
          s += " " + t;
          return s;
       }
       if (domNode.getNodeValue() != null) {
          if (s.startsWith("ProcInstr"))
             s += ", ";
          else
             s += ": ";
             // Trim the value to get rid of NL's at the front
          String t = domNode.getNodeValue().trim();
          int x = t.indexOf("\n");
          if (x >= 0)
             t = t.substring(0, x);
          s += t;
       }
       return s;
    }

    /**
     * Prints the HTML content of the current Node.
     * You can probably use it to display the current node content in a web
     * browser.
     */
    public String getHTMLContent() {
       String s = "";
       org.w3c.dom.NodeList nodeList = domNode.getChildNodes();
       for (int i = 0; i < nodeList.getLength(); i++) {
          org.w3c.dom.Node node = nodeList.item(i);
          int type = node.getNodeType();
          AdapterNode adpNode = new AdapterNode(node); //inefficient, but works
          if (type == ELEMENT_TYPE) {
             // Skip subelements that are displayed in the tree.
             if (isTreeElement(node.getNodeName()))
                continue;

             // EXTRA-CREDIT HOMEWORK:
             //   Special case the SLIDE element to use the TITLE text
             //   and ignore TITLE element when constructing the tree.

             // EXTRA-CREDIT
             //   Convert ITEM elements to html lists using
             //   <ul>, <li>, </ul> tags

             s += "<" + node.getNodeName() + ">";
             s += adpNode.getHTMLContent();
             s += "</" + node.getNodeName() + ">";
          }
          else if (type == TEXT_TYPE) {
             s += node.getNodeValue();
          }
          else if (type == ENTITYREF_TYPE) {
             // The content is in the TEXT node under it
             s += adpNode.getHTMLContent();
          }
          else if (type == CDATA_TYPE) {
             // The "value" has the text, same as a text node.
             //   while EntityRef has it in a text node underneath.
             //   (because EntityRef can contain multiple subelements)
             // Convert angle brackets and ampersands for display
             StringBuffer sb = new StringBuffer(node.getNodeValue());
             for (int j = 0; j < sb.length(); j++) {
                if (sb.charAt(j) == '<') {
                   sb.setCharAt(j, '&');
                   sb.insert(j + 1, "lt;");
                   j += 3;
                }
                else if (sb.charAt(j) == '&') {
                   sb.setCharAt(j, '&');
                   sb.insert(j + 1, "amp;");
                   j += 4;
                }
             }
             s += "<pre>" + sb + "\n</pre>";
          }

          // Ignoring these:
          //   ATTR_TYPE      -- not in the DOM tree
          //   ENTITY_TYPE    -- does not appear in the DOM
          //   PROCINSTR_TYPE -- not "data"
          //   COMMENT_TYPE   -- not "data"
          //   DOCUMENT_TYPE  -- Root node only. No data to display.
          //   DOCTYPE_TYPE   -- Appears under the root only
          //   DOCFRAG_TYPE   -- equiv. to "document" for fragments
          //   NOTATION_TYPE  -- nothing but binary data in here
       }
       return s;
    }

    /*
     * Return children, index, and count values
     */
    public int index(AdapterNode child) {
       //System.err.println("Looking for index of " + child);
       int count = childCount();
       for (int i = 0; i < count; i++) {
          AdapterNode n = this.child(i);
          if (child.domNode == n.domNode)
             return i;
       }
       return -1; // Should never get here.
    }

    /**
     * Gets the child indexed. If compression is on, considers only nodes
     * of type ELEMENT_TYPE.
     */
    public AdapterNode child(int searchIndex) {
       //Note: JTree index is zero-based.
       org.w3c.dom.Node node =
             domNode.getChildNodes().item(searchIndex);
       if (compress) {
          // Return Nth displayable node
          int elementNodeIndex = 0;
          for (int i = 0; i < domNode.getChildNodes().getLength(); i++) {
             node = domNode.getChildNodes().item(i);
             if (node.getNodeType() == ELEMENT_TYPE
                 && isTreeElement(node.getNodeName())
                 && elementNodeIndex++ == searchIndex) {
                break;
             }
          }
       }
       return new AdapterNode(node);
    }

    /**
     * Count the number of children of the current node. Counts only
     * the element type nodes.
     */
    public int childCount() {
       if (!compress) {
          // Indent this
          return domNode.getChildNodes().getLength();
       }
       int count = 0;
       for (int i = 0; i < domNode.getChildNodes().getLength(); i++) {
          org.w3c.dom.Node node = domNode.getChildNodes().item(i);
          if (node.getNodeType() == ELEMENT_TYPE
              && isTreeElement(node.getNodeName())) {
             // Note:
             //   Have to check for proper type.
             //   The DOCTYPE element also has the right name
             ++count;
          }
       }
       return count;
    }

    /**
     * Used to filter the XML Schema elements to consider while parsing this
     * DOM tree. It uses the contents of teh treeElementNames for that.
     */
    boolean isTreeElement(String elementName) {
     for (int i = 0; i < treeElementNames.length; i++) {
        if (elementName.equals(treeElementNames[i]))
           return true;
     }
     return false;
  }


 }
