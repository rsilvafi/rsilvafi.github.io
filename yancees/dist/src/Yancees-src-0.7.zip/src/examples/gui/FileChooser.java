/*
 * Copyright (c) 2003, Regents of the University of California. All rights
 * reserved.
 * 
 * =================================================================== The
 * Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if any, must
 * include the following acknowledgment: "This product includes software
 * developed by the Institute for Software Research at University of California,
 * Irvine" Alternately, this acknowledgment may appear in the software itself,
 * if and wherever such third-party acknowledgments normally appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and "University of
 * California" must not be used to endorse or promote products derived from this
 * software without prior written permission. For written permission, please
 * contact rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called "YANCEES", nor may
 * "YANCEES" appear in their name, without prior written permission of the
 * University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * INSTITUTE FOR SOFTWARE RESEARCH AT THE UNIVERSITY OF CALIFORNIA, IRVINE, OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */

package examples.gui;

// FILE CHOOSER APPLICATION
// 14 June 2003
// Frans Coenen
// University of Liverpool

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FileChooser extends JFrame implements ActionListener {

   private final String OPEN_SUBSCRIPTION = "Open Subscription";
   private final String SUBSCRIBE = "Subscribe";
   private final String UNSUBSCRIBE = "Unsubscribe";
   
   // GUI features
   private BufferedReader fileInput;
   private JTextArea textArea;
   private JButton openSubscriptionButton, subscribeButton, unSubscribeButton;
   private JTextField fileNameField; 

   // Other fields
   private File fileName;
   private String[] fileContent;
   private int numLines;

   public FileChooser(String s) {
      super(s);

      // Content pane
      Container container = getContentPane();
      container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS)); 
      //container.setLayout(new BorderLayout(5, 5)); // 5 pixel gaps

      JPanel buttonsPanel = new JPanel();
      buttonsPanel.setLayout(new FlowLayout());
      
      // Open button
      openSubscriptionButton = new JButton(OPEN_SUBSCRIPTION);
      openSubscriptionButton.addActionListener(this);
      buttonsPanel.add(openSubscriptionButton);
      //container.add(openButton, BorderLayout.WEST);

      // Read and subscribe file button
      subscribeButton = new JButton(SUBSCRIBE);
      subscribeButton.addActionListener(this);
      subscribeButton.setEnabled(false);
      //container.add(readButton, BorderLayout.EAST);
      buttonsPanel.add(subscribeButton);
      
//    Read and subscribe file button
      unSubscribeButton = new JButton(UNSUBSCRIBE);
      unSubscribeButton.addActionListener(this);
      unSubscribeButton.setEnabled(false);
      //container.add(readButton, BorderLayout.EAST);
      buttonsPanel.add(unSubscribeButton);
      
      
      container.add(buttonsPanel);
      
      fileNameField = new JTextField(30);
      JPanel filePanel = new JPanel();
      filePanel.add(new JLabel("File Name: "));
      filePanel.add(fileNameField);
      container.add(filePanel);
      
      // Text area
      textArea = new JTextArea(30, 15);
      //container.add(new JScrollPane(textArea), BorderLayout.SOUTH);
      container.add(new JScrollPane(textArea));
   }

   /* ACTION PERFORMED */

   public void actionPerformed(ActionEvent event) {
      if (event.getActionCommand().equals(OPEN_SUBSCRIPTION)) { 
         getFileName();
         fileNameField.setText(fileName.getPath());
         fileNameField.update(fileNameField.getGraphics());
      }
      if (event.getActionCommand().equals(SUBSCRIBE)) {
         readFile();
      }
      
      if (event.getActionCommand().equals(UNSUBSCRIBE)) {
         
      }
   }

   /* OPEN THE FILE */

   private void getFileName() {
      // Display file dialog so user can select file to open
      JFileChooser fileChooser = new JFileChooser(new File(".").getPath());
      fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

      int result = fileChooser.showOpenDialog(this);

      // If cancel button selected return
      if (result == JFileChooser.CANCEL_OPTION) return;

      // Obtain selected file
      fileName = fileChooser.getSelectedFile();

      if (checkFileName()) {
         openSubscriptionButton.setEnabled(false);
         subscribeButton.setEnabled(true);
      }
   }

   /* READ FILE */

   private void readFile() {
      // Disable read button
      subscribeButton.setEnabled(false);

      // Dimension data structure
      getNumberOfLines();
      fileContent = new String[numLines];

      // Read file
      readTheFile();

      // Output to text area
      textArea.setText(fileContent[0] + "\n");
      for (int index = 1; index < fileContent.length; index++)
         textArea.append(fileContent[index] + "\n");

      // Rnable open button
      openSubscriptionButton.setEnabled(true);
   }

   /* GET NUMBER OF LINES */

   /* Get number of lines in file and prepare data structure. */

   private void getNumberOfLines() {
      int counter = 0;

      // Open the file
      openFile();

      // Loop through file incrementing counter
      try {
         String line = fileInput.readLine();
         while (line != null) {
            counter++;
            System.out.println("(" + counter + ") " + line);
            line = fileInput.readLine();
         }
         numLines = counter;
         closeFile();
      } catch (IOException ioException) {
         JOptionPane.showMessageDialog(this, "Error reading File", "Error 5: ",
               JOptionPane.ERROR_MESSAGE);
         closeFile();
         System.exit(1);
      }
   }

   /* READ FILE */

   private void readTheFile() {
      // Open the file
      openFile();
      System.out.println("Read the file");
      // Loop through file incrementing counter
      try {
         for (int index = 0; index < fileContent.length; index++) {
            fileContent[index] = fileInput.readLine();
            System.out.println(fileContent[index]);
         }
         closeFile();
      } catch (IOException ioException) {
         JOptionPane.showMessageDialog(this, "Error reading File", "Error 5: ",
               JOptionPane.ERROR_MESSAGE);
         closeFile();
         System.exit(1);
      }
   }

   /* CHECK FILE NAME */

   /*
    * Return flase if selected file is a directory, access is denied or is not a
    * file name.
    */

   private boolean checkFileName() {
      if (fileName.exists()) {
         if (fileName.canRead()) {
            if (fileName.isFile())
               return (true);
            else
               JOptionPane.showMessageDialog(null,
                     "ERROR 3: File is a directory");
         } else
            JOptionPane.showMessageDialog(null, "ERROR 2: Access denied");
      } else
         JOptionPane.showMessageDialog(null, "ERROR 1: No such file!");
      // Return

      return (false);
   }

   /* ------------------------------------------------------- */
   /*                                                         */
   /* FILE HANDLING UTILITIES */
   /*                                                         */
   /* ------------------------------------------------------- */

   /* OPEN FILE */

   private void openFile() {
      try {
         // Open file
         FileReader file = new FileReader(fileName);
         fileInput = new BufferedReader(file);
      } catch (IOException ioException) {
         JOptionPane.showMessageDialog(this, "Error Opening File", "Error 4: ",
               JOptionPane.ERROR_MESSAGE);
      }
      System.out.println("File opened");
   }

   /* CLOSE FILE */

   private void closeFile() {
      if (fileInput != null) {
         try {
            fileInput.close();
         } catch (IOException ioException) {
            JOptionPane.showMessageDialog(this, "Error Opening File",
                  "Error 4: ", JOptionPane.ERROR_MESSAGE);
         }
      }
      System.out.println("File closed");
   }

   /* ------------------------------------------------------- */
   /*                                                         */
   /* MAIN METHOD */
   /*                                                         */
   /* ------------------------------------------------------- */

   /* MAIN METHOD */

   public static void main(String[] args) throws IOException {
      // Create instance of class FileChooser
      FileChooser newFile = new FileChooser("File chooser");

      // Make window vissible
      newFile.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      newFile.setSize(500, 400);
      newFile.setVisible(true);
   }
}