/*
 * Copyright (c) 2003, Regents of the University of California.
 * All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE INSTITUTE FOR SOFTWARE RESEARCH AT THE UNIVERSITY
 * OF CALIFORNIA, IRVINE, OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 
package examples.gui;

import java.io.File;
import java.io.IOException;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.GenericMessage;
import edu.uci.isr.yancees.MessageInterface;
import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.YanceesException;
import edu.uci.isr.yancees.client.rmi.YanceesRMIClient;

/**
 * @author rsilvafi
 * class created at May 18, 2004
 * 
 */
public class GUISubscriber implements SubscriberInterface {

   YanceesRMIClient yancees = null;
   String hostname = "localhost";
   String fileName = null;
   GUISubscriberFrame myFrame = null;
   
   public static void main(String argv[]) {


      if (argv.length != 0) {
         System.err.println("Usage: java examples.gui.GUISubscriber");
         System.exit(1);
      }

      // Create an instance of this class
      GUISubscriber myInstance;
      myInstance = new GUISubscriber();

      //System.out.println("RMISubscriber: Waiting for notifications...");
      /*
      while (true) {
         try {
            Thread.sleep(500);
         } catch (InterruptedException ex) {
            System.out.println(ex);
         }
      }
      */

   } // main
   
   // constructor
   public GUISubscriber() {
      super();
      myFrame = new GUISubscriberFrame("Subscriber", this);
     
      // Make window vissible
      myFrame.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
      myFrame.setSize(500, 400);
      myFrame.setVisible(true);
      
   }
   
   
   public void connectToYancees (String hostname) {
      try {
         yancees = new YanceesRMIClient(hostname);
         
      } catch (YanceesException ex) {
         System.out.println(ex);
      }
   }
   
   public boolean isConnected() {
      return yancees != null;
   }
   
   public void disconnect() {
      yancees = null;
   }
 
   public void subscribeToString(String sub) throws YanceesException {
      MessageInterface msg = null;
      
      msg = new GenericMessage(sub);
      
      if (msg == null) {
         System.exit(1);
      }
         
      yancees.subscribe(msg, (SubscriberInterface) this);       
   }
 
   
   public void subscribeToFile(File file) throws YanceesException {
      MessageInterface msg = null;
      
      try {
         msg = new GenericMessage(file);
      } catch (IOException ex) {
         throw new YanceesException(ex.toString());
      }
      if (msg == null) {
         System.exit(1);
      }
         
      yancees.subscribe(msg, (SubscriberInterface) this);       
   }
   
   public void subscribeToFileName(String filename) throws YanceesException {

      File file = new File(filename);
      subscribeToFile(file);    
   }
   
   public void unsubscribe() {
      
      try {
         yancees.unsubscribe(this);
      } catch (YanceesException e) {
         System.out.println(e);
         e.printStackTrace();
      }
      
   }
   

   /**
    * sends an <code>Event</code> to this <code>Subscriber</code>
    *
    * @param n Event passed to the Subscriber
    *
    **/
   public void notify(EventInterface evt) {
      System.out.println("GUISubscriber: got Event: \n\n" + evt.toString());
      myFrame.printNewEvent(evt.toString());
   }

   /**
    * sends a sequence of <code>Event</code> evt to this
    * <code>Subscriber</code>
    *
    * @param s sequence of Events passed to the Subscriber
    *
    **/
   public void notify(EventInterface[] evtList) {
      for (int i = 0; i < evtList.length; i++) {
         System.out.println("GUISubscriber: got Event: \n\n" + evtList[i].toString());
         myFrame.printNewEvent(evtList[i].toString());
      }

   }
   
   
}
