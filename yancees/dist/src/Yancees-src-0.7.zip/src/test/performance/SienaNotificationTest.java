/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package test.performance;

// used to get attributes// used to get child nodes
// used to get attributes
// used to get child nodes
import java.util.Date;

import siena.Filter;
import siena.HierarchicalDispatcher;
import siena.Notifiable;
import siena.Notification;
import siena.Op;
import siena.SienaException;
import siena.comm.InvalidSenderException;
import siena.comm.PacketSenderException;

public class SienaNotificationTest implements Notifiable {

	static int repetitions = 10;
	
	long[] beginSubscribe = new long[repetitions];
	long[] endSubscribe = new long[repetitions];
	long[] beginPublish = new long[repetitions];
	long[] endPublish = new long[repetitions];
	Date eventSent;
	long[] notificationReceived = new long[repetitions];
	long[] averageCycles = new long[repetitions];
	
	int notifCounter = 0; // number of notifications received

	public static void main(String argv[]) {
		HierarchicalDispatcher siena = null;
		String hostname;
		String subscriptionFileName;
		String eventFileName;

		if (argv.length != 1) {
			System.err.println(
				"Usage: java SienaNotificationTest hosthame ");
			System.exit(1);
		}

		hostname = argv[0];
		
		
		// Create an instance of this class
		SienaNotificationTest myInstance = null;
		
		siena = new HierarchicalDispatcher();
   	try {
   	siena.setMaster(hostname);
   	} catch (PacketSenderException ex) {
   		System.out.println(ex);
   		System.exit(1);
   	} catch (java.io.IOException ex) {
			System.out.println(ex);
			System.exit(1);
   	} catch (InvalidSenderException ex) {
			System.out.println(ex);
			System.exit(1);
   	}

		
		System.out.println("SienaPerformanceTest: Subscribing...");
		try {
			myInstance = new SienaNotificationTest();	
			

			System.out.println("SienaPerformanceTest: Posting 1 subscription...");
			
			Filter mySubscription = new Filter();
			mySubscription.addConstraint("name", "Roberto"); // name = "Antonio"
			mySubscription.addConstraint("age", Op.GT, 18);	// age > 18
			
			for (int i=0; i<1; i++) {
				myInstance.beginSubscribe[i] = System.currentTimeMillis();
				siena.subscribe(mySubscription, myInstance);
				myInstance.endSubscribe[i] = System.currentTimeMillis();
			}
			System.out.println(
				"SienaPerformanceTest: Waiting for notifications...");

			Notification event = new Notification();
			event.putAttribute("name", "Roberto");
			event.putAttribute("age", 29);
			
			System.out.println("SienaPerformanceTest: Publishing "+repetitions+" events...");
			for (int i=0; i<repetitions; i++) {
				myInstance.beginPublish[i] = System.currentTimeMillis();
				siena.publish(event);
				myInstance.endPublish[i] = System.currentTimeMillis();
				myInstance.pause();
			}
			

			// We need to wait some time in order to receive all the remaining notifications
			// before we close the connection.
			try {
				Thread.sleep(2000);
			} catch (InterruptedException ex) {
				System.out.println(ex);
			}
			
			System.out.println("Unsubscribing...");
			siena.unsubscribe(myInstance);
			
		} catch (SienaException ex) {
			System.out.println(ex);
		}

		myInstance.printStatistics();
		
		/*
		while (true) {
		   try {
		      Thread.sleep(500);
		   } catch (InterruptedException ex) {
		      System.out.println(ex);
		   }
		}
		*/

	} // main
	
	private void pause() {
		try {
			Thread.sleep(300);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void printStatistics() {
		long period;
		long sum;
		System.out.println("\n Performance data: \n");
		
		System.out.println("\nSubscription delays:");
		sum = 0;
		for (int i=0; i<1; i++) {
			period = endSubscribe[i] - beginSubscribe[i];
			System.out.println("Period: "+period+" ms");
			sum = sum + period;
		}
		System.out.println("Average = "+(sum / repetitions)+" ms");
		
		System.out.println("\nPublication delays:");
		sum = 0;		for (int i=0; i<repetitions; i++) {
			period = endPublish[i] - beginPublish[i];
			System.out.println("Period: "+period+" ms");
			sum = sum + period;
		}
		System.out.println("Average = "+(sum / repetitions)+" ms");
		
		System.out.println("\nNotification delays:");
		sum = 0;
		for (int i=0; i<repetitions; i++) {
				period = notificationReceived[i] - beginPublish[i];
				System.out.println("Period: "+period+" ms");
				sum = sum + period;
		}
		System.out.println("Average = "+(sum / repetitions)+" ms");
	}



	/* (non-Javadoc)
	 * @see siena.Notifiable#notify(siena.Notification)
	 */
	public void notify(Notification arg0) throws SienaException {
		notificationReceived[notifCounter] = System.currentTimeMillis();
		notifCounter++;

	}

	/* (non-Javadoc)
	 * @see siena.Notifiable#notify(siena.Notification[])
	 */
	public void notify(Notification[] arg0) throws SienaException {
		for (int i=0; i<arg0.length; i++) {
			notificationReceived[notifCounter] = System.currentTimeMillis();
			notifCounter++;
		}
		
		// TODO Auto-generated method stub

	}

}