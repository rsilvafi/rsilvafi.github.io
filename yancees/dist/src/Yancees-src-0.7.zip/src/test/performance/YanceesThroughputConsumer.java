package test.performance;

import java.io.File;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.GenericMessage;
import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.client.rmi.YanceesRMIClient;

//import AwacsSimulatorEvent;
public class YanceesThroughputConsumer extends Thread
    implements SubscriberInterface
{
    int numberOfEvents = 0;
    int eventsPerCycle = 0;
    int CYCLE_TIME = 1000; // 1 second

    public static void main(String[] args)
        throws Exception
    {
        String hostname = "localhost";
        GenericMessage subscriptionMsg;

        if (args.length != 2)
        {
            System.out.println(
                "Usage: java YanceesThroughputConsumer hostname subscriptionFile.xml");
            System.exit(0);
        }
			
		  hostname = args[0];
        File subscriptionFile = new File(args[1]);

        //		create the subscription message
        subscriptionMsg = new GenericMessage(subscriptionFile);

        YanceesThroughputConsumer consumer = new YanceesThroughputConsumer();
        YanceesRMIClient yancees = new YanceesRMIClient(hostname);

		  System.out.println("Subscribing to:");
		  System.out.println(subscriptionMsg.getXMLTextContent());


        yancees.subscribe(subscriptionMsg, consumer);
        System.out.println("waiting for events...");
        consumer.start();
    }

    public void run()
    {
        while (true)
        {
            System.out.println("Total events received: " + numberOfEvents);
            System.out.println("Throughput: " + eventsPerCycle + " events/s");
            eventsPerCycle = 0;

            try
            {
                Thread.sleep(CYCLE_TIME);
            }
            catch (InterruptedException e)
            {
                System.out.println(e);
                e.printStackTrace();
            }
        }
    }

    /* (non-Javadoc)
     * @see
    edu.uci.isr.yancees.SubscriberInterface#notify(edu.uci.isr.yancees.EventInterface)
     */
    public void notify(EventInterface arg0)
    {
        numberOfEvents++;
        eventsPerCycle++;
    }

    /* (non-Javadoc)
     * @see
    edu.uci.isr.yancees.SubscriberInterface#notify(edu.uci.isr.yancees.EventInterface[])
     */
    public void notify(EventInterface[] arg0)
    {
        numberOfEvents = numberOfEvents + arg0.length;
        eventsPerCycle = eventsPerCycle + arg0.length;
    }
}
