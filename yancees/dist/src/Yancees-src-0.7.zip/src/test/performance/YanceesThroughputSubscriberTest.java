
/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package test.performance;

// used to get attributes// used to get child nodes
// used to get attributes
// used to get child nodes
import java.io.File;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.Date;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.GenericMessage;
import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.YanceesException;
import edu.uci.isr.yancees.client.rmi.YanceesRMIClient;

public class YanceesThroughputSubscriberTest implements SubscriberInterface {

	static int repetitions = 100000;
	static int interval = 50; // interval in ms betwen repetitive operations
	
	public YanceesThroughputSubscriberTest() throws RemoteException {
		super();
	}

	Date[] beginSubscribe = new Date[repetitions];
	Date[] endSubscribe = new Date[repetitions];
	Date[] beginPublish = new Date[repetitions];
	Date[] endPublish = new Date[repetitions];
	Date eventSent;
	//Date[] notificationReceived = new Date[repetitions];
	Date[] averageCycles = new Date[repetitions];
	
	
	Date beginDate = null;
	Date endDate = null;
	
	int notifCounter = 0; // number of notifications received

	public static void main(String argv[]) {
		//RemoteYanceesInterface yanceesRemote = null;
		
		YanceesRMIClient yancees = null;
		
		String hostname;
		String subscriptionFileName;
		String eventFileName;

		if (argv.length != 2) {
			System.err.println(
				"Usage: java SubscribePerformanceTest hosthame subscription.xml");
			System.exit(1);
		}

		hostname = argv[0];
		subscriptionFileName = argv[1];

		GenericMessage subscriptionMsg = null;
		EventInterface event = null;

		// create the subscription message
		try {
			subscriptionMsg = new GenericMessage(new File(subscriptionFileName));
		} catch (IOException ex) {
			System.out.println(ex);
		}
		if (subscriptionMsg == null) {
			System.out.println("Problem when reading and creating subscription!");
			System.exit(1);
		}
		
		// Create an instance of this class
		YanceesThroughputSubscriberTest myInstance = null;
		
		
		
		try {
			yancees = new YanceesRMIClient(hostname);
		} catch (YanceesException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		
		System.out.println("YanceesPerformanceTest: Subscribing...");
		try {
			myInstance = new YanceesThroughputSubscriberTest();	
			
			System.out.println("Subscribing to:");
			System.out.println(subscriptionMsg.getXMLTextContent());

			System.out.println("YanceesPerformanceTest: Posting 1 subscription...");
			System.out.println("Waiting for "+repetitions+" events to come");
			
				myInstance.beginSubscribe[0] = new Date();
				yancees.subscribe(
					subscriptionMsg,
					(SubscriberInterface) myInstance);
				myInstance.endSubscribe[0] = new Date();			
			
			int eventRate = 0;
			int lastCount = 0;
			while (myInstance.notifCounter < repetitions) {
				try {
					Thread.sleep(1000);
					eventRate = myInstance.notifCounter - lastCount;
					lastCount = myInstance.notifCounter;
					System.out.println("Got "+myInstance.notifCounter+" notifications up to now. "+eventRate+" events/s");
				} catch (InterruptedException e1) {
					System.out.println(e1);
					e1.printStackTrace();
				}
			}
			
			System.out.println("Unsubscribing...");
			yancees.unsubscribe(myInstance);

		} catch (YanceesException ex) {
			System.out.println(ex);
		} catch (RemoteException ex) {
			System.out.println(ex);
		}

		// wait for delayed events...
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e1) {
			System.out.println(e1);
			e1.printStackTrace();
		}
		myInstance.printStatistics();
		
		/*
		while (true) {
		   try {
		      Thread.sleep(500);
		   } catch (InterruptedException ex) {
		      System.out.println(ex);
		   }
		}
		*/

	} // main

	public void printStatistics() {
		System.out.println();
		System.out.println("End date: "+endDate);
		System.out.println("Begin date: "+beginDate);
		long difference = endDate.getTime() - beginDate.getTime();
		double rate = repetitions / difference;
		System.out.println("Total time: "+difference+" ms");
		System.out.println("Average throughput: "+rate + " events/ms");
		System.out.println("Average throughput: "+repetitions/(difference/1000) + " events/s");
	}

	/**
	 * sends an <code>Event</code> to this <code>Subscriber</code>
	 *
	 * @param n Event passed to the Subscriber
	 *
	 **/
	public void notify(EventInterface evt) {
		//notificationReceived[notifCounter] = new Date();
		
		if (notifCounter == 0 )
			beginDate = new Date();
		
		notifCounter++;
		
		if (notifCounter >= repetitions) 
			endDate = new Date();
		
	}

	/**
	 * sends a sequence of <code>Event</code> evt to this
	 * <code>Subscriber</code>
	 *
	 * @param s sequence of Events passed to the Subscriber
	 *
	 **/
	public void notify(EventInterface[] evtList) {
		
		if (notifCounter == 0)
			beginDate = new Date();
		
		//notificationReceived[notifCounter] = new Date();
		notifCounter = notifCounter+evtList.length;
		
		if (notifCounter >= repetitions) 
			endDate = new Date();
	
	}

}
