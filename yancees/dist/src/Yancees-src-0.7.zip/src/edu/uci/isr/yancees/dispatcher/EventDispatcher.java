/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.dispatcher;

import java.util.HashMap;
import java.util.Vector;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.SubscriptionInterface;


/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

/**
 *
 * This class works as a wrapper around an event dispatcher implementation, It
 * allows the registratoin of different adapters for to handle the content-based
 * subscriptions of the system.
 */
public class EventDispatcher
      implements EventDispatcherInterface {

   private Vector adapterList; // list of all EventDispatcherInterface implementing objects.
   private boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG;
   private java.util.HashMap adapterLookupTable;
   
   /*
   private boolean MULTI_THREADED = false;
   private int numberOfThreads = 0;
   private int THREAD_LIMIT = 100;
   private int THREAD_SLEEP_TIME = 50;
   */
   
   // Unique instance of this singleton.
   private static EventDispatcher myInstance;

   /**
    * This constructor, as protected, prevents the direct instantiation of this
    * object, and  guarantees the singleton characteristic of this class. The
    * protected modifyer allows this class to be subclassed, permiting the over-
    * load of the constructor.
    */
   protected EventDispatcher() {
		adapterList = new Vector();
		adapterLookupTable = new HashMap();
   }

   /**
    * The only way to access the unique instance of EventDispatcher is by
    * using this access method
    */
   public static EventDispatcher getInstance() {
      if (myInstance == null) {
         myInstance = new EventDispatcher();
      }
      return myInstance;
   }

   /**
    * Configures the event dispatcher with the proper adapter.
    * The dispatcher is a fa�ade to the implementation-specific adapter. The use of
    * this fa�ade allows the runtime change of the adapter. Otherwise a simple
    * inheritance would be enough.
    */
   public void addAdapter(EventDispatcherAdapterInterface adp) { 
      adapterList.add(adp);
      adapterLookupTable.put(adp.getAdapterName(), adp);
   }
   
   public void removeAdapter(EventDispatcherAdapterInterface adp) {
   	adapterList.remove(adp);
   	adapterLookupTable.remove(adp.getAdapterName());
   }

   /**
    * Starts the connection with the notification servers that the adapter
    * wrapps.
    */
   public void connect() {
      /*
      EventDispatcherInterface adapter;
      for (int i = 0; i < adapterList.size(); i++) {
			adapter = (EventDispatcherInterface) adapterList.get(i);
			adapter.connect();
		}
		*/
   }
   
   public void connect(String address) {
   	// This does nothing since this class is a wrapper for all the 
		// server-specific adapters, which are assumed to be already 
		// configured and connected to their respective notification servers.
		
   }

   /**
    *
    * @return the list of adapters that is being currently used.
    */
   public Vector getAdapterList() {
      return adapterList;
   }
   
	/*
	public void threadGuard() {
		while (numberOfThreads > THREAD_LIMIT) {
			try {
				Thread.sleep(THREAD_SLEEP_TIME);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}
	}
	*/


	/**
	 * Multithreaded publish implementation. We need to deliver events to more than
	 * one dispatcher here. If we do not use threads, the slower dispatcher will be the
	 * bottleneck of the whole system, making fast dispatchers inneficient. Hence, we
	 * add threads to have "parallel" publishing, preventing one dispathcher's delay
	 * to interfere with another one.
	 */
   public void publish(EventInterface evnt) throws DispatcherException {
   	
		EventDispatcherAdapterInterface adapter;
   	
   	for (int i = 0; i < adapterList.size(); i++) {	
			adapter = (EventDispatcherAdapterInterface) adapterList.get(i);
			adapter.publish(evnt);
 	   }
		
   }

   public void subscribe(SubscriptionInterface sub,
                         EventDispatcherListenerInterface li) throws
         DispatcherException {
		EventDispatcherAdapterInterface adapter;
		for (int i = 0; i < adapterList.size(); i++) {
			adapter = (EventDispatcherAdapterInterface) adapterList.get(i);
			adapter.subscribe(sub,li);
		}

   }

   public void unsubscribe(SubscriptionInterface sub,
                           EventDispatcherListenerInterface li) throws
         DispatcherException {
		EventDispatcherAdapterInterface adapter;
		for (int i = 0; i < adapterList.size(); i++) {
			adapter = (EventDispatcherAdapterInterface) adapterList.get(i);
			adapter.unsubscribe(sub,li);
		}

   }

   public void unsubscribe(EventDispatcherListenerInterface li) throws
         DispatcherException {
				EventDispatcherAdapterInterface adapter;
		for (int i = 0; i < adapterList.size(); i++) {
			adapter = (EventDispatcherAdapterInterface) adapterList.get(i);
			adapter.unsubscribe(li);
		}


   }

   public void suspendDispatcher(EventDispatcherListenerInterface li) throws
         DispatcherException {
		
		EventDispatcherAdapterInterface adapter;
		for (int i = 0; i < adapterList.size(); i++) {
			adapter = (EventDispatcherAdapterInterface) adapterList.get(i);
			adapter.suspendDispatcher(li);
		}

   }

   public void resumeDispatcher(EventDispatcherListenerInterface li) throws
         DispatcherException {
      
		EventDispatcherAdapterInterface adapter;
		for (int i = 0; i < adapterList.size(); i++) {
			adapter = (EventDispatcherAdapterInterface) adapterList.get(i);
			adapter.resumeDispatcher(li);
		}

   }

   public void shutdownDispatcher() throws DispatcherException {

		EventDispatcherAdapterInterface adapter;
		for (int i = 0; i < adapterList.size(); i++) {
			adapter = (EventDispatcherAdapterInterface) adapterList.get(i);
			adapter.shutdownDispatcher();
		}

   }

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#subscribe(java.lang.String, edu.uci.isr.yancees.SubscriptionInterface, edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface)
	 */
	public void subscribe(String adapterName, SubscriptionInterface sub, EventDispatcherListenerInterface li) throws DispatcherException {
		EventDispatcherAdapterInterface adapter;
		
		adapter = (EventDispatcherAdapterInterface) adapterLookupTable.get(adapterName);
		
		if (adapter != null)
			adapter.subscribe(sub,li);
		
		
	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#unsubscribe(java.lang.String, edu.uci.isr.yancees.SubscriptionInterface, edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface)
	 */
	public void unsubscribe(String adapterName, SubscriptionInterface sub, EventDispatcherListenerInterface li) throws DispatcherException {
		EventDispatcherAdapterInterface adapter;
		
		adapter = (EventDispatcherAdapterInterface) adapterLookupTable.get(adapterName);
		if (adapter != null) {
			adapter.unsubscribe(sub,li);
		}
		
	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#unsubscribe(java.lang.String, edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface)
	 */
	public void unsubscribe(String adapterName, EventDispatcherListenerInterface li) throws DispatcherException {
		EventDispatcherAdapterInterface adapter;
		
		adapter = (EventDispatcherAdapterInterface) adapterLookupTable.get(adapterName);
		if (adapter != null) {
			adapter.unsubscribe(li);
		}
		
	}

	

}