/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.server.dispatcher.elvin;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;

import org.elvin.je4.Consumer;
import org.elvin.je4.ElvinURL;
import org.elvin.je4.Notification;
import org.elvin.je4.NotificationListener;
import org.elvin.je4.Producer;
import org.elvin.je4.Subscription;

import edu.uci.isr.yancees.EventInterface;

import edu.uci.isr.yancees.YanceesEvent;
import edu.uci.isr.yancees.SubscriptionInterface;
import edu.uci.isr.yancees.core.ParsingException;
import edu.uci.isr.yancees.dispatcher.DispatcherException;
import edu.uci.isr.yancees.dispatcher.EventDispatcherAdapterInterface;
import edu.uci.isr.yancees.dispatcher.EventDispatcherListenerInterface;

/**
 * Implements the event dispatcher interface, bridging the communication between
 * the yancees core and the idiosincrasies of the target event notification used, 
 * in this case, Elvin.
 * 
 */
public class ElvinAdapter
      implements EventDispatcherAdapterInterface {

   private Consumer elvinConsumer; // reference to elvin consumer.
	private Producer elvinProducer; // reference to elvin producer.
   private ElvinURL elvinURL;
   private String elvinAddress;
   
   private final String DEFAULT_ELVIN_ADDRESS="elvin://localhost";
   
   private HashMap subscribersMap; // Associates subscribers to their SubscriberMediators

   private boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG;
	public final String ADAPTER_NAME = "ElvinAdapter";

   /**
    * Constructor
    *
    * @param sienaAddress is the address where siena is executing. It must follow
    * the siena syntax.
    */
   public ElvinAdapter(String address) {

      subscribersMap = new HashMap();
      connect(address);

   }

   public ElvinAdapter() {
      subscribersMap = new HashMap();
      // this constructor requires the call of connect method
   }

	public void connect() {
		if (elvinAddress == null) {
					elvinAddress = DEFAULT_ELVIN_ADDRESS;
					// default address used in this implementation
	
				}
				elvinURL = new ElvinURL(elvinAddress);
	
				try {
	
					if (print)
						System.out.print("ElvinAdapter: Connecting to Elvin...");
	
					elvinConsumer = new Consumer(elvinURL);
					elvinProducer = new Producer(elvinURL);
	
					if (print)
						System.out.println("[OK]");
	
				} catch (IOException ex) {
					if (print)
						System.out.println("[ERROR]");
	
					System.err.println("Elvin error:" + ex.toString());
	
				}
	}
	

	/**
	 * Connects to siena bafore any method can be used.
	 * this method is used by the architecture manager to initialize the dispatcher
	 * @param sienaAddress
	 */
	public void connect(String address) {
	
		elvinAddress = address;
		connect();	
	}

   protected void finalize() throws Throwable {
      elvinConsumer.getConnection().close();
      elvinProducer.getConnection().close();
      super.finalize();
   }

   /**
    * Publishes a Yancees event in the format of Elvin event. It also makes
    * the namespace transformation to differentiate body and header events.
    * Special attributes are added to identify yancees events from regular ones
    * that may be used in siena
    *
    *  @param evnt The event to publish.
    *  @see Event
    **/
   public void publish(EventInterface e) throws DispatcherException {
  
      Notification n = new org.elvin.je4.Notification(); // Elvin event to be composed

		// If the event provided is in the YanceesEvent wrapper, we can extract the
		// attributes for Elvin directly...
		
		if ( e instanceof YanceesEvent) {
			YanceesEvent yevt = (YanceesEvent) e;
			String attName;
			// Parses the body of the event
			for (Iterator i = yevt.getAttributeNamesIterator(); i.hasNext(); ) {
				  attName = (String) i.next();
				  n.put(attName, yevt.get(attName));
			}
				  
			
		// We do our own parsing here in case it is not the YanceesEvent format....
		} else {
			
				ElvinEvent evnt = new ElvinEvent(e);
		      String attName; // temporary name
		      AttValue value; // temporary value
		
		      //n.put("yancees.type", "Yancees 1.0"); // Marks the event as belonging to yancees
		
		      // Parses the body of the event
		      for (Iterator i = evnt.getAttributeNamesIterator(); i.hasNext(); ) {
		         attName = (String) i.next();
		         value = evnt.getAttribute(attName);
		
		         switch (value.getType()) {
		            case AttValue.STRING: // or BYTEARRAY are the same
		               n.put(attName,value.stringValue());
		               break;
		            case AttValue.LONG:
		               n.put(attName, value.longValue());
		               break;
		            case AttValue.BOOL:
		               n.put(attName, new Boolean(value.booleanValue()));
		               break;
		            case AttValue.DOUBLE:
		               n.put(attName, value.doubleValue());
		               break;
		
		         }
		      }
		} 


		// copy dates and id from e to n
		saveDateAndID(n, e);

      try {
         //System.out.print("ElvinAdapter: piblishing event...");
         if (print) {
            System.out.println("ElvinAdapter: publishing... \n" + n.printString());
            System.out.println("to address "+elvinURL);
            System.out.println();
         }
         elvinProducer.notify(n);
         if (print)
         	System.out.println(" [OK]");
      } catch (Exception ex) {
         System.out.println(" [ERROR]");
         throw new DispatcherException(
               "Error while sending event to Elvin! \n" +
               ex.toString());
      }

   }
   
   /**
    * A generic event has an id, a date it was created and a date it
    * arrived in the server. This meta-informatin needs to be embeded in the
    * siena event so it can be reconstructred when a new event is generated in 
    * the subscriber side. 
    * @param n is the Notification to receive the dates and Id from the event
    * @param evt is the event whose meta-info will be saved
    */
   private void saveDateAndID(Notification n, EventInterface evt) {
   	n.put(YanceesEvent.YANCEES_ID, evt.getId());
   	n.put(YanceesEvent.YANCEES_DATE_CREATED, evt.getDateCreated().getTime());
   	if (evt.getDateReceivedInServer() != null) {
   		n.put(YanceesEvent.YANCEES_DATE_RECEIVED, evt.getDateReceivedInServer().getTime());
   	} else {
   		n.put(YanceesEvent.YANCEES_DATE_RECEIVED, (new Date()).getTime());
   	}
		n.put(YanceesEvent.YANCEES_VERSION_TAG, YanceesEvent.YANCEES_VERSION);
   }
   
   /**
    * This method restores the meta-parameters that were embeded in the 
    * siena notification. This meta-data must not make part in the original event
    * but must be updated in the YanceesEvent in order for the dates and id to be
    * preserved.
    * @param n is the source, the place where the dates and id is stored
    * @param yevt is the target, the YanceesEvent to receive the meta-info.
    */
   private void restoreDateAndID(Notification n, YanceesEvent yevt) {
   	
   	/*
   	 * If yancess is used as a correlation library around a notification server
   	 * that is not yancees itself, these fields may not be present in the events. 
   	 */
   	
		if (n.containsKey(YanceesEvent.YANCEES_DATE_CREATED)) {
   		yevt.setDateCreated(new Date(n.getLong(YanceesEvent.YANCEES_DATE_CREATED)));
   		n.remove(YanceesEvent.YANCEES_DATE_CREATED);
		} else
		
		if (n.containsKey(YanceesEvent.YANCEES_DATE_RECEIVED)) {
			yevt.setDateReceivedInServer(new Date(n.getLong(YanceesEvent.YANCEES_DATE_RECEIVED)));
			n.remove(YanceesEvent.YANCEES_DATE_RECEIVED);
		}
		
		if (n.containsKey(YanceesEvent.YANCEES_ID)) {
			yevt.setID(n.getLong(YanceesEvent.YANCEES_ID));
			n.remove(YanceesEvent.YANCEES_ID);
		}
		
		if (n.containsKey(YanceesEvent.YANCEES_ID)) {
			n.remove(YanceesEvent.YANCEES_VERSION_TAG);
		}
		
   }

   /**
    *  subscribes for sequences of events matching subscription <b>p</b>.
    *
    *  <p>Notice that given the distributed nature of some
    *  implementations of Dispatcher interface, there exist race
    *  conditions that might affect the semantics of subscriptions.
    *  A subscriber might miss some notifications published before or
    *  while the subscription is processed by Dispatcher.
    *
    *  <p>Also, keep in mind that the current implementation of Dispatcher
    *  does not enforce any temporal order for the delivery of
    *  notifications.  This limitation might affect the recognition
    *  of patterns.  For example, two notifications <em>x</em> and
    *  <em>y</em>, generated at time <em>t<sub>x</sub></em> and
    *  <em>t<sub>y</sub></em> respectively, with
    *  <em>t<sub>x</sub></em> &lt; <em>t<sub>y</sub></em>, in that
    *  order matching a pattern <em>P=(f<sub>x</sub>
    *  f<sub>y</sub>)</em>, might in fact reach the subscriber at
    *  times <em>T<sub>x</sub></em> and <em>T<sub>y</sub></em>, with
    *  <em>T<sub>x</sub></em> &gt; <em>T<sub>y</sub></em>, in which
    *  case pattern <em>P</em> would not be matched.
    *
    *  @param li is the subscriber
    *  @param sub is a generic subscription containing a DOM tree. It is expected
    *  here that this subscription is in the format readable by the ElvinAdapter.
    *  @see #unsubscribe
    **/
   public void subscribe(SubscriptionInterface sub, EventDispatcherListenerInterface li) throws
         DispatcherException {

      SubscriberMediator med;
      ElvinSubscription elvinSub;

      if (sub == null) {
         throw new DispatcherException(
               "ElvinAdapter: Null subscrtiption reference provided");
      }

      try {
         elvinSub = new ElvinSubscription(sub.getDOM());
      } catch (ParsingException ex) {
         throw new DispatcherException(
               "ElvinAdapter: Error while parsing siena subscription");
      }

		// updates the subscriber mediator data base
      if (subscribersMap.containsKey(li)) {
         med = (SubscriberMediator) subscribersMap.get(li);
      } else {
         med = new SubscriberMediator(li);
         subscribersMap.put(li, med);
      }
      
      try {
         if (print) {
            System.out.println("Subscribing to event: " + elvinSub.toString());
         }
         Subscription mySub = elvinSub.getSubscription();
         mySub.addNotificationListener(med);
         elvinConsumer.addSubscription(mySub);
         med.incrementReferenceCounter();
         med.addSubscription(mySub);
      } catch (IOException ex) {
         throw new DispatcherException("Error while subscribing to Dispatcher" +
                                       ex.toString());
      }
   }

   /** cancels the subscriptions, posted by <b>li</b>, whose subscripton
    *  <b>sub'</b> is covered by subscripiton <b>p</b>.
    *
    *  <p>Unsubscriptions might incurr in the same kind of race
    *  conditions as subscriptions.  Dispatcher will stop sending
    *  notifications to the subscriber only after it has completed
    *  the processing of the unsubscription.  Due to the distributed
    *  nature of some implementations of Dispatcher, this might result in
    *  some additional ``unsolicited'' notifications.
    *
    *  @param li is the subscriber interface
    *  @see #subscribe
    **/
   public void unsubscribe(SubscriptionInterface sub, EventDispatcherListenerInterface li) throws
         DispatcherException {

      SubscriberMediator med;
      ElvinSubscription sienaSub = (ElvinSubscription) sub;

      if (subscribersMap.containsKey(li)) {
         
         try {
         elvinConsumer.removeSubscription(sienaSub.getSubscription());
         } catch (IOException ex) {
         	System.out.println("ElvinAdapter: error when unsubscribing");
         	System.out.println(ex);
         }
         
			med = (SubscriberMediator) subscribersMap.get(li);
         med.decrementReferenceCounter();
         if (med.getReferenceCounter() <= 0) {
            subscribersMap.remove(med);
         }
      }

   }

   /** cancels <i>all</i> the subscriptions posted by <b>n</b>.
    *
    *  @param li is the subscriber
    *  @see #subscribe
    **/
   public void unsubscribe(EventDispatcherListenerInterface li) throws
         DispatcherException {

      SubscriberMediator med = (SubscriberMediator) subscribersMap.get(li);
      if (med != null) {
         med.unsubscribeAll(); // first remove all the subscriptions associated to it
         subscribersMap.remove(li); // remove the mediator associated to this listener interface
      }

   }

   /** suspends the delivery of notifications to the given subscriber
    *  <code>li</code>.
    *
    *  @param li subscriber to be suspended
    **/
   public void suspendDispatcher(EventDispatcherListenerInterface li) throws
         DispatcherException {

      //TODO: Implement it for Elvin. It seems that there is no equivalent to that.

   }

   /** resumes the delivery of notifications to the given subscriber
    *  <code>n</code>.
    *
    *  @param li is the subscriber callback reference
    **/
   public void resumeDispatcher(EventDispatcherListenerInterface li) throws
         DispatcherException {

     //TODO: Implement that to Elvin. It seems that there is no equivalent to that.
   }

   /**
    *  closes this Dispatcher service access point.
    *
    *  This method releases any system resources associated with the
    *  access point.  In case this access point is connected to other
    *  Dispatcher servers, this method will properly disconnect it.
    **/
   public void shutdownDispatcher() throws DispatcherException {
      if (print)
      	System.out.println("ElvinAdapter: Shutting down Elvin...");
		
		Set mediatorsSet = subscribersMap.entrySet();
		for (Iterator iter = mediatorsSet.iterator(); iter.hasNext();) {
			SubscriberMediator element = (SubscriberMediator) iter.next();
			element.unsubscribeAll();
		}
      
		elvinProducer.getConnection().close();
		elvinConsumer.getConnection().close();

   }

   /**
    * This class represents a subscriber, receiving all the events from Elvin
    * that are destinated to this particular EventDispatcherListenerInterface
    *
    * It gets the events from siena, convets it to Events in Yancees and sends
    * to the corresponding EventDispatcherListenerInterface that it represents.
    */
   private class SubscriberMediator
         implements NotificationListener {

      private int referenceCounter;
      private EventDispatcherListenerInterface subsInt;
		private Vector mySubscriptions = new Vector();

      /**
       * Constructor
       * @param li is the subscriber this class represents
       */
      public SubscriberMediator(EventDispatcherListenerInterface li) {
         subsInt = li;
         referenceCounter = 0;
      }

      public void incrementReferenceCounter() {
         referenceCounter++;
      }

      public void decrementReferenceCounter() {
         referenceCounter--;
      }

      public int getReferenceCounter() {
         return referenceCounter;
      }
      
      /**
       * In order to implement unsubscribe() with elvin I need to know all the
       * subscriptions this NotificationListener is subscribed to.
       * @param sub is the subscription to be registered
       */
      public void addSubscription(Subscription sub) {
      	mySubscriptions.add(sub);
      }
      
      public void unsubscribeAll() {
      	for (int i = 0; i < mySubscriptions.size(); i++) {
				Subscription sub = (Subscription) mySubscriptions.get(i);
				try {
					elvinConsumer.removeSubscription(sub);
				} catch (IOException ex) {
					System.out.println("ElvinAdapter: Error when unsubscribing");
					System.out.println(ex);
				}
			}
      }
      

      /**
       * Used to receive events from elvin
       * It transforms elvin events to Yancees events and forwards the event
       * to the appropriate subscriber.
       * The events are sent to yancees having a prefix in their attributes. For
       * example: header/attributeName or body/attributeName. We have to process
       * them accordingly, eliminating the prefix.
       */
      public void notificationAction(Notification n) {
         //ElvinEvent se = new ElvinEvent();
			YanceesEvent result = new YanceesEvent();
         String name;
         Object value;
         
			restoreDateAndID(n, result);
         
         for (Iterator i = n.keySet().iterator(); i.hasNext(); ) {
            name = (String) i.next();
            value = n.get(name);
            
            if (value instanceof String)
            	result.put(name, value.toString());
				else if (value instanceof Long)
					result.put(name, Long.parseLong(value.toString()));
				else if (value instanceof Integer)
					result.put(name, Integer.parseInt(value.toString()));
				else if (value instanceof Boolean)
					result.put(name, Boolean.getBoolean(value.toString()));
				else if (value instanceof Double)
					result.put(name, Double.parseDouble(value.toString()));
				else if (value instanceof byte[])
					result.put(name, value.toString().getBytes());

         }
         
         /*
         GenericEvent result = null;
         try {
            result = new GenericEvent(se.getDOM());
         } catch (ParsingException ex) {
            System.out.println(
                  "Error when extracting resultt DOM tree from ElvinEvent");
            System.out.println(ex);
         }
         */

         subsInt.receiveDispatcherNotification(result);
      }


      protected void finalize() throws Throwable {
         unsubscribeAll();
         super.finalize();

      }

   }
	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.dispatcher.EventDispatcherInterface#getAdapterName()
	 */
	public String getAdapterName() {
		
		return ADAPTER_NAME;
	}

}