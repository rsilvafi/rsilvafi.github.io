/*
 * Copyright (c) 2003, Regents of the University of California.
 * All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 
/*
 * Created on Jan 27, 2004
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 * @version 1.0
 */
package edu.uci.isr.yancees.client;


import java.io.File;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.MessageInterface;
import edu.uci.isr.yancees.ProtocolFacade;
import edu.uci.isr.yancees.PublicationFacade;
import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.SubscriptionFacade;
import edu.uci.isr.yancees.YanceesException;
import edu.uci.isr.yancees.YanceesFacade;
import edu.uci.isr.yancees.YanceesInterface;
import edu.uci.isr.yancees.core.ParsingException;
import edu.uci.isr.yancees.plugin.ProtocolPluginInterface;

/**
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 *
 * This class works as a wrapper to YanceesRMI or other communication method
 * between client and server. It also permits the insertion of filters, plug-ins
 * and other interceptors between client and server.
 */
public class YanceesClient implements YanceesInterface {

	private YanceesFacade yancees;
	private SubscriptionFacade subscriberAPI;
	private PublicationFacade publisherAPI;
	private ProtocolFacade protocolAPI;


   /**
    * Initializes the client YANCEES stub according to the provided configuration
    * file.
    * 
    * @param configFile is a XML document having the configuration
    */
	public YanceesClient(File configFile) {
		super();
		yancees = YanceesFacade.getInstance();
		try {
			yancees.bootstrap(configFile);
		} catch (ParsingException ex) {
			System.out.println(ex);
		}

		subscriberAPI = yancees.getSubscriberAPI();
		publisherAPI = yancees.getPublisherAPI();
		protocolAPI = yancees.getProtocolAPI();

	}
	
	
	/**
	 * Prints the usage and quits with an error message
	 */
	private static void initError() {
		System.err.println(
			"Usage: java YanceesClient configuration.xml");
		System.exit(1);
	}

	// main class
	// initializes the program with a configuration file
	public static void main(String[] args) {
		YanceesClient implementation;
		File configFile;

		if (args.length != 1) {
			initError();
		}

		configFile = new File(args[0]);
		if (!configFile.exists()) {
			initError();
		}
		
		System.out.println("YanceesClient: creating local Yancees instance...");
		implementation = new YanceesClient(configFile);

	}
	
	//-------------------------------- Wrapping methods -------------------------
	// These methods only repass the calls to the corrspondent APIs.
	// Remember here that the API's, or fa�ades, are singletons.



	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.YanceesInterface#publish(edu.uci.isr.yancees.EventInterface)
	 */
	public void publish(EventInterface evt) throws YanceesException {
		publisherAPI.publish(evt);

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.YanceesInterface#subscribe(edu.uci.isr.yancees.MessageInterface, edu.uci.isr.yancees.SubscriberInterface)
	 */
	public void subscribe(MessageInterface msg, SubscriberInterface rsi)
		throws YanceesException {
		subscriberAPI.subscribe(msg, rsi);

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.YanceesInterface#unsubscribe(edu.uci.isr.yancees.SubscriberInterface)
	 */
	public void unsubscribe(SubscriberInterface rsi) throws YanceesException {
		subscriberAPI.unsubscribe(rsi);

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.YanceesInterface#unsubscribe(edu.uci.isr.yancees.SubscriberInterface, edu.uci.isr.yancees.MessageInterface)
	 */
	public void unsubscribe(SubscriberInterface rsi, MessageInterface sub)
		throws YanceesException {
		subscriberAPI.unsubscribe(rsi, sub);

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.YanceesInterface#shutdownYancees()
	 */
	public void shutdownYancees() throws YanceesException {
		/**@todo Implement this yancees.RemoteYanceesInterface method*/
		throw new java.lang.UnsupportedOperationException(
			"Method shutdownYancees() not yet implemented.");

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.YanceesInterface#suspendYancees()
	 */
	public void suspendYancees() throws YanceesException {
		/**@todo Implement this yancees.RemoteYanceesInterface method*/
		throw new java.lang.UnsupportedOperationException(
			"Method shutdownYancees() not yet implemented.");

	}

	/* (non-Javadoc)
	 * @see edu.uci.isr.yancees.YanceesInterface#resumeYancees()
	 */
	public void resumeYancees() throws YanceesException {
		/**@todo Implement this yancees.RemoteYanceesInterface method*/
		throw new java.lang.UnsupportedOperationException(
			"Method resumeYancees() not yet implemented.");

	}


   /* (non-Javadoc)
    * @see edu.uci.isr.yancees.YanceesInterface#connectToSharedProtocol(java.lang.String, edu.uci.isr.yancees.SubscriberInterface)
    */
   public ProtocolPluginInterface connectToSharedProtocol(String protocolId, SubscriberInterface si) throws YanceesException {
      return  protocolAPI.connectToSharedProtocol(protocolId, si);
      
   }


   /* (non-Javadoc)
    * @see edu.uci.isr.yancees.YanceesInterface#connectToNewProtocol(java.lang.String, edu.uci.isr.yancees.SubscriberInterface)
    */
   public ProtocolPluginInterface connectToNewProtocol(String protocolId, SubscriberInterface si) throws YanceesException {
      return  protocolAPI.connectToNewProtocol(protocolId, si);
   }


   /* (non-Javadoc)
    * @see edu.uci.isr.yancees.YanceesInterface#disconnectFromProtocol(java.lang.String, edu.uci.isr.yancees.SubscriberInterface)
    */
   public void disconnectFromProtocol(String protocolId, SubscriberInterface si) throws YanceesException {
      protocolAPI.disconnectFromProtocol(protocolId, si);
      
   }
}
