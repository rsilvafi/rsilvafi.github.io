/*
 * Copyright (c) 2003, Regents of the University of California. All rights
 * reserved.
 * 
 * =================================================================== 
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if any, must
 * include the following acknowledgment: "This product includes software
 * developed by the Institute for Software Research at University of California,
 * Irvine" Alternately, this acknowledgment may appear in the software itself,
 * if and wherever such third-party acknowledgments normally appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and "University of
 * California" must not be used to endorse or promote products derived from this
 * software without prior written permission. For written permission, please
 * contact rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called "YANCEES", nor may
 * "YANCEES" appear in their name, without prior written permission of the
 * University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * INSTITUTE FOR SOFTWARE RESEARCH AT THE UNIVERSITY OF CALIFORNIA, IRVINE, OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */

package edu.uci.isr.yancees.server.service.jmdns;

import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;


import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.YanceesException;
import edu.uci.isr.yancees.client.rmi.YanceesRMIClient;
import edu.uci.isr.yancees.server.plugin.protocol.peerpublish.RemotePeerPublishProtocolPluginInterface;
import edu.uci.isr.yancees.server.rmi.RemoteYanceesInterface;
import edu.uci.isr.yancees.server.service.AbstractService;
import edu.uci.isr.yancees.server.plugin.protocol.peerpublish.PeerPublishPluginFactory;

import java.util.Vector;

/**
 * This service connects YANCESS with its peers in a subnetwork. It uses the
 * service location protocol (SLP)
 */
public class JmDNSService extends AbstractService implements ServiceListener {

	// Named used by YANCEES plug-ins, internally, to use this service
	public static String SERVICE_NAME = "jmdns.service";

	// note that this name must be the same as the name used to register this
	// service in the arthcitecutre configuration file
	public static String LOOKUP_NAME = RemoteYanceesInterface.RMI_LOOKUP_NAME;

	public static String JMDNS_SERVICE_TYPE = "_rmi._tcp.local.";

	// We use our own unique name instead of this one here
	// public static String JMDNS_SERVICE_NAME = "yancees." +
	// JMDNS_SERVICE_TYPE;

	public static int TIME_OUT = 2000; // getServiceInfo timeout
	public static int RETRY_TIMEOUT = 5000; // for RMI reconnecting loopls
	public static int RETRY_TENTATIVES = 5; // number of times to retry before

	//public String _hostname = ""; // String with the IP address of this host
	public Vector _myURLList = new Vector(); // Is the string used to connect to the RMI
	public Vector _myJmDNSList = new Vector();

	// implementation of this service

	//private JmDNS _jmdns = null; // a reference to the JmDNS service

	private boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG;

	// private boolean print = true;

	private HashMap _knownPeers = new HashMap(); // keeps a list of known
													// peers according to the
													// JmDNS listenter interface
													// calls

	private HashMap _peerProtocolConnections = new HashMap(); // stores the
																// live
																// connections
																// to the
																// protocol
																// plug-in of
																// the peers

	private SubscriberInterface _mySubscriberInterface = (SubscriberInterface) new MySubscriber();
	private ServiceInfo _info; // information published through JmDNS about
								// this service

	public JmDNSService() {
		super();

		Enumeration interfaces = null;
		try {
			interfaces = NetworkInterface.getNetworkInterfaces();
		} catch (SocketException e) {
			e.printStackTrace();
		}

		while (interfaces != null && interfaces.hasMoreElements()) {
			NetworkInterface inter = (NetworkInterface) interfaces
					.nextElement();
			Enumeration addresses = inter.getInetAddresses();

			InetAddress address = null;
			while (addresses.hasMoreElements()) {
				address = (InetAddress) addresses.nextElement();

				// a site local address is that using a LAN IP address such
				// as 192.168.0.x, as opposed to a WAN real IP addresss
				
				if (! (address.isLoopbackAddress() ||
						address.isLinkLocalAddress() ||
						/* address.isSiteLocalAddress() || */
						address.isMCOrgLocal() ||
						address.isMCSiteLocal() ||
						(address instanceof java.net.Inet6Address) )
					) {

					/*
					 * try { // gets the local host name // _hostname =
					 * java.net.InetAddress.getLocalHost().getHostName();
					 *  // gets the local IP address instead _hostname =
					 * java.net.InetAddress.getLocalHost().getHostAddress();
					 * 
					 *  } catch (UnknownHostException e) { System.out
					 * .println("JmDNSService: ERROR. could not determine local
					 * host address."); e.printStackTrace(); }
					 */

					JmDNS myJmDNS = null;
					try {
						// reference to the JmDNS runtime, which implements the
						// JmDNS protocol for the provided interface address...
						myJmDNS = new JmDNS(address);
					} catch (IOException e1) {
						System.out
								.println("JmDNSService: ERROR when initializing JmDNS for address: "+address);
						e1.printStackTrace();
					}
					
					registerItselfAsJMDNSListener(myJmDNS);
					
					// composes the name that this service will be known in the
					// JmDNS service for that specific address.
					String hostname = address.getHostAddress();
					String myURL = "//" + hostname + "/" + LOOKUP_NAME;
					_myURLList.add(myURL);

					System.out
							.println("JmDNSService: Registering local copy using URL: "
									+ myURL);

					advertiseThisYanceesInstance(myURL, myJmDNS);
				}
			}
		}

	}	

// ---------------------- BEGIN JMDNS Service Listeners  -------------------

	/*
	 * This method is called whenever a new service is registered in the P2P LAN
	 */
	public void addService(JmDNS jmdns, String type, String name) {
		// performs the command as a separate thread, improving the parallelism.
		System.out.println("JmDNSService: Got JmDNS SERVICE ADD event for : "
				+ name);
		if (type.equals(JMDNS_SERVICE_TYPE)) {
			executeAddService(jmdns, type, name);
		}
	}

	/**
	 * This method provides a multithreaded implementation of thee addService
	 * API call from the JmDNS service
	 * 
	 * @param jmdns
	 * @param type
	 * @param name
	 */
	private void executeAddService(final JmDNS jmdns, final String type,
			final String name) {

		Thread t = new Thread() {
			public void run() {

				// here we get the ServiceInfo which has the RMI address of
				// yancees in the peer
				ServiceInfo info = jmdns.getServiceInfo(type, name, TIME_OUT);

				if (print) {
					System.out.println("JmDNS Service detected ADD: " + info);
					// System.out.println("JmDNS text: "+info.getTextString());
				}

				// if the service which was added is not myself...
				if (info != null && isNotMyURL(info.getTextString()) ) {
					System.out.println("JmDNS Service ADDING "
							+ info.getTextString()
							+ " to the list of known peers");

					// add the received name to the list of known peers
					// we use the JmDNS unique name as key
					synchronized (_knownPeers) {
						_knownPeers.put(name, info);
					}

					YanceesRMIClient yancees = null;

					// It may be the case that the jmDNS service initialized but
					// YANCEES
					// did not finish booting up, so we try 5 times with 2
					// seconds
					// interval
					// before giving up connecting to the new YANCEES peer.
					boolean succeeded = false;
					int tentative = 0;
					while (!succeeded && tentative < RETRY_TENTATIVES) {
						try {
							if (print)
								System.out
										.println("JmDNSService: connecting to yancees at "
												+ info.getTextString());
							yancees = new YanceesRMIClient(info.getTextString());
							succeeded = true;
							if (print) {
								System.out
										.println("JmDNSService: successfully added "
												+ info.getTextString());
							}
						} catch (YanceesException ex) {
							tentative++;
							succeeded = false;
							try {
								if (print)
									System.out
											.println("JmDNSService: Trying again... Waiting for peer to start up...");
								Thread.sleep(RETRY_TIMEOUT);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}

							if (tentative >= RETRY_TENTATIVES)
								System.out.println(ex);
						}
					}

					RemotePeerPublishProtocolPluginInterface peerPublishPluginReference = null;
					if (succeeded) {
						boolean connected = false;
						int mytry = 0;
						while (!connected && mytry < RETRY_TENTATIVES) {
							try {

								if (mytry > 0)
									System.out
											.println("JmDNSService: retrying a connection to the protocol plug-in at "
													+ info.getTextString()
													+ "...");

								if (print)
									System.out
											.println("JmDNSService: Trying to connect to PeerPublishProtocol...");
								peerPublishPluginReference = (RemotePeerPublishProtocolPluginInterface) yancees
										.connectToSharedProtocol(
												PeerPublishPluginFactory.PROTOCOL_NAME,
												_mySubscriberInterface);
								connected = true;
								if (print)
									System.out
											.println("JmDNSService: Connected to PeerPublishProtocol at "
													+ info.getTextString()
													+ "...");
								// keeps the connection alive so it can publish
								// events in the
								// future.
								synchronized (_peerProtocolConnections) {
									if (print)
										System.out
												.print("JmDNSService: registering new connection...");
									_peerProtocolConnections.put(name,
											peerPublishPluginReference);
									if (print)
										System.out.println(" [OK]");
								}
							} catch (YanceesException e2) {
								mytry++;
								connected = false;

								System.out.println(" [ERROR] ");

								if (mytry == 1) {
									System.out
											.println("JmDNSService: error when connecting to new protocol...");
									System.out
											.println("JmDNSService: this may have been caused by a firewall");
									System.out
											.println("JmDNSService: Try opening the RMI 1099 and HTTP 9876 ports in the host you are trying to connect to");
								}

								try {
									System.out
											.println("JmDNSService: sleeping before retrying...");
									Thread.sleep(RETRY_TIMEOUT);
								} catch (InterruptedException e) {
									System.out.println(e);
								}
								// e2.printStackTrace();
							}
						}

					}
				}

			}

			

		};
		t.start();

	}
	
	protected boolean isNotMyURL(String textString) {
		for (Iterator iter = _myURLList.iterator(); iter.hasNext();) {
			String element = (String) iter.next();
			if (textString.equals(element))
				return false;
		}
		
		return true;
	}

	/**
	 * This method is called whenever a new service is unregistered from the LAN
	 * 
	 * @param jmdns
	 *            is the reference to the service running locally
	 * @param type
	 *            is the type of the service removed
	 * @param name
	 *            is the name of the resource removed
	 */
	public void removeService(JmDNS jmdns, String type, String name) {
		System.out
				.println("JmDNSService: Got JmDNS SERVICE REMOVED event for : "
						+ name);
		if (type.equals(JMDNS_SERVICE_TYPE)) {
			executeRemoveService(jmdns, type, name);
		}
	}

	/**
	 * Starts a thread to execute the remove command
	 * 
	 * @param jmdns
	 *            is the reference to the jmdns protocol manager
	 * @param type
	 *            is the type of the service that left the network
	 * @param name
	 *            is the unique name of the service that left the network
	 */
	public void executeRemoveService(final JmDNS jmdns, final String type,
			final String name) {
		Thread t = new Thread() {

			public void run() {
				if (print)
					System.out.println("JmDNSService: JmDNS Service REMOVED: "
							+ name);

				synchronized (_knownPeers) {
					System.out
							.println("JmDNSService: Removing "
									+ name
									+ " from known peers in response to JmDNS remove event");
					_knownPeers.remove(name);
				}

				synchronized (_peerProtocolConnections) {
					_peerProtocolConnections.remove(name);
				}

			}
		};
		t.start();
	}

	/*
	 * called whenever a service is resolved using mDNS protocol
	 */
	public void resolveService(JmDNS jmdns, String type, String name,
			ServiceInfo info) {

		if (print)
			System.out.println("JmDNS Service RESOLVED: " + info);

	}

	// ---------------------- END JMDNS Service Listeners ----------------------

	/**
	 * Register this class as a JmDNS listener.
	 */
	private void registerItselfAsJMDNSListener(JmDNS jmdns) {
		jmdns.registerServiceType(JMDNS_SERVICE_TYPE);
		jmdns.addServiceListener(JMDNS_SERVICE_TYPE, this);
	}

	/**
	 * publish this url to the JmDNS service using a unique name
	 * 
	 */
	private void advertiseThisYanceesInstance(String myURL, JmDNS jmdns) {

		if (print) {
			System.out.println("JmDNSService: registering myself as " + myURL
					+ " with JmDNS...");
		}

		try {
			/*
			 * We register the service using the field _myURL as a text
			 * associated to it. This text will be used to bind to the RMI
			 * implementation of the YANCEES server.
			 */

			// I am now using _myURL as the service name. It must be
			// concatenated
			// with the type in order to be acceptible by the mDNS protocol
			String serviceName = myURL + "." + JMDNS_SERVICE_TYPE;

			// pack a info PDU
			_info = new ServiceInfo(JMDNS_SERVICE_TYPE, serviceName, -1, 0, 0,
					myURL);

			// invoke the registration method
			jmdns.registerService(_info);

		} catch (IOException e) {
			System.out
					.println("JmDNSService: error when registering local yancees with JmDNS.");
			e.printStackTrace();
		}
	}

	/**
	 * Locates and display a list of other YANCEES instances in the neighborhod
	 * through JmDNS
	 * 
	 */
	/*
	 * public void printAllRegisteredServices() {
	 * System.out.println(_jmdns.getServiceInfo(JMDNS_SERVICE_TYPE,
	 * JMDNS_SERVICE_NAME)); }
	 */

	private void printKnownPeers() {

		HashMap myKnownPeers;
		synchronized (_knownPeers) {
			myKnownPeers = (HashMap) _knownPeers.clone();
		}
		System.out.println("\nJmDNSService: Known Yancees Peers:");
		for (Iterator iter = myKnownPeers.keySet().iterator(); iter.hasNext();) {
			String key = (String) iter.next();
			System.out.println(key);
		}

	}

	private void printKnownConnectedPeers() {
		// we make a copy of the current protocol connections to prevent
		// concurrent problems.

		HashMap myPeerProtocolConnections;
		synchronized (_peerProtocolConnections) {
			myPeerProtocolConnections = ((HashMap) _peerProtocolConnections
					.clone());
		}
		// we iterate over the copy we just created
		System.out.println("\nJmDNSService: Known Connected Peers:");
		for (Iterator iter = myPeerProtocolConnections.keySet().iterator(); iter
				.hasNext();) {
			String key = (String) iter.next();
			System.out.println(key);
		}

	}

	/**
	 * Propagates, or publishes an event in all the peers of the network. Note
	 * that for this operation, we do not use the regular publishing interface
	 * of YANCEES as a way to prevent repeated circular publishing of events.
	 * 
	 * @param evt
	 *            is the event to be propagated to the other peers.
	 */
	public void publishToPeers(final EventInterface evt) {

		Thread t = new Thread() {
			public void run() {
				// System.out.println("JmDNSService: will start publishing to
				// peers...");

				if (print) {
					System.out
							.println("JmDNSService: publishing to the known connected peers (excluding me):");
					printKnownConnectedPeers();
					// System.out.println("JmDNSService: YANCEES Known peers:");
					// printKnownPeers();
				}

				HashMap myPeerProtocolConnections = null;
				// we make a copy of the hashmap to avoid concurrency problems.
				synchronized (_peerProtocolConnections) {
					myPeerProtocolConnections = (HashMap) _peerProtocolConnections
							.clone();
				}

				for (Iterator iter = myPeerProtocolConnections.keySet()
						.iterator(); iter.hasNext();) {
					String key = (String) iter.next();
					RemotePeerPublishProtocolPluginInterface peer;

					peer = (RemotePeerPublishProtocolPluginInterface) myPeerProtocolConnections
							.get(key);

					if (peer != null) {
						try {
							if (print) {
								System.out
										.println("JMDNSService: publishing event to peer: "
												+ key);
								// System.out.println(evt.toString());

							}
							peer.publishEventFromPeer(evt);
						} catch (RemoteException e) {
							// peer is not alive anymore.
							if (print)
								System.out
										.println("JMDNSService: ERROR when publishing to peer: "
												+ key);
							System.out
									.println("JmDNSService: Removing "
											+ key
											+ " from known peers, because I could not send event:");
							System.out.println(evt);
							System.out.println("Exception: " + e);

							removePeerProtocolConnection(key);
							if (print)
								System.out
										.println("JmDNSService: Could not connect to peer: "
												+ key + ", unregistering it.");
							// e.printStackTrace();
						}
					} else {
						if (print)
							System.out
									.println("JMDNSService: null peer found, not publishing...");
					}
				}

			};

		};
		t.start();

	}

	private void removePeerProtocolConnection(String key) {
		synchronized (_peerProtocolConnections) {
			_peerProtocolConnections.remove(key);
		}
	}

	/**
	 * Propagates, or publishes an event in all the peers of the network. Note
	 * that for this operation, we do not use the regular publishing interface
	 * of YANCEES as a way to prevent repeated circular publishing of events.
	 * 
	 * @param evtList
	 *            is the event list to be propagated to the other peers.
	 */
	public void publishToPeers(final EventInterface[] evtList) {

		Thread t = new Thread() {
			public void run() {
				// System.out.println("JmDNSService: will start publishing to
				// peers...");

				if (print) {
					System.out
							.println("JmDNSService: publishing to the known connected peers (excluding me):");
					printKnownConnectedPeers();
					// System.out.println("JmDNSService: YANCEES Known peers:");
					// printKnownPeers();
				}

				HashMap myPeerProtocolConnections = null;
				// we make a copy of the hashmap to avoid concurrency problems.
				synchronized (_peerProtocolConnections) {
					myPeerProtocolConnections = (HashMap) _peerProtocolConnections
							.clone();
				}

				for (Iterator iter = myPeerProtocolConnections.keySet()
						.iterator(); iter.hasNext();) {
					String key = (String) iter.next();
					RemotePeerPublishProtocolPluginInterface peer;

					peer = (RemotePeerPublishProtocolPluginInterface) myPeerProtocolConnections
							.get(key);

					if (peer != null) {
						try {
							if (print) {
								System.out
										.println("JMDNSService: publishing event list to peer: "
												+ key);
							}
							peer.publishEventsFromPeer(evtList);
						} catch (RemoteException e) {
							// peer is not alive anymore.
							// System.out.println("JmDNSService: ERROR when
							// publishing to peer: "+key);

							System.out
									.println("JmDNSService: Removing "
											+ key
											+ " from known peers, because I could not send event:");
							System.out.println(evtList);
							System.out.println("Exception: " + e);

							removePeerProtocolConnection(key);
							System.out
									.println("JmDNSService: Could not connect to peer: "
											+ key + ", unregistering it.");
							// e.printStackTrace();
						}
					} else {
						if (print)
							System.out
									.println("JMDNSService: null peer found, not publishing...");
					}
				}
			}

		};
		t.start();
	}

	/**
	 * This is a dummy class to uniquely identify the subscriber in this case.
	 * For this protocol plug-in specifically, it has no application.
	 * 
	 * This interface allows other plug-ins to subscribe to events generated by
	 * this service.
	 * 
	 * @author rsilvafi class created at Jun 15, 2004
	 * 
	 */
	public class MySubscriber implements SubscriberInterface {

		/*
		 * (non-Javadoc)
		 * 
		 * @see edu.uci.isr.yancees.SubscriberInterface#notify(edu.uci.isr.yancees.EventInterface)
		 */
		public void notify(EventInterface evt) {
			// TODO Auto-generated method stub

		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see edu.uci.isr.yancees.SubscriberInterface#notify(edu.uci.isr.yancees.EventInterface[])
		 */
		public void notify(EventInterface[] evtList) {
			// TODO Auto-generated method stub

		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.jmdns.ServiceListener#serviceAdded(javax.jmdns.ServiceEvent)
	 */

}