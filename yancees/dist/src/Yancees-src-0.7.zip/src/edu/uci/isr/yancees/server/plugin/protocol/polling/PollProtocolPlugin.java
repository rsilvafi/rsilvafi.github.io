/*
 * Copyright (c) 2003, Regents of the University of California. All rights
 * reserved.
 * 
 * =================================================================== The
 * Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if any, must
 * include the following acknowledgment: "This product includes software
 * developed by the Institute for Software Research at University of California,
 * Irvine" Alternately, this acknowledgment may appear in the software itself,
 * if and wherever such third-party acknowledgments normally appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and "University of
 * California" must not be used to endorse or promote products derived from this
 * software without prior written permission. For written permission, please
 * contact rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called "YANCEES", nor may
 * "YANCEES" appear in their name, without prior written permission of the
 * University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * INSTITUTE FOR SOFTWARE RESEARCH AT THE UNIVERSITY OF CALIFORNIA, IRVINE, OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */

package edu.uci.isr.yancees.server.plugin.protocol.polling;

import java.rmi.RemoteException;
import java.util.Vector;

import edu.uci.isr.yancees.ArchitectureManager;
import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.GenericEvent;
import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.core.ActivePluginInstancesRegistry;
import edu.uci.isr.yancees.plugin.MOPluginInterface;
import edu.uci.isr.yancees.server.plugin.notification.pull.PullPlugin;
import edu.uci.isr.yancees.server.rmi.RemoteAbstractProtocolPluginImplementation;


/**
 * @author rsilvafi class created at May 3, 2004
 *  
 */
public class PollProtocolPlugin extends
      RemoteAbstractProtocolPluginImplementation {

   private boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG;
   private PollingMechanism pollingEngine;

   /**
    * @throws RemoteException
    */
   public PollProtocolPlugin(SubscriberInterface si) throws RemoteException {
      super(si);

      if (print) {
         System.out.println("PollProtocolPlugin: new instance...");
      }
      pollingEngine = new PollingMechanism(subscriber);

   }

   public void pollEvents() throws RemoteException {
      EventInterface[] events = pollingEngine.collectPullEvents();
      this.notifySybscriber(events);
   }

   public void startPeriodicPolling(int period) throws RemoteException {
      pollingEngine.setPollInterval(period);
      pollingEngine.start();
   }

   public void stopPolling() throws RemoteException {
      pollingEngine.pausePolling();
   }

   public void resumePolling() throws RemoteException {
      pollingEngine.resumePolling();
   }
   
   

   /**
    * 
    * Implements a thread that periodically polls all the pull plug-ins under
    * the provides subscriber interface and publishes the output of this plug-in
    * using the events stored in the pull plug-ins.
    */
   protected class PollingMechanism extends Thread {

      /*
       * Subscriber here is assumed to be a mediator. It makes the conversion
       * between the local SubscriberInterface and the remote one. Hence, we
       * handle it locally, allowing the protocol plug-in, for example, to
       * handle local invocations.
       */
      private SubscriberInterface subscriber = null;

      private int pollInterval = 1000; //default value
      private boolean paused = false;
      private boolean terminated = false;
      private String PULL_TAG = PullPlugin.PULL_TAG;

      // constructor
      public PollingMechanism(SubscriberInterface rsi, int interval) {
         pollInterval = interval;
         subscriber = rsi;

      }

      // constructor that uses the default poll interval
      public PollingMechanism(SubscriberInterface rsi) {
         subscriber = rsi;
      }

      /**
       * Infinite loop that collects the events for the current subscriber,
       * periodically, according to the pollInterval. It publishes the output
       * using the appropriate plug-in method.
       */
      public void run() {
         if (print) System.out.println("PollingMechanism: starting main loop");

         while (!terminated) {

            try {
               if (print)
                     System.out.println("PollingMechanism: sleeping for "
                           + pollInterval + "s");
               Thread.sleep(pollInterval);
            } catch (InterruptedException ex) {
               System.out.println("PollProtocolPlugin: error when sleeping...");
               System.out.println(ex);
            }

            if (!paused) {
               GenericEvent[] events = collectPullEvents();
               subscriber.notify(events);

            }
         }

      }

      /**
       * Colelcts all the evens stored in pull plug-ins for the current
       * subscriber
       * 
       * @return the list of events stored in the server (pull notificatoin
       *         plug-ins) for the current subscriber.
       */
      public synchronized GenericEvent[] collectPullEvents() {
         GenericEvent[] output;
         Vector outputList = new Vector(0);

         if (print)
               System.out
                     .println("PollingMechanism: Collecting pull events...");

         ActivePluginInstancesRegistry treesDB = ArchitectureManager
               .getInstance().getActiveSubscriptionTreesDB();

         if (print)
               System.out
                     .println("PollingMechanism: querying active trees DB...");

         MOPluginInterface[] pullNotificationInstances = treesDB
               .getActivePlugins(subscriber, PULL_TAG);

         PullPlugin pullPlugin;

         if (print)
               System.out.println("PollingMechanism: Found "
                     + pullNotificationInstances.length
                     + " pull plug-ins for this subscriber...");

         for (int i = 0; i < pullNotificationInstances.length; i++) {
            pullPlugin = (PullPlugin) pullNotificationInstances[i];
            outputList.addAll(pullPlugin.poll()); // collect the events
         }

         output = new GenericEvent[outputList.size()];
         outputList.copyInto(output);

         if (print)
               System.out.println("PollingMechanism: Collected "
                     + output.length + " events");

         return output;
      }

      public void pausePolling() {
         paused = true;
      }

      public void resumePolling() {
         paused = false;
      }

      public void setPollInterval(int interval) {
         pollInterval = interval;
      }

      public void terminate() {
         terminated = true;
      }

   } // PollingMechanism

}