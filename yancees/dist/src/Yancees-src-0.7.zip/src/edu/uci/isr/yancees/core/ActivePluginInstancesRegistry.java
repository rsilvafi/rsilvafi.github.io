/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.core;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.util.HashMap;
import java.util.Vector;

import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.plugin.MOPluginInterface;

/**
 *
 * This class represents a global record of parsed subscription and notification
 * trees. it is used by the protocol plug-ins as a blackboard, to collect infromation
 * about these trees and perform necessary interaction with active plug-ins.
 *
 * This is kept updated by the SubscriberAPI.
 */
public class ActivePluginInstancesRegistry {

   private HashMap subscriberPluginMap; // maps subscriberInterfaces to a Vector of plugin instances (trees)

   private boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG;

   // single instance of this class
    static ActivePluginInstancesRegistry myInstance;

    // can only be accessed by the YancessAPI or anyone else inside yancess package
    static public ActivePluginInstancesRegistry getInstance() {
       if (myInstance == null) {
          myInstance = new ActivePluginInstancesRegistry();
       }
       return myInstance;
    }

   // prevents direct instantiaion of this singleton
   private ActivePluginInstancesRegistry() {
      subscriberPluginMap = new HashMap();
   }

   /**
    * Associates the plug-in tree headded by <b>pi</b> under <b>si</b>
    * @param pi is the HEAD plugin interface of the parsed tree 
    * @param si is the subscriber that originated the creation of the plug-in
    * evaluation tree headed by pi
    */
   public void registerPluginTree(MOPluginInterface pi, SubscriberInterface si) {

      if (print)
         System.out.println("ActivePluginInstancesRegistry: adding new tree under "+si);
      Vector treeList = (Vector) subscriberPluginMap.get(si);
      if (treeList == null) {
         // there is no si record yet, create it
         treeList = new Vector();
         subscriberPluginMap.put(si, treeList);
      }

      // update the si record with the new pi
      treeList.add(pi);

   }

   /**
    * removes the reference to <b>pi</b> from the record of <b>si</b>
    * @param pi is the HEAD of the plug-in evaluation tree to be removed from the si record.
    * @param si is the record to be updated.
    */
   public void unregisterPluginTree(MOPluginInterface pi, SubscriberInterface si) {

      Vector treeList = (Vector) subscriberPluginMap.get(si);
      if (treeList != null) {
         treeList.remove(pi);
       	//System.gc();
       	//System.runFinalization();
      } else {
         // the record does not exist, nothing to be removed.
      }
   }

   /**
    * Removes all the records for a provides subscriber
    * @param si is the record locator for a sunscriber, which is its subscriber interface
    */
   public void uregisterSubscriber(SubscriberInterface si) {
		Vector treeList = (Vector) subscriberPluginMap.get(si);
		MOPluginInterface plugin;
		for (int i = 0; i < treeList.size(); i++) {
			plugin = (MOPluginInterface) treeList.get(i);
			plugin.dispose();
		}
      
      subscriberPluginMap.remove(si);
   }

   /**
    * @param si is the subscriber interface which active plug-ins are returned
    * @return a list of PluginInterface instances for the proviced subscriber or
    * an empty list if not found.
    */
   public MOPluginInterface[] getActiveTrees(SubscriberInterface si) {

      if (print)
         System.out.println("ActivePluginInstancesRegistry: querying for subscription trees under "+si);

      MOPluginInterface[] answer = new MOPluginInterface[0];
      Vector plugins = (Vector) subscriberPluginMap.get(si);

      if (plugins != null && plugins.size() > 0) {
         answer = new MOPluginInterface[plugins.size()];
         plugins.copyInto(answer);
      }

      return answer;
   }

   /**
    *
    * @param si is the subscriber interface that originated the creation of this tree
    * @param tag is the XML tag which the HEAD plug-in was creted to evaluate.
    * @return a list of head plug-ins or an empty list if not found.
    */
   public MOPluginInterface[] getActiveTrees(SubscriberInterface si, String tag) {

      if (print) {
         System.out.println(
               "ActivePluginInstancesRegistry: querying for subscription trees under " +
               si);
         System.out.println(
               "ActivePluginInstancesRegistry: looking for tag: " +tag);

      }

      Vector answerList = new Vector();

      MOPluginInterface[] answer = new MOPluginInterface[0];
      Vector plugins = (Vector) subscriberPluginMap.get(si);

      if (plugins != null) {
         MOPluginInterface tempPlugin;

         if (print) {
            System.out.println("ActivePluginInstancesRegistry: foud " +
                               plugins.size() + " trees matching subscriber");
            System.out.println("ActivePluginInstancesRegistry: looking for the tag: "+tag);
         }

         for (int i = 0; i < plugins.size(); i++) {
            tempPlugin = (MOPluginInterface) plugins.elementAt(i);

            if (print)
               System.out.println("Comparing tag: "+tempPlugin.getTag()+" with: "+tag);

            if (tempPlugin.getTag().equals(tag) || tempPlugin.getTag().endsWith(":"+tag) ) {
               answerList.add(tempPlugin);
            }
         }

         if (answerList.size() > 0) {
            answer = new MOPluginInterface[answerList.size()];
            answerList.copyInto(answer);
         }
      }

      return answer;

   }

   /**
    *
    * @param si is the subscriber interface that originated the creation of this plug-in
    * in a given tree. All the active trees for this subscriber are searched and the
    * plug-ins matching the tag are returned.
    * @param tag is the XML tag of the plug-in to look for
    * @return a list of plug-ins or an empty list if not found.
    */
   public MOPluginInterface[] getActivePlugins(SubscriberInterface si, String tag) {

      if (print) {
         System.out.println(
               "ActivePluginInstancesRegistry: querying for subscription trees under " +
               si);
         System.out.println(
               "ActivePluginInstancesRegistry: looking for tag: " +tag);

      }

      Vector answerList = new Vector();

      MOPluginInterface[] answer = new MOPluginInterface[0];
      Vector pluginTrees = (Vector) subscriberPluginMap.get(si);

      if (pluginTrees != null) {
         MOPluginInterface currentTree;

         if (print) {
            System.out.println("ActivePluginInstancesRegistry: foud " +
                               pluginTrees.size() + " trees matching subscriber");
            System.out.println("ActivePluginInstancesRegistry: looking for the tag: "+tag+" inside these trees");
         }

         for (int i = 0; i < pluginTrees.size(); i++) {
            currentTree = (MOPluginInterface) pluginTrees.elementAt(i);

            if (print)
               System.out.println("ActivePluginInstancesRegistry: Searching: "+tag+" on tree headed by: "+currentTree.getTag());

            answerList = searchPluginInTree(currentTree,tag);
         }

         if (answerList.size() > 0) {
            answer = new MOPluginInterface[answerList.size()];
            answerList.copyInto(answer);
         }
      }

      return answer;

   }

   /**
    * Searches for the plug-ins responding for the the provided tag in the subtre
    * @param tree is the plug-in evaluation tree to be searches
    * @param tag is the tag to be looked for in the plug-ins of this tree
    * @return a list of plug-ins which tag is equal to the one provided.
    */
   private Vector searchPluginInTree(MOPluginInterface tree, String tag) {
      Vector answer = new Vector(0);

      if (tree.getTag().equals(tag))
         answer.add(tree);

      if (tree.hasChildren()) {
         MOPluginInterface[] required = tree.getRequiredPluginsList();
         for (int i = 0; i < required.length; i++) {
            answer.addAll(searchPluginInTree(required[i], tag));
         }
      }

      return answer;
   }


}