/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 /*
 * Created on Sep 1, 2003
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */
package edu.uci.isr.yancees.filter;

import edu.uci.isr.yancees.EventInterface;

/**
 * @author rsilvafi
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface FilterManagerInterface {

	/**
	 * 
	 * @param name is the unique name of the filter
	 * @return the filter registered under the unique name
	 */
	public FilterInterface getFilterByName(String name);

	/**
	 * 
	 * @return the list of all the filters, in the order they are installed
	 */
	public FilterInterface[] getFilters();

	/**
	  * Add a filter to the end of a list and register it under a name
	  * @param filter is the filter to be inserted after all current filters
	  * @param name is the name of the filter
	  */
	public void addFilter(FilterInterface filter);

	/**
  	 * @param i is the position of the filter to be returned
	 * @return the filter at the provided position
	 */
	public FilterInterface getFilterAt(int i);

	/**
	 * Insters a filter in the provided position in the filters stream
	 * @param filter is the filter to be inserted
	 * @param i is the position to insert the filter
	 */
	public void insertFilterAt(FilterInterface filter, int i);

	/**
	 * Remove the element at provided position from filters streams
	 * @param i is the position of the filter to be removed
	 */
	public void removeFilterAt(int i);
	
	/**
	 * Handles the event passing it through the chain of responsibility
	 * formed by the filters managed by this object.
	 * @param msg is the message to be routed through the filters
	 * @return the event generated throught the filtering process
	 */
	public EventInterface[] filterEvent(EventInterface evt);
	
	/**
		 * Handles the event list passing them through the chain of responsibility
		 * formed by the filters managed by this object.
		 * @param msg is the message to be routed through the filters
		 * @return the event generated throught the filtering process
		 */
	public  EventInterface[] filterEventList(EventInterface[] evt);
}
