/*
 * Copyright (c) 2003, Regents of the University of California.
 * All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE INSTITUTE FOR SOFTWARE RESEARCH AT THE UNIVERSITY
 * OF CALIFORNIA, IRVINE, OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */

package edu.uci.isr.yancees.server.filter.peerpublisher;

import java.util.Vector;

import edu.uci.isr.yancees.ArchitectureManager;
import edu.uci.isr.yancees.AttributeNotFoundException;
import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.WrongAttributeTypeException;
import edu.uci.isr.yancees.YanceesEvent;
import edu.uci.isr.yancees.core.ParsingException;
import edu.uci.isr.yancees.filter.AbstractFilter;
import edu.uci.isr.yancees.server.service.jmdns.JmDNSService;

/**
 * @author rsilvafi
 * 
 * this filter redirects all events published using this YANCEEs instance, to
 * all the JmDNS peers in the network. For such, it uses the services provided
 * by the JmDNSService which should be installed as a local service.
 */
public class PeerPublisherInputFilter extends AbstractFilter {

	public static long id = 0;
	public static String PUBLISH_TO_PEERS = "PUBLISH_TO_PEERS";
	public static String TRUE="true";
	public static String FALSE="false";
	
	protected boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG;
	//protected boolean print = true;
	
	JmDNSService jmdnsService; // a reference to the installed service

	public PeerPublisherInputFilter() {
		super();

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.uci.isr.yancees.filter.AbstractFilter#doFilterEvent(edu.uci.isr.yancees.EventInterface)
	 */
	protected EventInterface[] doFilterEvent(EventInterface evt) {
		EventInterface[] eventList = new EventInterface[1];
		eventList[0] = evt;

		if (print)
			System.out.println("PeerPublisherInputFilter: filtering a single event...");
		
		
		/**
		 * It lets go all the events, doing no filtering. It also sends a copy
		 * of every event to the peers using the jmdnsService installed in this
		 * YANCEES configuratoin.
		 */

		if (jmdnsService == null) {
			getJmDNSService();
		}
		
		YanceesEvent event = null;
		if (evt instanceof YanceesEvent) {
			event = (YanceesEvent) evt;
		} else {
			try {
				event = new YanceesEvent(evt);
			} catch (ParsingException e) {
				e.printStackTrace();
			}
		}
		
		addIdToEvent(event);
				
		boolean publishToPeers = true; 
		
		try {
			publishToPeers = event.getString(PUBLISH_TO_PEERS).equals(TRUE);
			if (print) {
				System.out.println("PeerPublisherInputFilter: event: "+evt);
				System.out.println("PeerPublisherInputFilter: got attribute publishToPeers: "+publishToPeers);
			}
		} catch (WrongAttributeTypeException e) {
			//System.out.println(e);
			//e.printStackTrace();
			publishToPeers = true;
		} catch (AttributeNotFoundException e) {
			//System.out.println(e);
			//e.printStackTrace();
			publishToPeers = true;
		}
		
		if (publishToPeers) {
			if (print)
				System.out.println("PeerPublisherInputFilter: publishing event to peer...");
			jmdnsService.publishToPeers(evt);
		} else {
			if (print)
				System.out.println("PeerPublisherInputFilter: DO NOT publishing event");
		}

		return eventList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.uci.isr.yancees.filter.AbstractFilter#doFilterEventList(edu.uci.isr.yancees.EventInterface[])
	 */
	protected EventInterface[] doFilterEventList(EventInterface[] evtList) {

		if (jmdnsService == null) {
			getJmDNSService();
		}
		
		if (print)
			System.out.println("PeerPublisherInputFilter: filtering a list of events...");
		
		// we cast it down...
		edu.uci.isr.yancees.YanceesEvent[] eventList = (YanceesEvent[]) evtList;
		
		
		Vector filteredEventList = new java.util.Vector();
		boolean publishToPeers = true;
		
		for (int i = 0; i < eventList.length; i++) {		
			
			addIdToEvent(eventList[i]);
			
			
			publishToPeers = true;
			try {
				publishToPeers = eventList[i].getString(PUBLISH_TO_PEERS).equals(TRUE);
				if (print) {
					System.out.println("PeerPublisherInputFilter: got event: "+evtList[i]);
					System.out.println("PeerPublisherInputFilter: got attribute publishToPeers as: "+publishToPeers);
				}
				
			} catch (AttributeNotFoundException e) {
				//System.out.println(e);
				//e.printStackTrace();
				publishToPeers = true;
			} catch (WrongAttributeTypeException e) {
				//System.out.println(e);
				//e.printStackTrace();
				publishToPeers = true;
			}
			
			if (publishToPeers) {
				if (print)
					System.out.println("PeerPublisherInputFilter: marking event for publishing.");
				
				filteredEventList.add(eventList[i]);
			} else {
				if (print)
					System.out.println("PeerPublisherInputFilter: marking event as NOT publishable.");
			}
			
		}
		
		EventInterface[] finalEventList;
		finalEventList = new EventInterface[filteredEventList.size()];
		filteredEventList.copyInto(finalEventList);
		
		
		if (finalEventList.length > 0) {
			if (print) {
				System.out.println("PeerPublisherInputFilter: Publishing event list...");
			}
			jmdnsService.publishToPeers(finalEventList);
		}
		
		// we return the original event list so it can be visible locally.
		return evtList;
	}

	private void addIdToEvent(YanceesEvent event) {
		if (event != null) {
			id++;
			event.put("MESSAGE_ID", id);
		}
	}

	/**
	 * Used to get a reference to the JmDNS service that will publish the events
	 * to all the peers. This service is assumed to be installed in the current
	 * YANCEES configuration.
	 * 
	 */
	private void getJmDNSService() {
		jmdnsService = (JmDNSService) ArchitectureManager.getInstance()
				.getServiceManager()
				.getServiceByName(JmDNSService.SERVICE_NAME);
	}

}
