/*
 * Copyright (c) 2003, Regents of the University of California. All rights
 * reserved.
 * 
 * =================================================================== The
 * Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if any, must
 * include the following acknowledgment: "This product includes software
 * developed by the Institute for Software Research at University of California,
 * Irvine" Alternately, this acknowledgment may appear in the software itself,
 * if and wherever such third-party acknowledgments normally appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and "University of
 * California" must not be used to endorse or promote products derived from this
 * software without prior written permission. For written permission, please
 * contact rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called "YANCEES", nor may
 * "YANCEES" appear in their name, without prior written permission of the
 * University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * INSTITUTE FOR SOFTWARE RESEARCH AT THE UNIVERSITY OF CALIFORNIA, IRVINE, OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */

package edu.uci.isr.yancees.server.service.slp;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Properties;
import java.util.Vector;

import com.solers.slp.Advertiser;
import com.solers.slp.Locator;
import com.solers.slp.ServiceLocationEnumeration;
import com.solers.slp.ServiceLocationException;
import com.solers.slp.ServiceLocationManager;
import com.solers.slp.ServiceType;
import com.solers.slp.ServiceURL;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.server.service.AbstractService;

/**
 * This service connects YANCESS with its peers in a subnetwork. It uses the
 * service location protocol (SLP)
 */
public class SLPService extends AbstractService {

   // note that this name must be the same as the name used to register this
   // service in the arthcitecutre configuration file
   public static String SERVICE_NAME = "slp.service";

   private YanceesAdvertiser yanceesAdv;
   private ServiceURL url;
   private int serviceTimeout = 30; // service advertised for 30s
   private Locator loc = null;
   public final String YANCEES_SERVICE_NAME = "service:yancees";

   private boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG;

   //private boolean print = true;

   public SLPService() {
      super();

      try {
         loc = ServiceLocationManager.getLocator(java.util.Locale.getDefault());
      } catch (ServiceLocationException e) {
         System.out.println("SLPService: " + e);
         e.printStackTrace();
      }

      // Periodically advertises the yancees service. This approach copes with
      // the dynamism of the system. Many yancees servers can come and go in a
      // network at any time. This approach keeps them updated.
      yanceesAdv = new YanceesAdvertiser();
      yanceesAdv.start();

      if (print) {
         System.out.println("SLPService: locating other YANCEES instances...");
         printLANYanceesURLs();
      }
   }

   /**
    * Locates and display a list of other YANCEES instances in the neighborhod
    *  
    */
   public void printLANYanceesURLs() {

      ServiceURL[] urlArray = getNeighborhoodURLs();
      if (urlArray != null)
      ;
      for (int i = 0; i < urlArray.length; i++) {
         System.out.println("Found URL: " + urlArray[i].toString());
      }
   }

   /**
    * @return a list of IPs of the nosts running the YANCEES server in the local
    *         network (or the network configured in the SLP service).
    */
   public ServiceURL[] getNeighborhoodURLs() {
      ServiceURL[] urls = new ServiceURL[0];

      Vector scopes = new Vector();
      scopes.add("default");
      String selector = "";

      ServiceLocationEnumeration enum = null;

      if (loc != null) {
         try {
            enum = loc.findServices(new ServiceType(YANCEES_SERVICE_NAME),
                  scopes, selector);
         } catch (ServiceLocationException e1) {
            System.out.println("SLPService: " + e1);
            e1.printStackTrace();
         }
      }

      ServiceURL sUrl = null;

      Vector urlList = new Vector();
      while (enum != null && enum.hasMoreElements()) {
         try {
            urlList.add(enum.next());
         } catch (ServiceLocationException e2) {
            System.out.println("SLPService: " + e2);
            e2.printStackTrace();
         }
      }
      urls = new ServiceURL[urlList.size()];
      urlList.copyInto(urls);

      return urls;
   }

   /**
    * @return the ServiceURL for the current YANCEES implementation, the newest
    *         one registered for this server.
    */
   public ServiceURL getThisServerURL() {
      return url;
   }
   
   /**
    * Propagates, or publishes an event in all the peers of the network. Note
    * that for this operation, we do not use the regular publishing interface of
    * YANCEES as a way to prevent repeated circular publishing of events.
    * @param evt is the event to be propagated to the other peers.
    */
   public void publishToPeers(EventInterface evt) {
      
   }

   /**
    * Propagates, or publishes an event in all the peers of the network. Note
    * that for this operation, we do not use the regular publishing interface of
    * YANCEES as a way to prevent repeated circular publishing of events.
    * 
    * @param evtList is the event list to be propagated to the other peers.
    */
   public void publishToPeers(EventInterface[] evtList) {
      
   }

   /**
    * A thread that Advertises the URL where YANCEES is runnitg at every <b>
    * serviceTimeout </b>. seconds. In case of a disconnection, it guarantees
    * that this instance will not be accounted as active after the timeout.
    */
   private class YanceesAdvertiser extends Thread {

      private Advertiser adv;

      public void run() {

         Properties p = new Properties();
         p.put("net.slp.traceDATraffic", "true");
         p.put("net.slp.traceMsg", "true");
         p.put("net.slp.traceDrop", "true");
         p.put("net.slp.traceReg", "true");

         // The following are necessary for secure use
         // p.put("net.slp.securityEnabled", "true");
         // p.put("net.slp.privateKey.myspi", "path to pk8 private key");
         // p.put("net.slp.spi", "myspi");

         ServiceLocationManager.init(p);

         try {
            adv = ServiceLocationManager.getAdvertiser(java.util.Locale
                  .getDefault());
            while (true) {

               url = new ServiceURL("service:yancees://"
                     + InetAddress.getLocalHost().getHostAddress(),
                     serviceTimeout);

               // regirster the URL without any attribute associated to it.
               if (print) {
                  System.out
                        .println("SLPService: registering YANCEES with SLP");
                  System.out.println("Using URL: " + url);
               }

               adv.register(url, new Vector());

               try {
                  Thread.sleep((serviceTimeout - 1) * 1000);
               } catch (InterruptedException e) {
                  System.out.println("SLPService: error when thread sleeping "
                        + e);
                  e.printStackTrace();
               }
               printLANYanceesURLs();
            }

         } catch (UnknownHostException e1) {
            System.out.println("SLPService: " + e1);
            e1.printStackTrace();
         } catch (ServiceLocationException e1) {
            System.out.println("SLPService: " + e1);
            e1.printStackTrace();
         }

      }
   }

}