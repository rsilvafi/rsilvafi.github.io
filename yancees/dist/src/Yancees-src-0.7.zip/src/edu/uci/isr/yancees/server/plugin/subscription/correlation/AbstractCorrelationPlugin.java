/*
 * Copyright (c) 2003, Regents of the University of California.
 * All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 
/*
 * Created on Mar 3, 2004
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 * @version 1.0
 */
package edu.uci.isr.yancees.server.plugin.subscription.correlation;

import java.util.HashMap;
import java.util.Vector;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.plugin.AbstractMOPlugin;
import edu.uci.isr.yancees.plugin.MOPluginInterface;


/**
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public abstract class AbstractCorrelationPlugin extends AbstractMOPlugin {

	public final static String WITHIN_ATTRIBUTE_TAG = "within";
	public final static String AFTER_ATTRIBUTE_TAG  = "after";

	 int totalNotificationsExpected;
	 int totalNotificationsReceived;
	 Vector listOfBuffers; // list of all active event buffers, partially evaluated
	 long[] eventSourceIDPattern; // sequence of plug-ins that produces events, implies a pattern
  
	 final boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG;
   
	 // these values should be parsed, being part of the XML declaration of the AND tag.
	 long withinInterval = -1; //initially disabled
	 long afterInterval = -1;  //initially disabled

	 // fast translation between plug-in id and its position in pattern
	 HashMap pluginIdToPatternIndexMap = new HashMap();

	 /**
	  * @param subTree is the DOM tree this plugin is responsible for executing
	  * evalutation of this plugin is published.
	  */
	 public AbstractCorrelationPlugin(Node subTree) {
		super(subTree);

		if (print) {
			System.out.println("AbstractCorrelationPlugin: new instance...");
		}
		
		extractAttributes(subTree);     
		
		eventSourceIDPattern = null;
		
		 /*
		  * Each buffer represents a partially matched pattern
		  * We create a different buffer for every new event arrived
		  */
		listOfBuffers = new Vector();
      
	 }
	 
	 /**
	  * Parses the DOM Node representing this Plug-in in order to extract the
	  * optional attributes: 
	  * @param correlationNode
	  */
	 
	 private void extractAttributes(Node correlationNode) {
	 	if (correlationNode != null && correlationNode.hasAttributes()) {
	 		
	 		//System.out.println("Got node name: "+correlationNode.getLocalName());
	 		
	 		NamedNodeMap names = correlationNode.getAttributes();
	 		
	 		/*
	 		System.out.println("Number of attributes: "+names.getLength());
			for (int i = 0; i < names.getLength(); i++) {
				 System.out.println("att name = "+names.item(i).getNodeName());
				 System.out.println("att value = "+names.item(i).getNodeValue());
			}
			*/
	 		 		
	 		Node withinItem = names.getNamedItem(WITHIN_ATTRIBUTE_TAG);
			Node afterItem = names.getNamedItem(AFTER_ATTRIBUTE_TAG);
			
			/*
			System.out.println("Got within item: "+withinItem);
			System.out.println("Got after item: "+afterItem);
			*/
			
			if (withinItem != null) {
				withinInterval = Long.parseLong(withinItem.getNodeValue());
				if (print)
					System.out.println("AbstractCorrelationPlugin: got withinInterval: "+withinInterval);
			} 
			if (afterItem != null) {
				afterInterval = Long.parseLong(afterItem.getNodeValue());
				if (print)
					System.out.println("AbstractCorrelationPlugin: got afterInterval: "+afterInterval);
			} 
	 		
	 	}
	 }
   
	 /**
	  * Finds the position of the id in the pattern being observed.
	  * This operation is performed in O(1)
	  * @return the position of the id in the array or -1 if not found
	  */
	 protected int getPluginIdIndex (long id) {
		 Integer index = (Integer) pluginIdToPatternIndexMap.get(new Long(id));
		 if (index != null) {
			 return index.intValue();
		 } else {
			 return -1;
		 }
	 }

	 /**
	  * A new pattern came from a given source (represented from its id).
	  * this method is used to process more complex expressions such as (A or B) and C
	  * where the result from (A or B) is a set of events.
	  * @param eventList is the pattern published by a required plug-in
	  * @param id is the plug-in id where the pattern came from
	  */
	 private void processEventList(EventInterface[] eventList, long id) {
		   
		   //buld the pattern at the first time an event arrives, if it is not there.
			if (eventSourceIDPattern == null) {
			  initializePattern();
			}
		   for (int i = 0; i < eventList.length; i++) {
				processObject(eventList[i], id);	
			}
		   
	 }
	
	 /**
		* A new pattern came from a given source (represented from its id).
		* this method is used to process more complex expressions such as (A or B) and C
		* where the result from (A or B) is a set of events.
		* @param event is the event published by a required plug-in
		* @param id is the plug-in id where the event came from
		*/
	 private void processEvent(EventInterface event, long id) {
		
		//buld the pattern at the first time an event arrives, if it is not there.
		if (eventSourceIDPattern == null) {
		  initializePattern();
		}
		 processObject(event, id);
	 }
	
	 /**
	  * This method is called by the processObject() to initialize the sourceIDpattern
	  * and to create a hashmap associating ids with their index in the buffer.
	  * It is important NOT to call it in the constructor since at that point, 
	  * the plug-in tree is not already built.
	  */
	 private void initializePattern() {
		 eventSourceIDPattern = getExpectedPluginIDs();
		 for (int i = 0; i < eventSourceIDPattern.length; i++) {
			 pluginIdToPatternIndexMap.put(new Long(eventSourceIDPattern[i]), new Integer(i));
		 }
	 }
	
	 /**
	  * A new event came from a given source (represented from its id).
	  * @param element is the new arrived event 
	  * @param id is the id of the plug-in that sent the event
	  */
	 protected abstract void processObject(Object object, long id);

	 /**
	  * Receives a notification from another plug-in this plug-in is dependent on
	  * @param evt is the event received
	  * @param source is the plug-in sending the notification.
	  */
	 public void receivePluginNotification(EventInterface evt, MOPluginInterface source) {
		 if (print) {
			 System.out.println("AbstractCorrelationPlugin: got a plugin notification...");
		 }
      
		 processEvent(evt, source.getId());
	 }

	 /**
	  * Receives a list of events as notifications from another plug-in
	  * @param evtList is the list of events received
	  * @param source is the plug-in sending the notification.
	  **/
	 public void receivePluginNotification(EventInterface[] evtList, MOPluginInterface source) {

		 if (print) {
			 System.out.println(
					 "AbstractCorrelationPlugin: got plugin notification with multiple events...");
		 }

		 processEventList(evtList, source.getId());
  
	 }

	 /**
	  * Resets the current plugin in order to capture new sequences.
	  */
	 private void reset() {
		 listOfBuffers.removeAllElements();
	 }  

}
