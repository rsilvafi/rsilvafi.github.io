/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.server.dispatcher.switcher;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.util.Date;
import java.util.Vector;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import edu.uci.isr.yancees.SubscriptionInterface;
import edu.uci.isr.yancees.core.ParsingException;

/**
 * This class implements a siena subscription parser. It parses and converts an
 * XML subscription in the Siena format to the native siena subscription.
 *
 * Hence, this subscription represents the main functionality of the core event
 * dispatcher component, on top of which all other subscription extensions are
 * build.
 *
 * In other words, the subscription is an adapter around a DOM node that is able
 * to map the specific sienaSubscriptio.xsd elements to filters in Siena internal
 * representation. Hence, it works as a container and a translator of the
 * subscription subtrees that are understood by siena.
 */
public class SwitcherSubscription
      implements SubscriptionInterface {

   private static long globalID =0;
   private long id;

   private org.w3c.dom.Node domTree; // For memory purposes, we may need to get rid of it.
   private String[] requireFields; // The name of all required fields in the events
   
   private Date dateCreated;
   private Date dateReceivedInServer;

   
   /** Tags imported from the switcherSubscriptin.xsd
    */
   public static final String SUBSCRIPTION = "subscription";

   // Delimiters a filter as defined in the switcherSubscription.xsd
   public static final String REQUIRE = "require";

   private boolean print = edu.uci.isr.yancees.YanceesFacade.PRINT_DEBUG; // togles print of trancing debug messages

   /**
    * Initializes this object with a DOM tree to be parsed
    * we assume here that the subscription is provided according
    * to sienaSubscription.xsd and the node provided here corresponds to the
    * <subscription> tag.
    */
   public SwitcherSubscription(org.w3c.dom.Node node) throws
         ParsingException {

      SwitcherSubscription.globalID++;
      this.id = globalID;
      this.dateCreated = new Date();
      this.dateReceivedInServer=null;

      // Subscription in an incomplete format, just a <filter> node provided.
      // This part of the code helps in the siena plugin.
      if (node.getNodeName().endsWith(":" + REQUIRE) ||
          node.getNodeName().equals(REQUIRE)) {
         domTree = node;
         requireFields = new String[1];
         requireFields[0] = parseRequire(node);
         

      } else if (node.getNodeName().endsWith(":" + SUBSCRIPTION) ||
                 node.getNodeName().equals(SUBSCRIPTION)) {
         domTree = node;
         requireFields = parseRequireFields(domTree); // a subscription in siena is a pattern or a filter.
      // if it is a <message>, we look for the <subscription> tag.
      } else {
         domTree = null; // the attribute of this class that stores the subscription DOM tree
         if (node.hasChildNodes()) {
            NodeList list = node.getChildNodes();
            //System.out.println("Tree has : "+list.getLength()+" children");
            for (int i = 0; i < list.getLength(); i++) {
               Node myNode = list.item(i);
               //System.out.println("Checking for : "+myNode.getNodeName());
               if (myNode.getNodeName().endsWith(":" + SUBSCRIPTION) ||
                   myNode.getNodeName().equals(SUBSCRIPTION)) {
                  domTree = myNode;
                  //System.out.println("Found : "+myNode.getNodeName());
                  break;
               }
            }
            if (domTree == null) {
               throw new ParsingException(
                     "Could not find a <subscripton> node " +
                     "in tree headed by :" + node.getNodeName());
            }
         }
         //System.out.println("Found 'subscription' node. Parsing it...");
         requireFields = parseRequireFields(domTree);

      }

   }

   public long getId() {
      return id;
   }

   /**
    * Changes the current subscription DOM tree
    */
   public void setDOM(org.w3c.dom.Node node) throws
         ParsingException {

      if (node.getNodeName().endsWith(":" + REQUIRE) ||
          node.getNodeName().equals(REQUIRE)) {
         domTree = node;
			requireFields = new String[1];
			requireFields[0] = parseRequire(node);
          

      } else if (node.getNodeName().endsWith(":" + SUBSCRIPTION) ||
                 node.getNodeName().equals(SUBSCRIPTION)) {
         domTree = node;
         requireFields = parseRequireFields(domTree); // a subscription in siena is a pattern or a filter.
      } else {
         domTree = null;
         if (node.hasChildNodes()) {
            NodeList list = node.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
               Node myNode = list.item(i);
               if (myNode.getNodeName().endsWith(":" + SUBSCRIPTION) ||
                   myNode.getNodeName().equals(SUBSCRIPTION)) {
                  domTree = myNode;
                  break;
               }
            }
            if (domTree == null) {
               throw new ParsingException(
                     "Could not find a <subscripton> node");
            }
         }
         requireFields = parseRequireFields(domTree);

      }

   }

   /**
    * @return the current DOM tree representing this subscription
    */
   public org.w3c.dom.Node getDOM() {
      return domTree;
   }

   public String[] getRequireFields() {
      return requireFields;
   }

   
   private String[] parseRequireFields(org.w3c.dom.Node subscriptionDOM) {
      if (print) {
         System.out.println("parseRequireFields");
      }

      Vector fieldsList = new Vector(0, 5);
      String[] requireArray;

      if (subscriptionDOM != null && subscriptionDOM.hasChildNodes()) {
         NodeList list = subscriptionDOM.getChildNodes();
         int type;
         Node n;
         for (int i = 0; i < list.getLength(); i++) {
            n = list.item(i);
            type = n.getNodeType();
            if (type == Node.ELEMENT_NODE) {
               if (n.getNodeName().equals(REQUIRE) ||
                   n.getNodeName().endsWith(":" + REQUIRE)) {
                  String field = parseRequire(n);
                  fieldsList.add(field);
               }
            }
         }
      }

      requireArray = new String[fieldsList.size()];
      fieldsList.copyInto(requireArray);

      return requireArray;
   }


   private String parseRequire(org.w3c.dom.Node requireDOM) {
      if (print) {
         System.out.println("parseRequire");
      }
      
      String requireValue = null;

      if (requireDOM != null) {
			requireValue = parseNodeTextContent(requireDOM);
      }
	
		System.out.print("SwitcherSubscription: parsed: [require(");
		System.out.println(requireValue+")]");

      return requireValue;
   }



   /**
    * @return the text 'value' of a node like <element> value <element>
    * or null in case this value does not exist.
    */
   private String parseNodeTextContent(org.w3c.dom.Node node) {
      if (print) {
         System.out.println("parseNodeTextContent");
      }
      NodeList list = node.getChildNodes();
      int nodeType;
      Node n;
      for (int i = 0; i < list.getLength(); i++) {
         n = list.item(i);
         nodeType = n.getNodeType();
         if (nodeType == Node.TEXT_NODE) {
            return n.getNodeValue().trim();
         }
      }

      return null;
   }


   public String toString() {
      StringBuffer sb = new StringBuffer();
      sb.append("require ( ");
      for (int i = 0; i < requireFields.length; i++) {
         sb.append(requireFields[i].toString());
         sb.append(",");
      }
      sb.append(") \n");
      return sb.toString();

   }

   /**
    * Changes the content of this message. Replaces it with the XML content
    * provided in the String provided
    * @param content is the new XML format contnet in the form of a String
    */
   public void setXMLTextContent(String content) {
      /**@todo Implement this method*/
      throw new java.lang.UnsupportedOperationException(
            "Method setXMLTextContent() not yet implemented.");
   }

   /**
    * @return the content of this message in the text form, as a string.
    */
   public String getXMLTextContent() {
      /**@todo Implement this method*/
      throw new java.lang.UnsupportedOperationException(
            "Method getXMLTextContent() not yet implemented.");

   }
   
	public Date getDateCreated() {
		return dateCreated;
	}

	public Date getDateReceivedInServer() {
		return dateReceivedInServer;
	}

}