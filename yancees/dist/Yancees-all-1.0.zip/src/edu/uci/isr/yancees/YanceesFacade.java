/*
 * Copyright (c) 2002, Regents of the University of California. All rights
 * reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if any, must
 * include the following acknowledgment: "This product includes software
 * developed by the Institute for Software Research at University of California,
 * Irvine" Alternately, this acknowledgment may appear in the software itself,
 * if and wherever such third-party acknowledgments normally appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and "University of
 * California" must not be used to endorse or promote products derived from this
 * software without prior written permission. For written permission, please
 * contact rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called "YANCEES", nor may
 * "YANCEES" appear in their name, without prior written permission of the
 * University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
 * WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package edu.uci.isr.yancees;

/**
 * <p>
 * Title: Yancees Notification Server
 * </p>
 * <p>
 * Description: Yet ANother Configurable Extensible Event Service
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: School of Information and Computer Science - University of
 * California, Irvine
 * </p>
 * 
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.w3c.dom.Document;

import edu.uci.isr.yancees.core.MessageParsingException;
import edu.uci.isr.yancees.util.DOMNodeAdapter;
import edu.uci.isr.yancees.util.DOMParser;

/**
 * This class centralized all aspects of yancees: 1) The unique connection to
 * the dispatcher (siena, elvin or other) 2) The access to the specific Facades
 * (publication, subscription, administration), configuring them as necessary 3)
 * The parsing of files in Notification, Subscription and Message wrappers
 * 
 * Local users should use this class as the front-end to Yancees notification
 * server Remote users should use the RemoteYanceesInterface. This last
 * interface is most likely to be the preferred one.
 *  
 */
public class YanceesFacade {

	// BEGIN OF PROPERTIES
	
   // Globally enables or disables the printing of debugging information
   //public static boolean PRINT_DEBUG = true;

   //public static boolean PERFORM_XML_VALIDATION = true;

   // Configures the sizes of the input and output buffers on the RMI fa�ades
   //public static int PS_BUFFER_SIZE = 100;
   //public static int PS_BUFFER_FLUSH_PERIOD = 50;

   // END OR PROPERTIES
   
   private String yanceesPropertiesFileName = "yancees.properties";

   final static String MESSAGE_TAG = "message";
   final static String EVENT_TAG = "event";

   // Unique instance of this singleton.
   private static YanceesFacade myInstance;

   private ArchitectureManager archMan = null;
   private ProtocolFacade protocolAPI = null;
   private SubscriptionFacade subscriberAPI = null;
   private PublicationFacade publisherAPI = null;

   private boolean initialized = false;

   private String printDebugInformaitonPropName = "printDebugInformation";
   private String performXMLValidationPropName  = "performXMLValidation";
   private String usePubSubBuffer           = "usePubSubBuffer";
   private String pubSubBufferSize          = "pubSubBufferSize";
   private String pubSubBufferFlushInterval = "pubSubBufferFlushInterval";

	private String myLookupName;

   /**
    * This constructor, as protected, prevents the direct instantiation of this
    * object, and guarantees the singleton characteristic of this class. The
    * protected modifier allows this class to be sub-classed, permitting the over-
    * load of the constructor.
    */
   protected YanceesFacade() {
      boolean ignorePropertiesFile = false; // indicates whether to read runtime properties from file
      Properties defaultProps = new Properties();
      FileInputStream in;
      try {
         in = new FileInputStream(yanceesPropertiesFileName);
         defaultProps.load(in);
         in.close();
      } catch (FileNotFoundException e) {
         System.out
               .println("Ignoring properties file, using default configuration");
         ignorePropertiesFile = true;
      } catch (IOException e1) {
         System.out
               .println("Ignoring properties file, using default configuration");
         ignorePropertiesFile = true;
      }

      // reads runtime properties form file and configures Yancees.	
      if (!ignorePropertiesFile) {
         System.out.println("YanceesFacade: Using Yancees startup properties:");
         System.out.println(defaultProps);
         if (defaultProps.containsKey(performXMLValidationPropName)) {
            YanceesProperties.getInstance().PERFORM_XML_VALIDATION = new Boolean(defaultProps
                  .get(performXMLValidationPropName).toString()).booleanValue();
            System.out.println(performXMLValidationPropName + " = "
                  + YanceesProperties.getInstance().PERFORM_XML_VALIDATION);
         }

         if (defaultProps.containsKey(printDebugInformaitonPropName)) {
        	 YanceesProperties.getInstance().PRINT_DEBUG = new Boolean(defaultProps.get(
                  printDebugInformaitonPropName).toString()).booleanValue();
            System.out.println(printDebugInformaitonPropName + " = "
                  + YanceesProperties.getInstance().PRINT_DEBUG);
         }
         
         if (defaultProps.containsKey(usePubSubBuffer)) {
          	 YanceesProperties.getInstance().USE_PUBLICATION_BUFFER = new Boolean(defaultProps.get(
          			usePubSubBuffer).toString()).booleanValue();
              System.out.println(usePubSubBuffer + " = "
                    + YanceesProperties.getInstance().USE_PUBLICATION_BUFFER);
           }

         if (defaultProps.containsKey(pubSubBufferSize)) {
        	 YanceesProperties.getInstance().PS_BUFFER_SIZE = Integer.parseInt(defaultProps.get(
                  pubSubBufferSize).toString());
            System.out.println(pubSubBufferSize + " = " + YanceesProperties.getInstance().PS_BUFFER_SIZE);
         }

         if (defaultProps.containsKey(pubSubBufferFlushInterval)) {
        	 YanceesProperties.getInstance().PS_BUFFER_FLUSH_PERIOD = Integer
                  .parseInt(defaultProps.get(pubSubBufferFlushInterval)
                        .toString());
            System.out.println(pubSubBufferFlushInterval + " = "
                  + YanceesProperties.getInstance().PS_BUFFER_FLUSH_PERIOD);
         }
      }
   }

   /**
    * The only way to access the unique instance of Yancees is by using this
    * access method.
    * 
    * @return the instance of Yancess using the default configuration.
    */
   
   public static YanceesFacade getInstance() {
      if (myInstance == null) {
         myInstance = new YanceesFacade();
      }
      return myInstance;
   }
   
   /*
   public static YanceesFacade getInstance(File configFile, String lookupName) {
      if (myInstance == null) {
         myInstance = new YanceesFacade();
         myInstance.setLookupName(lookupName);
         try {
				myInstance.bootstrap(configFile);
			} catch (MessageParsingException e) {
				e.printStackTrace();
			}
      }
      return myInstance;
   }
   */
   
   /**
    * This is a new factory method. Instead of making this class a singleton, this
    * factory allows the creation of multiple instances of YANCEES in the same
    * virtual machine.
    */
   /*
   public static YanceesFacade getInstance() {
      return new YanceesFacade();
   }
   */

   /**
    * Initializes the system using the default configuration. This method should
    * be called before any other methods in this class.
    */
   public void initialize() {
      if (!initialized) buildArchitectureConfiguration();
      initialized = true;
   }

   /**
    * Initialize the client API using the provided configuration file. This
    * method should be called before any other methods in this class.
    * 
    * @param configFile
    *           is a file having the configuration for all the components of the
    *           system.
    */
   public void bootstrap(File configFile) throws MessageParsingException {
      if (!initialized) buildArchitectureConfiguration(configFile);
      initialized = true;
   }

   /**
    * Automatically called when the object is destroyed, this method disposes
    * all the resources allocated by the server, closing all the connections to
    * the dispatcher in use, saving all data and finalizing all the plug-ins and
    * so on.
    */
   protected void finalize() throws Throwable {
      archMan.dispose();
      super.finalize();
   }

   /**
    * builds the client-side configuration using the DEFAULT configuration.
    * 
    * @param configFile
    */
   private void buildArchitectureConfiguration() {
      archMan = ArchitectureManager.getInstance();
      archMan.initialize();
   }

   /**
    * builds the client-side configuration using a configuration file
    * 
    * @param configFile
    *           is a XML document describing the plug-ins and services available
    *           to this Yancees instance.
    */
   private void buildArchitectureConfiguration(File configFile)
         throws MessageParsingException {
      archMan = ArchitectureManager.getInstance();
      archMan.initialize(configFile);
   }

   /**
    * Get access to the internal protocolAPI and initializes this component if
    * necessary
    * 
    * @return the ServerPrococolFacade unique instance
    */
   public ProtocolFacade getProtocolAPI() {
      
   	// Initializes the protocolAPI if not initialized
   	if (protocolAPI == null && initialized) {
         protocolAPI = ProtocolFacade.getInstance();
         protocolAPI.setProtocolManager(archMan.getProtocolManager());
      }

      return protocolAPI;
   }

   /**
    * Get access to the internal publisher API and initializes this component if
    * necessary
    * 
    * @return the ServerPublicationFacade unique instance
    */
   public PublicationFacade getPublisherAPI() {
      
   	// Initialize the publisherAPI if not already initialized
   	if (publisherAPI == null && initialized) {
         publisherAPI = PublicationFacade.getInstance();
         publisherAPI.setEventDispatcher(archMan.getEventDispatcher());
         if (archMan.getInputFilterManager().getNumberOfFilters() > 0)
               publisherAPI
                     .installInputFilters(archMan.getInputFilterManager());
      }

      return publisherAPI;
   }

   /**
    * Gets access to the internal subscriber API and initializes this component
    * if necessary
    * 
    * @return the ServerSubscriptionFacade unique instance
    */
   public SubscriptionFacade getSubscriberAPI() {
      if (subscriberAPI == null && initialized) {
         subscriberAPI = SubscriptionFacade.getInstance();
         subscriberAPI.setSubscriptionManager(archMan.getSubscriptionManager());
         subscriberAPI.setNotificationManger(archMan.getNotificationManager());
         if (archMan.getOutputFilterManager().getNumberOfFilters() > 0)
               subscriberAPI.installOutputFilters(archMan
                     .getOutputFilterManager());
      }

      return subscriberAPI;
   }

   //--------------------- BEGIN static Utility methods -------------------------

   /**
    * Allows users to easily parse their XML messages before sending to the APIs
    * 
    * @param messageFile
    *           is the file to be parsed
    * @return a Message object with the parsed document or null in case of some
    *         error
    * @throws MessageParsingException
    *            in case the <message>tag is not present in the document
    */
/*  
public static GenericMessage parseMessage(File messageFile)
         throws MessageParsingException {

      Document doc = parseDocument(messageFile);
      if (doc != null) {
         DOMNodeAdapter adapt = new DOMNodeAdapter(doc);
         if (!adapt.hasChildElement(MESSAGE_TAG)) {
            throw new MessageParsingException("Tag <" + MESSAGE_TAG
                  + "> was not found!");
         } else {
        	// return new GenericMessage(doc); 
            return new GenericMessage(adapt.toXML());
         }
      }
      return null;
   }

*/   /**
    * Allows users to easily parse their XML events before sending to the APIs
    * 
    * @param eventFile
    *           is the file to be parsed
    * @return an Event object with the parsed document or null in case of some
    *         error
    * @throws MessageParsingException
    *            in case the <event> tag is not present in the document
    */
  /*
  public static GenericEvent parseEvent(File eventFile)
         throws MessageParsingException {

      Document doc = parseDocument(eventFile);
      if (doc != null) {
         DOMNodeAdapter adapt = new DOMNodeAdapter(doc);
         if (!adapt.hasChildElement(EVENT_TAG)) {
            throw new MessageParsingException("Tag <" + EVENT_TAG + "> was not found!");
         } else {      	 
            return new GenericEvent(new DOMNodeAdapter(doc).toXML());
         }
      }
      return null;
   }

*/   /**
    * Parsers a XML document from a file into a XML DOM Document object. This
    * parser performs syntactic checking according to the XMLSechema types
    * defined in the document. In other words, it is a validating and name-aware
    * parser
    * 
    * @param documentFile
    *           is the file which will be parsed into a Document object
    * @return a Document object with the parsed document.
    */
   /*
   private static Document parseDocument(File documentFile) {

      DOMParser parser = new DOMParser(documentFile);
      Document document = parser.getDocument();

      return document;
   }

*/	public void setLookupName(String lookupName) {
		myLookupName = lookupName;
	}
	
	public String getLookupName() {
		return myLookupName;
	}

   //--------------------- END static utility methods -------------------------

}