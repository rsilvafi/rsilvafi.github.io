/*
 * Copyright (c) 2008, Regents of the University of California.
 * All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE INSTITUTE FOR SOFTWARE RESEARCH AT THE UNIVERSITY
 * OF CALIFORNIA, IRVINE, OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */

package edu.uci.isr.yancees.server.rmi;

import java.rmi.RemoteException;

import edu.uci.isr.yancees.YanceesException;

/**
 * This buffer schedules events to be notified. The aim is to cope with
 * scalability and high throughput, in order to publish a bunch of events at
 * once, instead of one at a time. This strategy better utilizes the RMI
 * serialization mechanisms and icreases the throughput of the server.
 *
 * A big buffer will allow the server to handle more publish commands per
 * second. However, it will reduce the latency (the time between production
 * and delivery of an event). A low SLEEP_TIME will not permit the buffer to
 * get full, and will reduce the throughput.
 *
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 *
 */
public class NotificationBuffer extends Thread {
	
	private final int BUFFER_SIZE = edu.uci.isr.yancees.YanceesProperties
			.getInstance().PS_BUFFER_SIZE; // maximum number of events in the
														// buffer
	private final int SLEEP_TIME = edu.uci.isr.yancees.YanceesProperties
			.getInstance().PS_BUFFER_FLUSH_PERIOD; // period when the buffer, if
																// full, is flushed.
	
	private boolean print = edu.uci.isr.yancees.YanceesProperties.getInstance().PRINT_DEBUG;
	
	// private final int BUFFER_SIZE = 100; // maximum number of events in the
	// buffer
	// private final int SLEEP_TIME = 50; // period when the buffer, if full,
	// is flushed.

	// cicular buffer
	Object[] buffer = new Object[BUFFER_SIZE];
	SubscriberMediator mediator;

	private int size = 0;
	private int bottom = 0;

	RemoteSubscriberInterface remoteInterface = null;

	long totalNotificationsSent = 0;

	public NotificationBuffer(RemoteSubscriberInterface remInt,
			SubscriberMediator med) {
		remoteInterface = remInt;
		mediator = med;
	}

	/**
	 * Main logic of this thread
	 */
	public void run() {
		while (true) {
			if (!bufferIsEmpty()) {
				// System.out.println("NotificatonBuffer: notifying events...");
				// System.out.println("Elements in buffer: "+size);
				notifyEventsAndPatterns();
			} else {
				try {
					Thread.sleep(SLEEP_TIME);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Method used internally at this class to publish the events in the
	 * buffer.
	 */
	private void notifyEventsAndPatterns() {

		// System.out.println("Publishing events...");
		// System.out.println(" bottom = "+bottom+" elements = "+size);

		if (!bufferIsEmpty()) {

			Object[] list;
			/*synchronized(buffer) { */
				int elementsToProcess = size;
				list = new Object[elementsToProcess];
				for (int i = 0; i < elementsToProcess; i++) {
					list[i] = getObjectFromBuffer();
				}
			/*} */

			try {

				if (print)
					System.out.println("RemoteYanceesImplementation: notifying client with list size: "+list.length);

				remoteInterface.notifyBuffer(list);
				// totalNotificationsSent += evtList.length;
				// System.out.println("Total Events Notified =
				// "+totalNotificationsSent);
			} catch (RemoteException e) {
				System.out
						.println("NotificationBuffer: cound not send notification, unsubscribing...");
				 e.printStackTrace();

				try {
					mediator.getRemoteYanceesReference().unsubscribe(remoteInterface);
				} catch (RemoteException e1) {
					System.out
							.println("NotificationBuffer: Communication error when unsubscribing stale subscriber");
					e1.printStackTrace();
				} catch (YanceesException e1) {
					System.out
							.println("NotificationBuffer: Error when unsubscribing stale subscriber");
					e1.printStackTrace();
				}

			}

		}

		// System.out.println("Published");
		// System.out.println(" bottom = "+bottom+" elements = "+size);
		// System.out.println();
	}

	/**
	 * Method used by the clients of this class to enqueue events in the
	 * buffer
	 *
	 * @param event
	 */
	public void addObjectToBuffer(Object obj) {

		if (bufferIsFull()) {
			// flush buffer first if it is full...
			notifyEventsAndPatterns();
		}

		// System.out.println("Adding element to buffer");
		// System.out.println(" bottom = "+bottom+" elements = "+size);

		synchronized(buffer) {
			int index = (bottom + size) % BUFFER_SIZE;
			buffer[index] = obj;
			incSize();
		}
	}

	/**
	 * This method should be called when there is some event on the buffer,
	 * otherwise, it returns null
	 *
	 * @return null if buffer is empty, the element in FIFO order, in case
	 *         there is at least one element on it.
	 */
	public Object getObjectFromBuffer() {
		int index = bottom;

		synchronized(buffer) {
			if (size > 0) {
				incBottom();
				decSize();
				return buffer[index];
			} else {
				return null;
			}
		}
	}

	private void incBottom() {
		bottom = (bottom + 1) % BUFFER_SIZE;
	}

	private void decSize() {
		if (size > 0)
			size--;
	}

	private void incSize() {
		size++;
	}

	private boolean bufferIsFull() {
		return size == BUFFER_SIZE;
	}

	private boolean bufferIsEmpty() {
		// for some reason, the buffer size is becoming negative, even though
		// I have a guard at decsize()
		return size <= 0;
	}

}

