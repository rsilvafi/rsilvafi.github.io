/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 *
 * ===================================================================
 * The Apache Software License, Version 1.1
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 *
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 *
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
/*
 * Created on Oct 9, 2003
 *
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 * @version 1.0
 */
package edu.uci.isr.yancees.client.rmi;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Hashtable;

import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.MessageInterface;
import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.SubscriptionInterface;
import edu.uci.isr.yancees.YanceesException;
import edu.uci.isr.yancees.YanceesInterface;
import edu.uci.isr.yancees.client.YanceesClient;
import edu.uci.isr.yancees.plugin.ProtocolPluginInterface;
import edu.uci.isr.yancees.server.rmi.RemoteAbstractSubscriberImplementation;
import edu.uci.isr.yancees.server.rmi.RemoteProtocolPluginInterface;
import edu.uci.isr.yancees.server.rmi.RemoteSubscriberInterface;
import edu.uci.isr.yancees.server.rmi.RemoteYanceesInterface;

/**
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 *
 * This is the API used by remote clients to interact with the YANCEES server
 * using RMI. It hides from the end users, the code necessary to connect to the
 * remote server, the RMI name resolution and so on.
 *
 * This API does not support client-side plug-ins. It works as a direct
 * connection between client and server, allowing a faster interaction in this
 * case.
 *
 * Client-side plug-ins are supported in another API,
 * @see YanceesClient.java
 *
 */
public class YanceesRMIClient implements YanceesInterface {

	private RemoteYanceesInterface _yanceesRemote;

   // associates the subscriber interface with the mediator
	private HashMap<SubscriberInterface, SubscriberMediator> _mediatorsMap = new HashMap<SubscriberInterface, SubscriberMediator>();

	private  boolean USE_PUBLICATION_BUFFER = edu.uci.isr.yancees.YanceesProperties.getInstance().USE_PUBLICATION_BUFFER;
	private PublicationBuffer _pubBuffer;
	private boolean print = edu.uci.isr.yancees.YanceesProperties.getInstance().PRINT_DEBUG;

	/**
	 * Creates a client implementation and automatically connects to the address
	 * provided using the specified instance name. For example:
	 * 192.168.0.3/yancees3 where 192.168.0.3 is the hostname and yancees3 is
	 * the instance name.
	 *
	 * @param hostname
	 *            is the name of the host having the RMI registry where the
	 *            YANCEES interface is registered.
	 * @param instanceName
	 *            is the name of the yancees instance as it is registered with
	 *            the rmiregistry. This allows multiple copies of yancees to be
	 *            executed in the same host, for example.
	 */
	public YanceesRMIClient(String hostname, String instanceName)
			throws YanceesException {
		connectToYancees(hostname, instanceName);

		if (USE_PUBLICATION_BUFFER) {
			_pubBuffer = new PublicationBuffer();
			_pubBuffer.start();
		}

	}


	/**
	 * Creates a client implementation and automatically connects to the address
	 * provided
	 *
	 * @param address is the hostname or the full address where YANCEEES remote
	 * implementation is published.
	 */
	public YanceesRMIClient(String address) throws YanceesException {
		if (address.startsWith("//")) {
			connectToYancees(address);
		} else {
			System.out.println("YanceesRMIClient: connectiong using default address...");
			connectToYancees(address, RemoteYanceesInterface.RMI_LOOKUP_NAME);
		}

		if (USE_PUBLICATION_BUFFER) {
			_pubBuffer = new PublicationBuffer();
			_pubBuffer.start();
		}

	}

	/**
	 * Connects to an YANCEES instance using a fully qualifying address
	 * @param fullRMIReference is the full qualifying address
	 * @throws YanceesException
	 */
	protected void connectToYancees(String fullRMIReference) throws YanceesException {

		try {
			System.out.println("YanceesRMICLient: Binding to yancees remote implementation at address "
							+ fullRMIReference + "...");

			_yanceesRemote = (RemoteYanceesInterface) Naming.lookup(fullRMIReference);

			System.out.println(" [ OK ]");

		} catch (NotBoundException ex) {
			throw new YanceesException(
					"YanceesRMICLient: Yancees RMI service at address "
							+ fullRMIReference
							+ " was not found. Make sure yancees server is running.");
		} catch (MalformedURLException ex) {
			throw new YanceesException(
					"YanceesRMICLient: Wrong Yancees URI. Wrong host name or Yancees server name: "+fullRMIReference);
		} catch (RemoteException ex) {
			throw new YanceesException(
					"YanceesRMICLient: Error binding to the service: "
							+ ex.toString());
		}
	}

	/**
	 * Connects to Yancees in a given hostname and instance name. The name is composed
	 * and used to form a RMI URL.
	 * @param hostname is the name of the host where the instance is running
	 * @param instanceName is the name as registered in the local rmiregistry
	 * @throws YanceesException
	 */
	protected void connectToYancees(String hostname, String instanceName) throws YanceesException{

		if (instanceName == null) {
			System.out.println("YanceesRMIClient: using default Yancees Instance name.");
			instanceName = RemoteYanceesInterface.RMI_LOOKUP_NAME;
		}

		if (hostname == null ) {
			throw new YanceesException("Null hostname passed as parameter");
		} else if (hostname.startsWith("//")) {
			throw new YanceesException("Malformed hostname :"+hostname);
		} else 	if (hostname.equals("localhost")) {
			try {
				// hostname = InetAddress.getLocalHost().getCanonicalHostName();

				// We use the IP address instead since in the JmDNS scenario, a
				// hostname
				// may have different IP addresses, so we need to be precise and
				// use only
				// one of them.
				System.out.println("YanceesRMIClient: getting actual IP address for localhost...");
				hostname = InetAddress.getLocalHost().getHostAddress();
			} catch (UnknownHostException e) {
				e.printStackTrace();
			}
		} else {
			/*
			try {
							System.out.println("YanceesRMIClient: getting actual IP address for "+hostname);
				hostname = InetAddress.getByName(hostname).getHostAddress();
			} catch (UnknownHostException e) {
				e.printStackTrace();
			}
			*/
		}

		/**
		 * In the PocketPC, an error occurs if one tries to bound to a name.
		 * performing a lookup before bounding solves the problem.
		 */
		listBoundedRMINamesInHost(hostname);

		connectToYancees("//"+hostname+"/"+instanceName);

	}

	/**
	 * Forces a list of bounded names in a host
	 */
	private void listBoundedRMINamesInHost(String hostname) {

		String[] boundNames;
		try {
			boundNames = Naming.list("//"+hostname);

			if(print)
				System.out.println("RemoteYanceesImplementation: bound names:");
			for (int i = 0; i < boundNames.length; i++) {
				System.out.println(boundNames[i]);
			}

		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see edu.uci.isr.yancees.YanceesInterface#connectToSharedProtocol(java.lang.String,
	 *      edu.uci.isr.yancees.SubscriberInterface)
	 */
	public ProtocolPluginInterface connectToSharedProtocol(String protocolId,
			SubscriberInterface si) throws YanceesException {

		RemoteProtocolPluginInterface plugin;

		SubscriberMediator rsi = (SubscriberMediator) _mediatorsMap.get(si);
		if (rsi == null) {
			try {
				rsi = new SubscriberMediator(si);
			} catch (RemoteException e1) {
				System.out.println("YanceesRMIClient: remote exception");
				e1.printStackTrace();
			}
			_mediatorsMap.put(si, rsi);
		}
		try {
			plugin = _yanceesRemote.connectToSharedProtocol(protocolId, rsi);
			rsi.incReferenceCounter();
		} catch (RemoteException e) {
			throw new YanceesException(
					"YanceesRMIClient: remote error when connecting to remote protocol: "
							+ e.toString());
		}

		return plugin;

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see edu.uci.isr.yancees.YanceesInterface#connectToNewProtocol(java.lang.String,
	 *      edu.uci.isr.yancees.SubscriberInterface)
	 */
	public ProtocolPluginInterface connectToNewProtocol(String protocolId,
			SubscriberInterface si) throws YanceesException {

		RemoteProtocolPluginInterface plugin;

		SubscriberMediator rsi = (SubscriberMediator) _mediatorsMap.get(si);
		if (rsi == null) {
			try {
				rsi = new SubscriberMediator(si);
			} catch (RemoteException e1) {
				System.out.println("YanceesRMIClient: remote exception");
				e1.printStackTrace();
			}
			_mediatorsMap.put(si, rsi);
		}
		try {
			plugin = _yanceesRemote.connectToNewProtocol(protocolId, rsi);
			rsi.incReferenceCounter();
		} catch (RemoteException e) {
			throw new YanceesException("YanceesRMIClient: remote error "
					+ e.toString());
		}

		return plugin;

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see edu.uci.isr.yancees.YanceesInterface#disconnectFromProtocol(java.lang.String,
	 *      edu.uci.isr.yancees.SubscriberInterface)
	 */
	public void disconnectFromProtocol(String protocolId, SubscriberInterface si)
			throws YanceesException {

		SubscriberMediator rsi = (SubscriberMediator) _mediatorsMap.get(si);
		if (rsi == null) {
			// do nothing
		} else {
			try {
				_yanceesRemote.disconnectFromProtocol(protocolId, rsi);

			} catch (RemoteException e) {
				throw new YanceesException("YanceesRMIClient: remote error "
						+ e.toString());
			}
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see yancees.YanceesInterface#publish(yancees.core.EventInterface)
	 */
	public void publish(EventInterface evt) throws YanceesException {

		if (USE_PUBLICATION_BUFFER) {
			_pubBuffer.addEventToBuffer(evt);
		} else {
			try {
				_yanceesRemote.publish(evt);
			} catch (RemoteException e) {
				throw new YanceesException("YanceesRMIClient: remote error "
						+ e.toString());
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see yancees.YanceesInterface#resumeYancees()
	 */
	public void resumeYancees() throws YanceesException {
		try {
			_yanceesRemote.resumeYancees();
		} catch (RemoteException e) {
			throw new YanceesException("YanceesRMIClient: remote error "
					+ e.toString());
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see yancees.YanceesInterface#shutdownYancees()
	 */
	public void shutdownYancees() throws YanceesException {
		try {
			_yanceesRemote.shutdownYancees();
		} catch (RemoteException e) {
			throw new YanceesException("YanceesRMIClient: remote error "
					+ e.toString());
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see yancees.YanceesInterface#subscribe(yancees.core.MessageInterface,
	 *      yancees.RemoteSubscriberInterface)
	 */
	public void subscribe(SubscriptionInterface msg, SubscriberInterface si)
			throws YanceesException {

		SubscriberMediator rsi = (SubscriberMediator) _mediatorsMap.get(si);
		if (rsi == null) {
			try {
				rsi = new SubscriberMediator(si);
			} catch (RemoteException e1) {
				System.out.println("YanceesRMIClient: remote exception");
				e1.printStackTrace();
			}
			_mediatorsMap.put(si, rsi);
		}
		try {
			_yanceesRemote.subscribe(msg, rsi);
			rsi.incReferenceCounter();
		} catch (RemoteException e) {
			throw new YanceesException("YanceesRMIClient: remote error "
					+ e.toString());
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see yancees.YanceesInterface#suspendYancees()
	 */
	public void suspendYancees() throws YanceesException {
		try {
			_yanceesRemote.suspendYancees();
		} catch (RemoteException e) {
			throw new YanceesException("YanceesRMIClient: remote error "
					+ e.toString());
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see yancees.YanceesInterface#unsubscribe(yancees.SubscriberInterface,
	 *      yancees.core.MessageInterface)
	 */
	public void unsubscribe(SubscriberInterface si, MessageInterface sub)
			throws YanceesException {

		SubscriberMediator rsi = (SubscriberMediator) _mediatorsMap.get(si);
		if (rsi == null) {
			throw new YanceesException(
					"No subscription received from this SubscriberInterface. Nothing to subscribe!");
		} else {
			try {
				_yanceesRemote.unsubscribe(rsi, sub);
				rsi.decReferenceCounter();
				if (rsi.getReferenceCounter() <= 0) {
					_mediatorsMap.remove(si);
				}
			} catch (RemoteException e) {
				throw new YanceesException("YanceesRMIClient: remote error "
						+ e.toString());
			}
		}

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see yancees.YanceesInterface#unsubscribe(yancees.SubscriberInterface)
	 */
	public void unsubscribe(SubscriberInterface si) throws YanceesException {

		RemoteSubscriberInterface rsi = (RemoteSubscriberInterface) _mediatorsMap
				.get(si);
		if (rsi == null) {
			throw new YanceesException(
					"No subscription received from this SubscriberInterface. Nothing to subscribe!");
		} else {
			try {
				_yanceesRemote.unsubscribe(rsi);
				_mediatorsMap.remove(si);
			} catch (RemoteException e) {
				throw new YanceesException("YanceesRMIClient: remote error "
						+ e.toString());
			}
		}
	}

	/**
	 * This buffer schedules events to be published. The aim is to cope with
	 * scalability and high throughput, in order to publish a bunch of events at
	 * onnce, instead of one at a time. This strategy better utilizes the RMI
	 * serialization mechanisms and icreases the throughput of the server.
	 *
	 * A big buffer will allow the server to handle more publish commands per
	 * second. However, it will reduce the latency (the time between production
	 * and delivery of an event). A low SLEEP_TIME will not permit the buffer to
	 * get full, and will reduce the throughput.
	 *
	 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
	 *
	 */
	private class PublicationBuffer extends Thread {

	    // maximum number of events in the buffer
		private final int BUFFER_SIZE = 
			edu.uci.isr.yancees.YanceesProperties.getInstance().PS_BUFFER_SIZE; 

	   // period when the buffer, if full, is flushed.
		private final int SLEEP_TIME = edu.uci.isr.yancees.YanceesProperties
				.getInstance().PS_BUFFER_FLUSH_PERIOD; 

		// private final int BUFFER_SIZE = 100; // maximum number of events in
		// the buffer
		// private final int SLEEP_TIME = 50; // period when the buffer, if
		// full, is flushed.

		private long totalEventsPublished = 0;
		
		// cicular buffer
		EventInterface[] buffer = new EventInterface[BUFFER_SIZE];
		private int size = 0;
		private int bottom = 0;

		/**
		 * Main logic of this thread
		 */
		public void run() {
			while (true) {
				if (!bufferIsEmpty()) {
					publishEvents();
				} else {
					try {
						Thread.sleep(SLEEP_TIME);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}

		/**
		 * Method used internally at this class to publish the events in the
		 * buffer.
		 * No two threads in the system can be invoking publishEvents() at the same
		 * time.
		 */
		private synchronized void publishEvents() {

			// System.out.println("Publishing events...");
			// System.out.println(" bottom = "+bottom+" elements = "+size);

			if (!bufferIsEmpty()) {

				int elementsToProcess = size;
				EventInterface[] evtList = new EventInterface[elementsToProcess];

				for (int i = 0; i < elementsToProcess; i++) {
					evtList[i] = getEventFromBuffer();
				}

				try {
					_yanceesRemote.publishBuffer(evtList);
					// totalEventsPublished += evtList.length;
					// System.out.println("Total Events Published =
					// "+totalEventsPublished);

				} catch (RemoteException e) {
					System.out.println("YanceesClient: remote error "
							+ e.toString());
					e.printStackTrace();
				} catch (YanceesException e) {
					System.out
							.println("Error when publishing event batch to YANCEES "
									+ e.toString());
					e.printStackTrace();
				}

			}

			// System.out.println("Published");
			// System.out.println(" bottom = "+bottom+" elements = "+size);
			// System.out.println();
		}

		/**
		 * Method used by the clients of this class to enqueue events in the
		 * buffer
		 *
		 * @param event
		 */
		public synchronized void addEventToBuffer(EventInterface event) {

			if (bufferIsFull()) {
				// flush buffer first if it is full...
				publishEvents();
			}

			// System.out.println("Adding element to buffer");
			// System.out.println(" bottom = "+bottom+" elements = "+size);

			int index = (bottom + size) % BUFFER_SIZE;
			buffer[index] = event;
			incSize();

		}

		/**
		 * This method should be called when there is some event on the buffer,
		 * otherwise, it returns null
		 *
		 * @return null if buffer is empty, the element in FIFO order, in case
		 *         there is at least one element on it.
		 */
		public EventInterface getEventFromBuffer() {
			int index = bottom;

			if (size > 0) {
				incBottom();
				decSize();
				return buffer[index];
			} else {
				return null;
			}
		}

		private void incBottom() {
			bottom = (bottom + 1) % BUFFER_SIZE;
		}

		private void decSize() {
			if (size > 0)
				size--;
		}

		private void incSize() {
			size++;
		}

		private boolean bufferIsFull() {
			return size == BUFFER_SIZE;
		}

		private boolean bufferIsEmpty() {
			// for some reason, the buffer size is becoming negative, even
			// though
			// I have a guard at decsize()
			return size <= 0;
		}

	}

	/**
	 * @param si an existing subscriber
	 * @return a remoteInterface, able to receive remote notifications, for the
	 * equivalent local subscriber. It returns null if the mediator for this 
	 * interface does not exist
	 */
	public RemoteSubscriberInterface getRemoteInterfaceFor(SubscriberInterface si) {
		return (RemoteSubscriberInterface) _mediatorsMap.get(si);
	}
	
	/**
	 * The subscriber mediator receives notifications from the plug-ins and
	 * forward them to their specific subscribers.
	 */
	public class SubscriberMediator extends
			RemoteAbstractSubscriberImplementation {

		private SubscriberInterface si; // the subscriber to be notified
		private int referenceCounter = 0;

		/**
		 * Constructor
		 *
		 * @param s
		 *            is the subscriber interface to be notified when the
		 *            plug-in evaluation tree is completed.
		 */
		public SubscriberMediator(SubscriberInterface s) throws RemoteException {
			super();
			referenceCounter++;
			si = s;
		}

		/**
		 * Receives notification as RemoteSubscriberInterface and forwards it to
		 * the client SubscriberInterface
		 *
		 * @param evt
		 *            is the event received from the remote notification service
		 */
		public void notify(EventInterface evt) throws RemoteException {
			si.notify(evt);
		}

		/**
		 * Receives notification list as RemoteSubscriberInterface and forwards
		 * it to the client SubscriberInterface
		 *
		 * @param evtList
		 *            is the list of events received from the remote
		 *            notification service
		 */
		public void notify(EventInterface[] evtList) throws RemoteException {
			si.notify(evtList);
		}

		public void incReferenceCounter() {
			referenceCounter++;
		}

		public void decReferenceCounter() {
			referenceCounter--;
		}

		public int getReferenceCounter() {
			return referenceCounter;
		}

		/**
		 * Receives a batch of events and patterns as a notification
		 */
		public void notifyBuffer(Object[] objList)
				throws RemoteException {
			for (int i = 0; i < objList.length; i++) {
				Object obj = objList[i];
				if (obj instanceof EventInterface[]) {
					this.notify((EventInterface[]) obj);
				} else if (obj instanceof EventInterface) {
					this.notify((EventInterface) obj);
				}	else {
					System.err.println("Object is nor a pattern nor an event");
					System.err.println(obj.toString());
				}
			}
		}

	};

}

