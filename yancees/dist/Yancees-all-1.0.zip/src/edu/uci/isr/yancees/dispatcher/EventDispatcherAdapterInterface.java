/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package edu.uci.isr.yancees.dispatcher;


import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.SubscriptionInterface;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

public interface EventDispatcherAdapterInterface {


	/**
	 *  @param evt The event to publish.
	 *  @see Event
	 **/
	public void publish(EventInterface evnt) throws DispatcherException;

	/** subscribes for sequences of events matching pattern <b>p</b>.
	 *
	 *  <p>Notice that given the distributed nature of some
	 *  implementations of Dispatcher interface, there exist race
	 *  conditions that might affect the semantics of subscriptions.
	 *  A subscriber might miss some notifications published before or
	 *  while the subscription is processed by Dispatcher.
	 *
	 *  <p>Also, keep in mind that the current implementation of Dispatcher
	 *  does not enforce any temporal order for the delivery of
	 *  notifications.  This limitation might affect the recognition
	 *  of patterns.  For example, two notifications <em>x</em> and
	 *  <em>y</em>, generated at time <em>t<sub>x</sub></em> and
	 *  <em>t<sub>y</sub></em> respectively, with
	 *  <em>t<sub>x</sub></em> &lt; <em>t<sub>y</sub></em>, in that
	 *  order matching a pattern <em>P=(f<sub>x</sub>
	 *  f<sub>y</sub>)</em>, might in fact reach the subscriber at
	 *  times <em>T<sub>x</sub></em> and <em>T<sub>y</sub></em>, with
	 *  <em>T<sub>x</sub></em> &gt; <em>T<sub>y</sub></em>, in which
	 *  case pattern <em>P</em> would not be matched.
	 *
	 *  @param li is the subscriber
	 *  @param sub is the subscription pattern
	 *  @see #unsubscribe
	 **/
	public void subscribe(SubscriptionInterface sub, EventDispatcherListenerInterface li) throws
			DispatcherException;

	/** cancels the subscriptions, posted by <b>li</b>, whose subscripton
	 *  <b>sub'</b> is covered by subscripiton <b>p</b>.
	 *
	 *  <p>Unsubscriptions might incurr in the same kind of race
	 *  conditions as subscriptions.  Dispatcher will stop sending
	 *  notifications to the subscriber only after it has completed
	 *  the processing of the unsubscription.  Due to the distributed
	 *  nature of some implementations of Dispatcher, this might result in
	 *  some additional ``unsolicited'' notifications.
	 *
	 *  @param li is the subscriber interface
	 *  @see #subscribe
	 **/
	public void unsubscribe(SubscriptionInterface sub, EventDispatcherListenerInterface li) throws
			DispatcherException;

	/** cancels <i>all</i> the subscriptions posted by <b>n</b>.
	 *
	 *  @param li is the subscriber
	 *  @see #subscribe
	 **/
	public void unsubscribe(EventDispatcherListenerInterface li) throws DispatcherException;

	/** suspends the delivery of notifications to the given subscriber
	 *  <code>li</code>.
	 *
	 *  @param li subscriber to be suspended
	 **/
	public void suspendDispatcher(EventDispatcherListenerInterface li) throws
			DispatcherException;

	/** resumes the delivery of notifications to the given subscriber
	 *  <code>n</code>.
	 *
	 *  @param n subscriber to be resumed
	 **/
	public void resumeDispatcher(EventDispatcherListenerInterface li) throws
			DispatcherException;

	/** closes this Dispatcher service access point.
	 *
	 *  This method releases any system resources associated with the
	 *  access point.  In case this access point is connected to other
	 *  Dispatcher servers, this method will properly disconnect it.
	 **/
	public void shutdownDispatcher() throws DispatcherException;

	/**
	 * Connects and initializes the registered dispatchers
	 * This method is used by the server-specific adapters
	 * @param address is the address of the server.
	 * 
	 */
	public void connect(String address) throws DispatcherException;   
   /**
    * @return a name that identifies this adapter.
    */
   public String getAdapterName();
    

}