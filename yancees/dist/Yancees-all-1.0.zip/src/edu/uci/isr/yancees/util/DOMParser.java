/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 *
 * ===================================================================
 * The Apache Software License, Version 1.1
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 *
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 *
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package edu.uci.isr.yancees.util;

/**
 * <p>
 * Title: Yancees Notification Server
 * </p>
 * <p>
 * Description: Yet ANother Configurable Extensible Event Service
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: School of Information and Computer Science - University of
 * California, Irvine
 * </p>
 *
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

/**
 * This object parses a DOM Tree
 */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class DOMParser {

	private boolean VALIDATING = edu.uci.isr.yancees.YanceesProperties.getInstance().PERFORM_XML_VALIDATION;

	// Used by the validator parser to use the XML schema grammar.
	final String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
	final String W3C_XML_SCHEMA = "http://www.w3.org/2001/XMLSchema";

	static long globalId = 0;

	long myId;

	private final String tempDir = ".";

	// private final String alternativeTempDir = ".";
	private final String tempFileName = "DOMParser";

	// temporary files suffix
	private final String tempSuffix = ".tmp";

	// used to create a unique identifier for the temporary files
	private static Random generator = new Random(System.currentTimeMillis());

	Document document;

	public DOMParser() {
		DOMParser.globalId++;
		myId = globalId;
	}

	public DOMParser(String filename) {
		this();
		setDocument(filename);

	}

	public DOMParser(File file) {
		this();
		setDocument(file);

	}


	public void setXMLContent(String content) {
		String tempFilePath = writeTextToTempFile(content);
		// we need to open it again here because it is closed by the
		// writeFileContent method...
		setDocument(tempFilePath);

		File tempFile = new File(tempFilePath);
		tempFile.delete();
	}

	public void setDocument(String fileName) {
		setDocument(new File(fileName));
	}

	public void setDocument(File file) {
		document = null;

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setValidating(VALIDATING);
		factory.setNamespaceAware(true);

		// Other factory options
		factory.setIgnoringComments(true);
		factory.setIgnoringElementContentWhitespace(true);
		factory.setCoalescing(true);
		factory.setExpandEntityReferences(false);

		// Instructs the factory to validate using xml schema.
		try {
			factory.setAttribute(JAXP_SCHEMA_LANGUAGE, W3C_XML_SCHEMA);
		} catch (IllegalArgumentException x) {
			System.out.println("This parser does not support JAXP 1.2");
			System.out.println(x);
		}

		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			// set error handler before parsing
			// builder.setErrorHandler(new MyErrorHandler(System.err));
			document = builder.parse(file);

		} catch (SAXParseException spe) {
			// Error generated by the parser
			System.out.println("\n** Parsing error" + ", line "
					+ spe.getLineNumber() + ", uri " + spe.getSystemId());
			System.out.println("   " + spe.getMessage());

			// Use the contained exception, if any
			Exception x = spe;
			if (spe.getException() != null) {
				x = spe.getException();
			}
			x.printStackTrace();

		} catch (SAXException sxe) {
			// Error generated during parsing)
			Exception x = sxe;
			if (sxe.getException() != null) {
				x = sxe.getException();
			}
			x.printStackTrace();

		} catch (ParserConfigurationException pce) {
			// Parser with specified options can't be built
			System.out.println("DOMParser: Parser configuration error");
			pce.printStackTrace();

		} catch (IOException ioe) {
			// I/O error
			System.out.println("DOMParser: I/O Error");
			ioe.printStackTrace();
		}
	}

	public Document getDocument() {
		return document;
	}


	/**
	 * Writes the text to a temp file, with a special name and in the global
	 * temporary directory
	 *
	 * @param text
	 *            the text to be written
	 * @return the path of the file created so it can be opened and used
	 *         elsewhere
	 */
	protected String writeTextToTempFile(String text) {

		// creates the temp directory if necessary.
		File tempDirDirectory = new File(tempDir);
		boolean created;
		if (!tempDirDirectory.exists()) {
			created = tempDirDirectory.mkdir();
			if (!created) {
				System.out
						.println("GenericMessage: could not create temp dir: "
								+ tempDir);
				System.out
						.println("This is necessary to serialize the events in XML");
			}

		}

		// the file name is created here in order to get a random name, based on
		// the
		// time this method is called.
		String tempFilePath = tempDir + "/" + tempFileName + "_" + myId + "_"
				+ generator.nextInt() + tempSuffix;
		File tempFile = new File(tempFilePath);
		try {
			writeFileContent(tempFile, text);
		} catch (IOException ex) {
			System.out.println(ex);
		}

		return tempFilePath;
	}

	/**
	 * Write the content to the destination file. The destintion file is first
	 * erased and then created a new.
	 *
	 * @param destination
	 *            is the destination file
	 * @param content
	 *            is the content to be written
	 * @throws IOException
	 *             in case of some error
	 */
	private void writeFileContent(File destination, String content)
			throws IOException {
		// destination.delete();
		destination.createNewFile();
		FileWriter fileWrite = null;
		BufferedWriter outFile = null;
		String s;

		fileWrite = new FileWriter(destination);
		outFile = new BufferedWriter(fileWrite);

		outFile.write(content);
		outFile.flush();
		outFile.close();
	}

}