/*
 * Created on Sep 20, 2004
 */
package edu.uci.isr.yancees.server.rmi;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 * @author rsilvafi@ics.uci.edu
 */
public class RMIRegistryImpl extends Thread {
	boolean available = false;
	boolean keepRunning = true;

	public boolean isAvailable() {
		return available;
	}

	/**
	 * Main thread method. Keeps the rmi registry running unkill a kill command
	 * is posted.
	 */
	public void run() {
		available = false;
		try {
			LocateRegistry.createRegistry(Registry.REGISTRY_PORT);
		} catch (RemoteException e) {
			System.out
					.println("RMIRegistryImpl: could not create RMI Registry, it must be already running");
			System.out.println(e);
			available = true;
		}
		
		if (! available) {
			available = true;
			System.out.println("RMIRegistryImpl: RMI registry successfully started");
		} else {
			System.out.println("RMIRegistryImpl: RMI registry not started. Using existing rmiregistry");
		}
		while (keepRunning) {
			
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * Kills current rmiregistry.
	 */
	public void kill() {
		keepRunning = false;
	}
	
	/**
	 * Starts this program as a separate process using the command line.
	 * @param args
	 */
	public static void main(String[] args) {
		RMIRegistryImpl registry = new RMIRegistryImpl();
		registry.start();
		System.out.println("Created RMI Registry.");
		
	}

}
