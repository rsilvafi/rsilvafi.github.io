/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
 package test.performance;


import siena.Filter;
import siena.HierarchicalDispatcher;
import siena.Notifiable;
import siena.Notification;
import siena.SienaException;
import siena.comm.InvalidSenderException;
import siena.comm.PacketSenderException;

public class SienaNotificationTest  {

	static int repetitions = 100;
	
	static long[] beginSubscribe = new long[repetitions];
	static long[] endSubscribe = new long[repetitions];
	static long[] beginPublish = new long[repetitions];
	static long[] endPublish = new long[repetitions];
	static long eventSent;
	static long[] notificationReceived = new long[repetitions];
	static long[] averageCycles = new long[repetitions];
	
	static int notifCounter = 0; // number of notifications received

	public static void main(String argv[]) {
	
		String hostname;

		if (argv.length != 1) {
			System.err.println(
				"Usage: java SienaNotificationTest hosthame ");
			System.exit(1);
		}

		hostname = argv[0];
		
		SienaSubscriber subscriber = new SienaSubscriber(hostname);
		subscriber.start();
		
		// give some time for the subscription to happen....
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SienaPublisher publisher = new SienaPublisher(hostname);
		publisher.start();
		
		

	} // main
	
	public static void printStatistics() {
		long period;
		long sum;
		System.out.println("\n Performance data: \n");
		
		System.out.println("\nNotifications Received: "+notifCounter);
		System.out.println("\nSubscription delays:");
		sum = 0;
		for (int i=0; i<1; i++) {
			period = endSubscribe[i] - beginSubscribe[i];
			//System.out.println("Period: "+period+" ms");
			sum = sum + period;
		}
		System.out.println("Average = "+(sum / repetitions)+" ms");
		
		System.out.println("\nPublication delays:");
		sum = 0;
		for (int i=0; i<repetitions; i++) {
			period = endPublish[i] - beginPublish[i];
			//System.out.println("Period: "+period+" ms");
			sum = sum + period;
		}
		System.out.println("Average = "+(sum / repetitions)+" ms");
		
		System.out.println("\nNotification delays:");
		sum = 0;
		for (int i=0; i<repetitions; i++) {
				period = notificationReceived[i] - beginPublish[i];
				//System.out.println("Period: "+period+" ms");
				sum = sum + period;
		}
		System.out.println("Event Throughput Average = "+(sum / repetitions)+" ms");
		
	}

}

class SienaPublisher extends Thread {
	HierarchicalDispatcher siena = null;
	
	public SienaPublisher(String hostname) {
		super();
		
		siena = new HierarchicalDispatcher();
	   	try {
	   		siena.setMaster(hostname);
	   	} catch (PacketSenderException ex) {
	   		System.out.println(ex);
	   		System.exit(1);
	   	} catch (java.io.IOException ex) {
				System.out.println(ex);
				System.exit(1);
	   	} catch (InvalidSenderException ex) {
				System.out.println(ex);
				System.exit(1);
	   	}
		
	}
	
	public void run() {
		Notification event;
		System.out.println("SienaPerformanceTest: Publishing "+SienaNotificationTest.repetitions+" events...");
		
		for (int i=0; i<SienaNotificationTest.repetitions; i++) {
		
			event = newEvent(i);
					
			try {
				SienaNotificationTest.beginPublish[i] = System.currentTimeMillis();
				siena.publish(event);
				SienaNotificationTest.endPublish[i] = System.currentTimeMillis();
			} catch (SienaException e1) {
				e1.printStackTrace();
			}
			
			try {
				sleep(150);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
		System.out.println("Finalizing SienaPublisher...");
		
	}
	
	public Notification newEvent(int counter) {
		Notification event = new Notification();
		event.putAttribute("name", "Roberto");
		event.putAttribute("age", 29);
		return event;
	}

	
}

 class SienaSubscriber extends Thread implements Notifiable {
	HierarchicalDispatcher siena = null;
			
	public SienaSubscriber(String hostname) {
		super();

		siena = new HierarchicalDispatcher();
	   	try {
	   		siena.setMaster(hostname);
	   	} catch (PacketSenderException ex) {
	   		System.out.println(ex);
	   		System.exit(1);
	   	} catch (java.io.IOException ex) {
			System.out.println(ex);
			System.exit(1);
	   	} catch (InvalidSenderException ex) {
			System.out.println(ex);
			System.exit(1);
	   	}
			
	}
		
	public void run() {
		System.out.println("SienaSubscriber: subscribing...");

		Filter mySubscription = new Filter();
		mySubscription.addConstraint("name", "Roberto"); // name = "Roberto"
		//mySubscription.addConstraint("age", Op.GT, 18);	// age > 18
		
		try {
			SienaNotificationTest.beginSubscribe[0] = System.currentTimeMillis();
			siena.subscribe(mySubscription, this);
			SienaNotificationTest.endSubscribe[0] = System.currentTimeMillis();
		} catch (SienaException e1) {
			e1.printStackTrace();
		}
		
		System.out.println("SienaSubscriber: waiting for events...");
		
		while (SienaNotificationTest.notifCounter < SienaNotificationTest.repetitions) {
			try {
				sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Finalizing SienaSubscriber...");
		try {
			siena.unsubscribe(this);
		} catch (SienaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SienaNotificationTest.printStatistics();
		
	}
	
	/* (non-Javadoc)
	 * @see siena.Notifiable#notify(siena.Notification)
	 */
	public void notify(Notification arg0) throws SienaException {
		SienaNotificationTest.notificationReceived[SienaNotificationTest.notifCounter] = System.currentTimeMillis();
		SienaNotificationTest.notifCounter++;
		System.out.println("Got noification "+SienaNotificationTest.notifCounter);

	}

	/* (non-Javadoc)
	 * @see siena.Notifiable#notify(siena.Notification[])
	 */
	public void notify(Notification[] arg0) throws SienaException {
		for (int i=0; i<arg0.length; i++) {
			SienaNotificationTest.notificationReceived[SienaNotificationTest.notifCounter] = System.currentTimeMillis();
			SienaNotificationTest.notifCounter++;
			System.out.println("Got noification "+SienaNotificationTest.notifCounter);
		}
		
		// TODO Auto-generated method stub

	}
	

}
