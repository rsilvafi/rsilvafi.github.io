/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 * 
 * ===================================================================
 * The Apache Software License, Version 1.1
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at  
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 * 
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 * 
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */
package test;

/**
 * <p>Title: Yancees Notification Server</p>
 * <p>Description: Yet ANother Configurable Extensible Event Service</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: School of Information and Computer Science - University of California, Irvine</p>
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import java.io.File;
import java.io.IOException;
import java.util.Vector;

import edu.uci.isr.yancees.AttributeNotFoundException;
import edu.uci.isr.yancees.WrongAttributeTypeException;
import edu.uci.isr.yancees.YanceesEvent;
import edu.uci.isr.yancees.util.DOMNodeAdapter;

/**
 * 
 * @author Roberto Silveira Silva Filho [rsilvafi@ics.uci.edu]
 *
 * tests the YanceesEvent class, which is a wrapper to the XML representation of
 * an event in Yancees. It then exercises all the methods of this class.
 */
public class YanceesEventTest {
	public YanceesEventTest() {
	}

	public static void main(String[] args) {
		
		System.out.println("Creating and empty event...");
		YanceesEvent evt = new YanceesEvent();
		System.out.println( evt.getXMLTextContent() );
		System.out.println(evt.toString());

		System.out.println("Adding some attributes...");
		evt.put("name", "Roberto");
		evt.put("room", 247);
		evt.put("present", true);
		evt.put("other filed", 1.4);
		evt.put("one more field", 3.2342094920809238509348592028309582034);
		
		Vector myVector = new Vector();
		myVector.add(new String("hello"));
		evt.put("object", myVector);
		try {
			System.out.println("Adding attribute: ");
			System.out.println( ((java.util.Vector) evt.getObject("object")).get(0).toString());
		} catch (WrongAttributeTypeException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (AttributeNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		Object[] objectArray = new Object[2];
		objectArray[0] = new String("hello");
		objectArray[1] = new String("hello2");
		
		evt.put("objectArray", objectArray);
		evt.get("objectArray");

		System.out.println(evt.toString());

		evt.remove("other field");
		evt.remove("one more field");
		evt.clearAll();

		System.out.println(evt.toString());

		evt.put("name", "Roberto");
		evt.put("room", 247.43456);
		evt.put("present", false);

		System.out.println( evt.getXMLTextContent() );
		System.out.println();

		System.out.println("Now checking the parsing of a file...");
		if (args.length == 0) {
			System.out.println();
			System.out.println("Error: no file specified as input");
			System.out.println("Test stoped!");
		} else {
			
			System.out.println("Performing another tests, now using a previously defined XML file...");
			DOMNodeAdapter adapt;
			File file = new File(args[0]);
			if (file.exists()) {
				try {
					evt = new YanceesEvent(file);
				} catch (IOException e) {
					e.printStackTrace();
				}
				adapt = new DOMNodeAdapter(evt.getDOM());
				adapt.printNodeTree();
				
			   System.out.println(evt.toString());

				System.out.println("Adding some more attributes...");

				evt.put("name", "John");
				evt.put("room", 12.4);
				evt.put("present", false);

				adapt = new DOMNodeAdapter(evt.getDOM());
				adapt.printNodeTree();

			}
		}

	}

}