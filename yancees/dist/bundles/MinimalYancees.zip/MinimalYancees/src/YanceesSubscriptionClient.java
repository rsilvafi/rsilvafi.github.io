/*
 * Copyright (c) 2002, Regents of the University of California. All rights reserved.
 *
 * ===================================================================
 * The Apache Software License, Version 1.1
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        the Institute for Software Research at
 *        University of California, Irvine"
 *    Alternately, this acknowledgment may appear in the software
 *    itself, if and wherever such third-party acknowledgments normally
 *    appear.
 *
 * 4. The names "YANCEES", "Institute for Software Research" and
 *    "University of California" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    rsilvafi@ics.uci.edu or redmiles@ics.uci.edu.
 *
 * 5. Products derived from this software may not be called
 *    "YANCEES", nor may "YANCEES" appear in their name, without
 *    prior written permission of the University of California Regents.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL WEBCOLLAB.COM OR ITS CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */

import edu.uci.isr.yancees.AttributeNotFoundException;
import edu.uci.isr.yancees.EventInterface;
import edu.uci.isr.yancees.GenericMessage;
import edu.uci.isr.yancees.SubscriberInterface;
import edu.uci.isr.yancees.WrongAttributeTypeException;
import edu.uci.isr.yancees.YanceesEvent;
import edu.uci.isr.yancees.YanceesException;
import edu.uci.isr.yancees.client.rmi.YanceesRMIClient;

public class YanceesSubscriptionClient implements SubscriberInterface {

	YanceesRMIClient client;

	// this is the same code fpr publishers or subscribers
	public void connectToYanceesClient() throws YanceesException {

		/*
		 * connects to YANCEES server at host: hostname.mydomain.com RMI name:
		 * yancees
		 */
		client = new YanceesRMIClient("localhost");

	}

	public void subscribeToEvents() throws YanceesException {

		// A GenericMessage class can be used to represent an event, or in this
		// case, a subscription.
		System.out.println("Creating Generic Message...");
		GenericMessage msg = new GenericMessage(
				"<subscription> <require> messageNum </require> </subscription>");

		System.out.println(msg);

		System.out.println("Posting subscription...");
		client.subscribe(msg, this);

	}

	public void notify(EventInterface[] myEvents) {
		// handle the event list (pattern match) sent by the server when events
		// are match

		YanceesEvent evt;

		for (int i = 0; i < myEvents.length; i++) {
			evt = (YanceesEvent) myEvents[i];
			System.out.println(evt);
		}
	}

	public void notify(EventInterface myEvent) {
		YanceesEvent yanceesEventHelper = (YanceesEvent) myEvent;
		// handle the received event, in this case represented as an
		// YanceesEvent object
		// (It could be a GenericEvent object if a pure XML event is published
		// instead.

		try {
			System.out.println("Message "
					+ yanceesEventHelper.getInt("messageNum") + " caught");
		} catch (WrongAttributeTypeException e) {
			e.printStackTrace();
		} catch (AttributeNotFoundException e) {
			e.printStackTrace();
		}
	}

	/**
	 * main program logic
	 * @param argv
	 */
	public static void main(String[] argv) {
		YanceesSubscriptionClient myClient = new YanceesSubscriptionClient();

		try {
			myClient.connectToYanceesClient();
		} catch (YanceesException e) {
			// failed to connect
		}

		try {
			myClient.subscribeToEvents();
		} catch (YanceesException e) {
			// failed to subscribe
		}

		// keeps the subscriber alive, listening to events that match the
		// subscription
		while (true) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException ex) {
				// interrupted
			}
		}
	}

}