#! /bin/sh

java -cp .:./bin:$CLASSPATH:./lib/Yancees-SNAPSHOT.jar -Djava.rmi.server.codebase="file:///./lib/Yancees-SNAPSHOT.jar  -Djava.security.policy=java.policy.all YanceesPublisher
