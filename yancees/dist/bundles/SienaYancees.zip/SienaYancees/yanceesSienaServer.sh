#! /bin/sh

java -cp .:./bin:./lib/Yancees-SNAPSHOT.jar:./lib/siena-1.5.0.jar:$CLASSPATH -Djava.rmi.server.codebase=file:///./lib/Yancees-SNAPSHOT.jar -Djava.security.policy=java.policy.all -Djava.rmi.dgc.leaseValue=10000 edu.uci.isr.yancees.server.rmi.RemoteYanceesImplementation ./simpleLocalSienaConfiguration.xml