package edu.uci.ics.isr.versionfolder;

/**
 * Title:        Versioned Folders
 * Description:  Extends the WebDAV servlet functionality to implement versioned folders.
 * Copyright:    Copyright (c) 2001
 * Company:      University of California, Irvine
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import org.apache.catalina.servlets.WebdavServlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.naming.NamingException;
import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NameClassPair;
import javax.naming.directory.DirContext;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;


import org.apache.naming.resources.Resource;
import org.apache.naming.resources.ResourceAttributes;


public class DirTest extends WebdavServlet {

   private boolean printLog = true;
   private boolean printDebug = true;

   /**
    * Initialize this servlet.
    */
   public void init()
      throws ServletException {

      super.init();

      System.out.println(getServletContext().getServletContextName()+" initialized!");
   }


   protected void doGet(HttpServletRequest req,
                         HttpServletResponse resp)
      throws IOException, ServletException {
      printDebug("doing GET...");

      super.doGet(req, resp);

      DirContext context = getResources();

      NamingEnumeration enum = null;

      try {
         enum = context.list("/");
      } catch (NamingException ex) {
         printDebug(ex.toString());
      }

      while (enum != null && enum.hasMoreElements()) {
            System.out.println(enum.nextElement());
      }



   }


   /**
     * Prints debug information to the output
     */
    private void printDebug(String message) {

       String formatMsg = "["+getServletName()+"] :"+message;

       if (printDebug)
          System.out.println(formatMsg);
       if (printLog)
          log(formatMsg);

    }

}