package edu.uci.ics.isr.versionfolder;

/**
 * Title:        Versioned Folders
 * Description:  Extends the WebDAV servlet functionality to implement versioned folders.
 * Copyright:    Copyright (c) 2001
 * Company:      University of California, Irvine
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

import org.apache.catalina.servlets.WebdavServlet;


import edu.uci.ics.isr.versionfolder.exceptions.MalformedNameException;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.util.Vector;
import java.util.Hashtable;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;

import javax.naming.NamingException;
import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NameClassPair;
import javax.naming.directory.DirContext;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

import java.util.StringTokenizer;

import org.apache.naming.resources.Resource;
import org.apache.naming.resources.ResourceAttributes;

/**
 * An org.apache.naming.resources.Resource is a wrapper to a file in the current
 * filesystem. It provides access to the file byte stream.
 *
 * org.apache.naming.resources.ResourceAttributes stores the attributes associated
 * to the file represented by a Resorce. For example: Name, Type, CreationDate, and
 * so on.
 */


// Utilities to manipulate the Requests.
import org.apache.catalina.util.RequestUtil;


public class VersionFolderServlet extends WebdavServlet{


   // Constants

   protected final int INFINITE_VERSION_WINDOW = -1;
   protected final int DEFAULT_VERSION_WINDOW  = 5;
   protected final String DEFAULT_FILE_DIR = "/files"; // Relative to the current context
   protected final String DEFAULT_VER_DIR  = "/ver";   // Default version directory


   protected final String VERSION_SEPARATOR    = "~";
   protected final char VERSION_SEPARATOR_CHAR = '~';
   protected final String CONTEXT_ROOT_PARAM   = "context_root";
   protected final String VERSION_ROOT_PARAM   = "version_root";
   protected final String VERSION_WINDOW_PARAM = "version_window";

   // Variables

   private boolean printLog = true;
   private boolean printDebug = true;

   protected String localFolder = null;   // Absolute path of the folder
   protected String versionFolder = null; // Absolute path of the ver folder

   protected String filesFolder = DEFAULT_FILE_DIR; // Relative to the current context
   protected String verFolder   = DEFAULT_VER_DIR;  // Relative to the current context

   protected int versionWindow = DEFAULT_VERSION_WINDOW; // Default version window size

   private int putCounter = 0;
   private boolean firstPut = true; // Flag to indicate if it is the first or second
                                    // time a put is being called. For some reason, the
                                    // MS Webfolder calls them in pairs.

   public void init(ServletConfig config)
        throws ServletException {

        // Set our properties from the initialization parameters
        String value = null;
        try {
            value = config.getInitParameter(CONTEXT_ROOT_PARAM);
            localFolder = value;
        } catch (Throwable t) {
            localFolder = config.getServletContext().getRealPath("/");
            localFolder = localFolder+filesFolder;

        }

        try {
            value = config.getInitParameter(VERSION_ROOT_PARAM);
            versionFolder = value;
        } catch (Throwable t) {
            versionFolder = config.getServletContext().getRealPath("/");
            versionFolder = versionFolder+verFolder;

        }


        try {
            value = config.getInitParameter(VERSION_WINDOW_PARAM);
            int intValue = Integer.parseInt(value);
            if (intValue >0) {
               versionWindow = intValue;
            } else if (intValue <0) {
               versionWindow = INFINITE_VERSION_WINDOW;
            } else {
               versionWindow = DEFAULT_VERSION_WINDOW;
            }

        } catch (Throwable t) {
            ; // Assue the default of 5.

        }


        // Create another context specially to store the version structure.

        super.init(config);

  }

   /**
     * Finalize this servlet.
     */
    public void destroy() {
        super.destroy();
        ;       // No actions necessary
    }


   /**
     * COPY Method.
     */
    protected void doCopy(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {

        printDebug("doing COPY...");

        versionResource(req, resp);

        final Vector v = new Vector();
        v.add(new Integer(2));
        v.add(new Integer(3));


        super.doCopy(req,resp);
    }

    /**
     * DELETE Method.
     */
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {
        printDebug("doing DELETE...");

        super.doDelete(req, resp);

    }

    /**
     * Process a GET request for the specified resource.
     *
     * This method is used to display a directory listing through a WEB browser.
     * The PROPFIND method is used by WebDAV clients instead.
     *
     * @param req The servlet request we are processing
     * @param resp The servlet response we are creating
     *
     * @exception IOException if an input/output error occurs
     * @exception ServletException if a servlet-specified error occurs
     *
     */
    protected void doGet(HttpServletRequest req,
                         HttpServletResponse resp)
        throws IOException, ServletException {

        printDebug("doing GET...");

        super.doGet(req, resp);

    }

    /**
     * LOCK Method.
     */
    protected void doLock(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {

        printDebug("doing LOCK...");

        super.doLock(req, resp);
    }

   /**
     * MKCOL Method.
     */
    protected void doMkcol(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {
        printDebug("doing MKCOL...");

        super.doMkcol(req, resp);
    }

    /**
     * MOVE Method.
     */
    protected void doMove(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {
        printDebug("doing MOVE...");

        // A MOVE is a copy followed by a delete. The delete is performed in
        // the superclass.
        versionResource(req, resp);

        super.doMove(req, resp);
    }


    /**
     * OPTIONS Method.
     */
    protected void doOptions(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {
        printDebug("doing OPTIONS...");

        super.doOptions(req,resp);
    }

    /**
     * PROPFIND Method.
     * This method is used to read the contents of a directory or to
     * display information about a file.
     * It does not display the contents of .VERSIONS folder
     */
    protected void doPropfind(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {
        printDebug("doing PROPFIND...");

        super.doPropfind(req, resp);

    }

    /**
     * PROPPATCH Method.
     */
    protected void doProppatch(HttpServletRequest req,
                               HttpServletResponse resp)
        throws ServletException, IOException {

        printDebug("doing PROPPATCH...");

        super.doProppatch(req, resp);

    }

    /**
     * Process a PUT request for the specified resource.
     *
     * In this case, a new file is being provided or the file exists and is
     * going to be overwritten.
     *
     * @param request The servlet request we are processing
     * @param response The servlet response we are creating
     *
     * @exception IOException if an input/output error occurs
     * @exception ServletException if a servlet-specified error occurs
     *
     * The PUT Command is done twice, the first time it creates an empty file,
     * on the second time, it overwrites the existing file with the content. This is
     * done for each single copy of an external file to the folder. This has to be
     * worked around. It was tested with the Microsoft Web Folders implementation.
     *
     */
    protected void doPut(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {

         printDebug("doing PUT...");

        if (readOnly) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        String path = getRelativePath(req);

        if ((path.toUpperCase().startsWith("/WEB-INF")) ||
            (path.toUpperCase().startsWith("/META-INF"))) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        // Looking for a Content-Range header
        if (req.getHeader("Content-Range") != null) {
            // No content range header is supported
            resp.sendError(HttpServletResponse.SC_NOT_IMPLEMENTED);
        }

        // Retrieve the resources
        DirContext resources = getResources();

        if (resources == null) {
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            return;
        }

        boolean exists = true;
        try {
            resources.lookup(path);
        } catch (NamingException e) {
            exists = false;
        }

        /*
        Solves the problem when PUT is invoked twice for file: the first time to
        create an empty file and the second time to create the actual file, over-
        writting the file with 0 in its content.

        In the first time, the put will

        */


        printDebug("Put counter: "+putCounter);
        printDebug("First put: "+firstPut);
        putCounter++;

        // It will be overwritten by the superclass...
        if (exists && firstPut) {

            // CREATE A VERSION OF THE RESOURCE THAT ALREADY EXISTS
            printDebug("The : "+path+" already exists! "); // no exception was thrown
            printDebug("Versioning the resource: "+path);
            boolean result = versionResource(resources, path);

            if (result)
               printDebug("Versioning successfull!");

        }

        firstPut = ! firstPut;


        super.doPut(req,resp);

    }

/*----------------------------------------------------------------------------*/

    // THIS METHOD WAS NOT TESTED
    protected boolean copyResource(String source, String dest) {
       DirContext resources = getResources();
       Resource sourceRes = null;
       boolean result = true;

       boolean exists = true;
       try {
          sourceRes = (Resource) resources.lookup(source);
       } catch (NamingException e) {
          exists = false;
          printDebug("The source path is not a resource or does not exist");
       }

       Resource newResource = null;
       try {
          newResource = new Resource(sourceRes.streamContent());
          // FIXME: Add attributes
          if (exists) {
              resources.rebind(dest, newResource);
          } else {
              resources.bind(dest, newResource);
          }
      } catch(NamingException e) {
          result = false;
      } catch (IOException e) {
        printDebug(e.toString());
      }

      return result;

   }

/*----------------------------------------------------------------------------*/


    /**
     * Returns true if a path exists false if not.
     * Uses the servlet resources to get this conclusion
     */
    private boolean checkPathExistance(String path) {

       // Retrieve the resources
       DirContext resources = getResources();
       if (resources == null) {
           return false;
       }

      // Indicates the existence of the requested resource...
       boolean exists = true;
       try {
           resources.lookup(path);
       } catch (NamingException e) {
           exists = false;
       }

       return exists;
    }


   /**
     * UNLOCK Method.
     */
    protected void doUnlock(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {
        super.doUnlock(req, resp);
    }


    /**
     * Creates a version of the provided path.
     *
     * It is used by the PUT method. It looks for all the versions of
     * this file stored in the current context, extracts the highest version,
     * increments by one and creates a copy of the most recent file: the one pointed
     * by the path.
     *
     * This method is used becore an overwritting...
     *
     * @param path is the relative path to the current context, includding the
     * file name
     */
    private void createVersion(String path) {
      printDebug("Creating version of "+path);


    }


     /**
     * Create a version of a RESOURCE which will be copied.
     *
     * Inspect the request and saves a version of the current resource if it will
     * be overwritten by the copy command. ie. It needs to have a version created.
     *
     * @param req Servlet request
     * @param resp Servlet response
     * @return boolean true if the versioning was successful
     */
    private boolean versionResource(HttpServletRequest req,
                                 HttpServletResponse resp)
        throws ServletException, IOException {

        // Parsing destination header
        String destinationPath = req.getHeader("Destination");

        if (destinationPath == null) {
            return false;
        }

        int protocolIndex = destinationPath.indexOf("://");
        if (protocolIndex >= 0) {
            // if the Destination URL contains the protocol, we can safely
            // trim everything upto the first "/" character after "://"
            int firstSeparator =
                destinationPath.indexOf("/", protocolIndex + 4);
            if (firstSeparator < 0) {
                destinationPath = "/";
            } else {
                destinationPath = destinationPath.substring(firstSeparator);
            }
        } else {
            String hostName = req.getServerName();
            if ((hostName != null) && (destinationPath.startsWith(hostName))) {
                destinationPath = destinationPath.substring(hostName.length());
            }

            int portIndex = destinationPath.indexOf(":");
            if (portIndex >= 0) {
                destinationPath = destinationPath.substring(portIndex);
            }

            if (destinationPath.startsWith(":")) {
                int firstSeparator = destinationPath.indexOf("/");
                if (firstSeparator < 0) {
                    destinationPath = "/";
                } else {
                    destinationPath =
                        destinationPath.substring(firstSeparator);
                }
            }
        }

        String contextPath = req.getContextPath();
        if ((contextPath != null) &&
            (destinationPath.startsWith(contextPath))) {
            destinationPath = destinationPath.substring(contextPath.length());
        }

        String pathInfo = req.getPathInfo();
        if (pathInfo != null) {
            String servletPath = req.getServletPath();
            if ((servletPath != null) &&
                (destinationPath.startsWith(servletPath))) {
                destinationPath = destinationPath
                    .substring(servletPath.length());
            }
        }

        destinationPath =
            RequestUtil.URLDecode(normalize(destinationPath), "UTF8");

        if (debug > 0)
            System.out.println("Dest path :" + destinationPath);

        if ((destinationPath.toUpperCase().startsWith("/WEB-INF")) ||
            (destinationPath.toUpperCase().startsWith("/META-INF"))) {
            //resp.sendError(WebdavStatus.SC_FORBIDDEN);
            return false;
        }

        String path = getRelativePath(req);

        if ((path.toUpperCase().startsWith("/WEB-INF")) ||
            (path.toUpperCase().startsWith("/META-INF"))) {
            //resp.sendError(WebdavStatus.SC_FORBIDDEN);
            return false;
        }

        // Trying to copy a file to itself. In windows systems, with InternetExplorer,
        // Here the system creates a new file with the same name as the previous one
        // but includding the preffix "Copy of"
        if (destinationPath.equals(path)) {
            //resp.sendError(WebdavStatus.SC_FORBIDDEN);
            return false;
        }

        // Parsing overwrite header

        boolean overwrite = true;
        String overwriteHeader = req.getHeader("Overwrite");

        if (overwriteHeader != null) {
            if (overwriteHeader.equalsIgnoreCase("T")) {
                overwrite = true;
            } else {
                overwrite = false;
            }
        }

        // Overwriting the destination

        // Retrieve the resources
        DirContext resources = getResources();

        if (resources == null) {
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            return false;
        }

        boolean exists = true;
        try {
            resources.lookup(destinationPath);
        } catch (NamingException e) {
            exists = false;
        }

        if (overwrite) {

            // Delete destination resource, if it exists
            if (exists) {
                /*
                if (!deleteResource(destinationPath, req, resp)) {
                    return false;
                } else {
                    resp.setStatus(WebdavStatus.SC_NO_CONTENT);
                }
                */

                // HERE WE CREATE ANOTHER VERSION...

                // The destinatino will be placed in the version folder.
                destinationPath = versionFolder+destinationPath;
                destinationPath = normalize(destinationPath);

                Hashtable errorList = new Hashtable();

                printDebug("File Will be overwritten...");
                printDebug("Creating a version of the resource "+path+
                           " in the destination path :"+destinationPath);

                boolean result = versionResource(resources, errorList,
                                      path, destinationPath);

                if ((!result) || (!errorList.isEmpty())) {

                    //sendReport(req, resp, errorList);
                    return false;
                }

            } else {
                //resp.setStatus(WebdavStatus.SC_CREATED);
            }


        } else {

          // DO NOT DO ANYTHING, THE ERROR WILL VBE HANDLED BY
          // BY THE COPY OPERATION....

          /*
            // If the destination exists, then it's a conflict
            if (exists) {
                resp.sendError(WebdavStatus.SC_PRECONDITION_FAILED);
                return false;
            }

          */
        }

        // Copying source to destination

        /*
        Hashtable errorList = new Hashtable();

        boolean result = copyResource(resources, errorList,
                                      path, destinationPath);

        if ((!result) || (!errorList.isEmpty())) {

            sendReport(req, resp, errorList);
            return false;

        }

        // Removing any lock-null resource which would be present at
        // the destination path
        lockNullResources.remove(destinationPath);
        */

        return true;
    }


    /**
     * Create a version of a COLLECTION whith all its contents.
     *
     * @param resources Resources implementation to be used
     * @param errorList Hashtable containing the list of errors which occured
     * during the copy operation
     * @param source Path of the resource to be copied
     * @param dest Destination path
     *
     * The destination path includes the version folder, but do not have information
     * about the version suffix. For example:
     * source = /folder/a.txt and destination = /ver/folder/a.txt
     */
    private boolean versionResource(DirContext resources, Hashtable errorList,
                                 String source, String dest) {

        printDebug("Versioning: " + source + " To: " + dest);

        // Figures out what the source is...
        Object object = null;
        try {
            object = resources.lookup(source);
        } catch (NamingException e) {
        }

        // A whole directory is being copied, we have to check for each one
        // of its inner resources...
        if (object instanceof DirContext) {

            printDebug("Versioning a DirContext: "+getRelativePath((DirContext)object));
            // Create a destination directory
            /*
            try {
                printDebug("Creating subContext "+dest);
                resources.createSubcontext(dest);
            } catch (NamingException e) {
                //errorList.put
                //    (dest, new Integer(WebdavStatus.SC_CONFLICT));
                return false;
            }
            */

            try {
                NamingEnumeration enum = resources.list(source);
                while (enum.hasMoreElements()) {
                    NameClassPair ncPair = (NameClassPair) enum.nextElement();
                    String childDest = dest;
                    if (!childDest.equals("/"))
                        childDest += "/";
                    childDest += ncPair.getName();
                    String childSrc = source;
                    if (!childSrc.equals("/"))
                        childSrc += "/";
                    childSrc += ncPair.getName();

                    // Create a correspondent version for the subdir.
                    versionResource(resources, errorList, childSrc, childDest);
                }
            } catch (NamingException e) {
                //errorList.put
                //    (dest, new Integer(WebdavStatus.SC_INTERNAL_SERVER_ERROR));
                return false;
            }

        } else {

            if (object instanceof Resource) {
                try {

                    // Creates the subcontexts to hold the versions ...
                    createResourceSubContexts(dest);

                    // The method getDirContext is locking !!!!!!!
                    DirContext destCont=null;
                    try {
                       printDebug("Invoking getDirContext with "+dest);
                       destCont = getDirContext(dest);
                    } catch (NamingException ex) {
                       printDebug("Error when getting the dirContext for "+dest);
                    }
                    String fileName = getFileName(dest);

                    printDebug("Getting newest version for: "+dest);
                    printDebug("Using fileName :"+fileName);
                    printDebug("Using Context :"+destCont.getNameInNamespace());
                    int version = getNewestVersion(destCont, fileName);
                    version++;
                    String versionDest = dest + createVersionSuffix(version);
                    printDebug("Version destination: "+versionDest);

                    printDebug("Binding version resource to context: "+versionDest);
                    resources.bind(versionDest, object);

                    // TO DO: VERSION WINDOW NEEDS TO BE ENFORCED HERE...

                    printDebug("Enforcing version window...");
                    enforceVersionWindow(getDirContext(dest),
                                          getFileName(dest),
                                          versionWindow);


                } catch (NamingException e) {
                    //errorList.put
                    //    (source,
                    //     new Integer(WebdavStatus.SC_INTERNAL_SERVER_ERROR));
                    return false;
                }
            } else {
                //errorList.put
                //    (source,
                //     new Integer(WebdavStatus.SC_INTERNAL_SERVER_ERROR));
                return false;
            }

        }

        return true;

    }

   /**
    * Versions a single resource, given a pathname. It is used by the PUT method
    * to make a backup versioned copy of a resource being overwritten.
    *
    * @path points to a file that already exists and will be overwritten by the
    * super class PUT method. It then creates a versioned copy of the path.
    */
   private boolean versionResource(DirContext resources, String path) {
      String source = path;
      String dest = normalize(versionFolder+path);

      Hashtable errorList = new Hashtable();
      printDebug("Creating a version of the resource "+source+
                            " in the destination path :"+dest);

      return versionResource(resources, errorList, source, dest);

   }


    /**
     * Extracts the fileName from a full qualified relative path.
     */
    protected String getFileName(String fullPathName) {
        String fileName = "";
        fullPathName = normalize(fullPathName);
        int index = fullPathName.lastIndexOf("/");
        fileName = fullPathName.substring(index+1,fullPathName.length());

        return fileName;
    }

    /**
     * Returns a dirContext associated to a relative path.
     *
     * @param relativePath points to a resource or to a conett (directory)
     * @param cont a context to be used in order to do the lookup.
     * @return the associated DirContext or null if it was not found.
     */
    protected DirContext getDirContext(String relativePath)
    throws NamingException {

        boolean exists = true;
        Object obj = null;

        DirContext cont = getResources();

        printDebug("Looking up for "+relativePath);

        try {
           obj = cont.lookup(relativePath);
        } catch (NamingException ex) {
          // Context does not exist, try using the relative path...
          exists = false;
        }


        if (exists) {

          if (obj instanceof DirContext) {
             printDebug("Returning a DirContext");
             return (DirContext) obj;

          } else if (obj instanceof Resource) {

             relativePath = normalize(relativePath);
             int index = relativePath.lastIndexOf("/");
             String contRelPath = relativePath.substring(0,index);

             printDebug("Going to lookup for "+contRelPath);

             DirContext resContext;
             resContext = (DirContext) cont.lookup(contRelPath);

             return resContext;

          }

        // The resource does not exist, it may be a file...
        } else {

            int index = relativePath.lastIndexOf("/");
            String contRelPath = relativePath.substring(0,index);

            try {
               obj = cont.lookup(contRelPath);
            } catch (NamingException ex) {
               // Context does not exist, try using the relative path...
               return null;
            }

            return (DirContext) obj;
        }

        return null;

    }


    /**
     * Creates the subcontexts in which a resource will be placed in the future.
     * The resouce path is sent as a parameter.
     */
    public boolean createResourceSubContexts(String path) {
       StringTokenizer st;

       path = normalize(path);
       st = new StringTokenizer(path,"/");

       DirContext context = (DirContext) getResources();
       String currentContextName="";
       String fullContextName="";
       Object obj;
       boolean exists;

       // Ignore the last token, which is the file name
       int totalTokens = st.countTokens();
       for (int t=0; t < totalTokens-1;t++) {

           currentContextName = st.nextToken();
           fullContextName += "/"+currentContextName;

           exists = true;
           try {
              obj = context.lookup(currentContextName);
           } catch (NamingException ex) {
              exists = false;
           }

           if (!exists) {
              try {
                 context.createSubcontext(currentContextName);
                 printDebug("Creting subcontext :"+currentContextName);
              } catch (NamingException ex) {
                 printDebug("Error when creting context :"+currentContextName);
              }

           }

           // Change to the new context.
           try {
              context = (DirContext) context.lookup(currentContextName);
              printDebug("Changing to subContext :"+currentContextName);
           } catch (NamingException ex) {
              printDebug("Error when changing to new context :"+currentContextName);
           }
       }

       printDebug("full context name :"+fullContextName);

       return true;

    }

    /**
     * Return a context-relative path, beginning with a "/", that represents
     * the canonical version of the specified path after ".." and "." elements
     * are resolved out.  If the specified path attempts to go outside the
     * boundaries of the current context (i.e. too many ".." path elements
     * are present), return <code>null</code> instead.
     *
     * @param path Path to be normalized
     */
    protected String normalize(String path) {

        if (path == null)
            return null;

        path.replace('\\','/');

        return super.normalize(path);
    }

    /**
     * Composes a version suffix for the given version
     */
    protected String createVersionSuffix(int version) {

       // First time version, start counting on 1.
       if (version == 0) {
          version = 1;
       }

       return new String(VERSION_SEPARATOR+version+VERSION_SEPARATOR);
    }


    /**
     * Extracts the verison of the fileName provided.
     */
    protected int extractVersion(String fileName) throws MalformedNameException {

        int currentPos = fileName.length()-1;

       //check for the final character...
       if (fileName.charAt(currentPos) != VERSION_SEPARATOR_CHAR) {
          throw new MalformedNameException("The last character is invalid");
       } else {
          currentPos--;
          while ((fileName.charAt(currentPos) != VERSION_SEPARATOR_CHAR) &&
                (currentPos >0) ){
             currentPos --;
          }
          if (currentPos == 0) {
             throw new MalformedNameException("A '~' character is missing...");
          }
          String strNumb = fileName.substring(currentPos+1,fileName.length()-1);

          return Integer.parseInt(strNumb);
       }

       //return 0;

    }


// ************************* Version Handling Methods *************************

    /**
    * Returns the newest version suffix for a given fileName in a
    * context. Ignores all directroies. The newest is the biggest.
    *
    * For example, if the fileName = "filename.txt" and there are two files
    * in the current context under the names: filename.txt~1~ and filename.txt~3~
    * the biggest version is 3.
    *
    * @param context the context to search for. No subdir is searched
    * @param fileName the original fileName (without version info and path)
    *
    * @returns the version number (>0) or 0 if there is no versioned fileName
    * in the current context.
    */
   public int getNewestVersion(DirContext context, String fileName) {

      NamingEnumeration enum = null;
      NameClassPair ncPair;
      String currentName;
      int biggestVersion = 0;


      printDebug("Looking for versions of the file :"+fileName);

      try {
          printDebug("Looking for newest version in :"+context.getNameInNamespace());
          enum = context.list("/");
      } catch (NamingException ex) {
          printDebug ("Error listing the context '/'...");
          printDebug (ex.toString());
      }

      int verNumb;
      while (enum != null && enum.hasMoreElements()) {
         ncPair = (NameClassPair) enum.nextElement();
         currentName = ncPair.getName();
         verNumb =0;

         // If the currentName starts with the fileName substring...
         if (currentName.indexOf(fileName) == 0) {

            printDebug("Found the name : "+fileName+" in the context");

            // If the fileName has a suffix...
            if (currentName.length() > fileName.length()) {

               printDebug("The file : "+currentName+" is versioned");

               int currPos = fileName.length();
               //printDebug("The char at position "+currPos+" is "+
               //               currentName.charAt(currPos));

               // It is a versioned artifact...
               if (currentName.charAt(currPos) == VERSION_SEPARATOR_CHAR) {
                  currPos++;
                  //printDebug("The char at position "+currPos+" is "+
                  //            currentName.charAt(currPos));

                  // Extract the version number String
                  String verNumbStr = new String("");
                  while (currPos < currentName.length() &&
                         currentName.charAt(currPos) != VERSION_SEPARATOR_CHAR) {
                    verNumbStr += currentName.substring(currPos,currPos+1);
                    currPos++;
                    //printDebug("version String is "+verNumbStr);
                  }
                  if (verNumbStr.length() >0) {
                    verNumb = Integer.parseInt(verNumbStr);
                  }
               }
            }

         } // if

         biggestVersion = java.lang.Math.max(biggestVersion,verNumb);
         printDebug("Biggest version is "+biggestVersion);

      } // while

      printDebug("Retturning biggest version "+biggestVersion);
      return biggestVersion;
   }

   /**
    * @param context The directory context where to look for the resource
    * @param fileName The name of the file to look up.
    *
    * @returns a Resource with the found file or null if the file was not found.
    */
   public Resource getOldestVersionResource(DirContext context, String fileName) {

      int ver = getOldestVersion(context, fileName);

      Resource res = null;

      try {
         res = (Resource) context.lookup(fileName+VERSION_SEPARATOR+ver+VERSION_SEPARATOR);
      } catch (NamingException ex) {
         printDebug(ex.toString());
      }

      return res;

   }

   /**
    * Deletes the oldest version associated to the provided fileName in the provided
    * version context. The resource to be erased is the fileName concatenated with
    * the oldest version currently available in the context.
    *
    * This method is used to manage the version window for each file.
    *
    * The fileName is passed without any path information associated.
    *
    * @param context The context to look for the oldest version
    * @param fileName The fileName which correspondent oldest version will be erased
    * @return true if the operation was successfully accomplished, false if not.
    */
   public boolean deleteOldestVersionResource(DirContext context, String fileName) {
      int ver = getOldestVersion(context, fileName);
      try {
        context.unbind(fileName+VERSION_SEPARATOR_CHAR+ver+VERSION_SEPARATOR_CHAR);
      } catch (NamingException ex) {
        return false;
      }

      return true;
   }

   /**
    * Counts the number of versions of a given filename which are stored in a
    * given context.
    *
    * @param context The context where the versions of fileName are stored
    * @param fileName the file that is being versioned
    *
    */
   public int countVersions(DirContext context, String fileName) {

      NamingEnumeration enum = null;
      NameClassPair ncPair;
      String currentName;

      int counter=0; // Counts the occurrences

      // Get all files in the current context
      try {
          enum = context.list("/");
      } catch (NamingException ex) {
          printDebug (ex.toString());
      }

      // For all files in the current context...
      while (enum != null && enum.hasMoreElements()) {
         ncPair = (NameClassPair) enum.nextElement();
         currentName = ncPair.getName();

         // If the currentName starts with the fileName substring...
         if (currentName.indexOf(fileName) == 0) {

            //printDebug("Found the name : "+fileName+" in the context");

            // If the fileName has a suffix...
            if (currentName.length() > fileName.length()) {

               //printDebug("The file : "+currentName+" is versioned");

               int currPos = fileName.length();
               //printDebug("The char at position "+currPos+" is "+
               //               currentName.charAt(currPos));

               // It is a versioned artifact...
               if ( (currentName.charAt(currPos) == VERSION_SEPARATOR_CHAR) &&
                     currentName.endsWith(VERSION_SEPARATOR)) {
                  counter++;
                  //printDebug("The char at position "+currPos+" is "+
                  //            currentName.charAt(currPos));
               }
            }

         } // if

      } // while

      return counter;
   }

   /**
    * Enforces a provided version window, erasing the excess of versions of a
    * fileName inside a context. It erases the oldest versions ultil the number
    * specified in the window is reached.
    *
    * @param context the version context (directory with version files)
    * @param fileName the original file name which versions are stored in the
    *        context. The name does not have path information.
    *
    */
   public void enforceVersionWindow(DirContext context, String fileName, int window) {

       printDebug("enforcing with fileName :"+fileName);
       printDebug("enforcing with context :"+getRelativePath(context));
       printDebug("enforcing with window :"+window);

       while (countVersions(context,fileName) > window) {
          printDebug("Deleting old versions of "+fileName);
          deleteOldestVersionResource(context, fileName);
       }
   }

   /**
    * Converts a path in its correspondent version path: the path in which the
    * versions are stored
    */
   public String getCorrespondentVersionPath(String path) {

       return normalize(versionFolder+path);
   }

   /**
    * Converts a context to its correspondent version context: the context
    * where the version Resources are stored
    */
   public DirContext getCorrespondentVersionContext(DirContext context) {
      String verPath;
      DirContext verCont = null;

      try {
         verPath = getCorrespondentVersionPath(getRelativePath(context));
         verCont = (DirContext) getResources().lookup(verPath);
      } catch (NamingException ex) {
        printDebug(ex.toString());
      }

      return verCont;

   }

   /**
    * Replaces the first occurence of a directory inside a path string. For example:
    * /files/a/b/c/filename.txt is replaced by /ver/a/b/c/filename.txt if
    * oldDir = 'files' and newDir = 'ver'
    *
    * @param oldDir old string to be replaced
    * @param newdir new string to take the place of the oldDir string
    * @param path the string having the oldDir substring.
    *
    */
   public String replaceFirstOccurrence(String oldDir, String newDir, String path) {

      path = normalize(path);
      StringTokenizer st = new StringTokenizer(path,"/");

      String newPath = "";
      boolean replaced = false;

      while (st.hasMoreElements()) {
        String dir = (String) st.nextToken();
        if (dir.equals(oldDir) && !replaced) {
           newPath += "/"+newDir;
           replaced = true;
        } else {
          newPath += "/"+dir;
        }
      }

      return normalize(newPath);
   }

    /**
    * Returns the oldest version suffix for a given fileName in a
    * context. Ignores all directroies. The oldest is the shortest.
    *
    * For example, if the fileName = "filename.txt" and there are two files
    * in the current context under the names:
    * filename.txt~1~ and filename.txt~3~
    * the shortest version is 3.
    *
    * @param context the context to search for. No subdir is searched
    * @param fileName the original fileName (without version info)
    *
    * @returns the version number (>0) or Integer.MAX_VALUE if there is no
    *  versioned fileName in the current context.
    */
   public int getOldestVersion (DirContext context, String fileName) {

      NamingEnumeration enum = null;
      NameClassPair ncPair;
      String currentName;
      int shortestVersion = Integer.MAX_VALUE;

      try {
          enum = context.list("/");
      } catch (NamingException ex) {
          printDebug (ex.toString());
      }

      int verNumb;
      while (enum != null && enum.hasMoreElements()) {
         ncPair = (NameClassPair) enum.nextElement();
         currentName = ncPair.getName();
         verNumb = Integer.MAX_VALUE;

         // If the currentName starts with the fileName substring...
         if (currentName.indexOf(fileName) == 0) {

            //printDebug("Found the name : "+fileName+" in the context");

            // If the fileName has a suffix...
            if (currentName.length() > fileName.length()) {

               //printDebug("The file : "+currentName+" is versioned");

               int currPos = fileName.length();
               //printDebug("The char at position "+currPos+" is "+
               //               currentName.charAt(currPos));

               // It is a versioned artifact...
               if (currentName.charAt(currPos) == VERSION_SEPARATOR_CHAR) {
                  currPos++;
                  //printDebug("The char at position "+currPos+" is "+
                  //            currentName.charAt(currPos));

                  // Extract the version number String
                  String verNumbStr = new String("");
                  while (currPos < currentName.length() &&
                         currentName.charAt(currPos) != VERSION_SEPARATOR_CHAR) {
                    verNumbStr += currentName.substring(currPos,currPos+1);
                    currPos++;
                    //printDebug("version String is "+verNumbStr);
                  }
                  if (verNumbStr.length() >0) {
                    verNumb = Integer.parseInt(verNumbStr);
                  }
               }
            }

         } // if

         shortestVersion = java.lang.Math.min(shortestVersion,verNumb);
         //printDebug("Biggest version is "+shortestVersion);

      } // while

      return shortestVersion;
   }


   /**
    * Returns the realive path of the DirContext in relation to the
    * default servlet context. A DirContext is mapped to a directory
    * related to the current ServletContext.
    */
   private String getRelativePath(DirContext context) {
      String relativePath = "";

      // Real path of this servlet context
      String realPath = getServletContext().getRealPath("/");
      String fullName=""; // The context full name

      try {
         fullName = context.getNameInNamespace();
      } catch (NamingException ex) {
         printDebug(ex.toString());
      }

      relativePath = "/"+fullName.substring(realPath.length(),fullName.length());

      return normalize(relativePath);

   }


    // **************************** Auxiliary methods *************************/

   /**
     * Prints debug information to the output
     */
    private void printDebug(String message) {

       String formatMsg = "["+getServletName()+"] :"+message;

       if (printDebug)
          System.out.println(formatMsg);
       if (printLog)
          log(formatMsg);

    }

}


