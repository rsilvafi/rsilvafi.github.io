package edu.uci.ics.isr.versionfolder.exceptions;

/**
 * Title:        Versioned Folders
 * Description:  Extends the WebDAV servlet functionality to implement versioned folders.
 * Copyright:    Copyright (c) 2001
 * Company:      University of California, Irvine
 * @author Roberto Silveira Silva Filho
 * @version 1.0
 */

public class MalformedNameException extends Exception {

  public MalformedNameException() {
  }

  public MalformedNameException(String msg) {
         super(msg);
  }
}