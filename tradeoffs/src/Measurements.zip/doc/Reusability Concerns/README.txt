This is a re-evaluation of the benchmark, now considering the different
publish/subscribe concerns:
- Publicaiton
- Notification
- Subscription
- Protocol
- Routing
- Event

As well as other concerns that are pertinent to reuse

- Adaptation
- Configuration and Connection

And concerns that are related to performance and scalability

- Factory
- Other (gule)
- Threading and Distribution


In this analysis, we used ConcernMapper and ConcernTagger, both are
plug-ins for Eclipse that allow the grouping of methods and classes
by different concerns. Note that here concerns can overlap.
