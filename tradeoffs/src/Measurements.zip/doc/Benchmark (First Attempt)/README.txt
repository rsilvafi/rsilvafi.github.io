This is the general benchmark, used in the Middleware paper. It was our
first attempt to analyze the benchmark and the infrastructures.

It considers:

- Performance based on an average use case
- Total adaptation costs
- Total development effort (cognitive/reuse distance)
- Development effort of common methods

The metrics here consider both LOC and CC. They are also divided by
methods. These methods are our best effort approach to separate concerns.
Note that in this approach, based on modular decomposition, concerns
do not overlap.

Later on, we found a way to group concerns using ConcernMapper and
ConcernTagger plug-ins. This originated the analysis in the ../Concerns
folder.
