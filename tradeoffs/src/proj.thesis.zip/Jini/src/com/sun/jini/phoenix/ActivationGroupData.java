/*
 * 
 * Copyright 2005 Sun Microsystems, Inc.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * 	http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package com.sun.jini.phoenix;

import java.io.Serializable;

/**
 * Initialization data for {@link ActivationGroupImpl}, to control the
 * activation group's configuration. An instance of this is specified in the
 * <code>ActivationGroupDesc</code> for the group.
 * 
 * @author Sun Microsystems, Inc.
 * 
 * @since 2.0
 */
public class ActivationGroupData implements Serializable {
	private static final long serialVersionUID = 1135616886784731068L;

	/**
	 * The configuration options.
	 * 
	 * @serial
	 */
	private final String[] config;

	/**
	 * Constructs an instance with the specified
	 * {@link net.jini.config.Configuration} options, if any.
	 * 
	 * @param config
	 *           the configuration options, or <code>null</code>
	 */
	public ActivationGroupData(String[] config) {
		this.config = (config == null ? null : (String[]) config.clone());
	}

	/**
	 * Returns the configuration options, or <code>null</code>.
	 * 
	 * @return the configuration options, or <code>null</code>
	 */
	public String[] getConfig() {
		return config == null ? null : (String[]) config.clone();
	}
}
